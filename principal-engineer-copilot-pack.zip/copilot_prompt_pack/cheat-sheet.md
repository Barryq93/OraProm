# Copilot Prompt Cheat Sheet – Principal Engineer Helper

## Modes Overview

You can switch how Copilot responds by starting your prompt with:

- `Mode: Coding` (default if you don’t specify)
- `Mode: Troubleshooting`
- `Mode: Productivity`
- `Mode: Architect`
- `Mode: Team`
- `Mode: Personal`

If you don’t specify a mode, Copilot behaves as **Mode: Coding**.

Every response will start with an **Executive Summary**.

---

## 1. Coding Mode (Default)

**Use when:** you want code, scripts, configs, or templates.

**Trigger:**  
Just ask *normally*, or explicitly:  
`Mode: Coding`

**Expected sections:**

1. Executive Summary  
2. Technical Intent  
3. Build Strategy  
4. Code Solution (with prerequisites, usage, expected output, comments)  
5. Risks & Test Plan  

**Example prompts:**

- `Build an IBM Content Navigator plugin that adds a custom action to download documents as a ZIP.`
- `Mode: Coding – Create a SpringBoot microservice that reads from DB2, exposes REST endpoints, and publishes metrics to Prometheus.`
- `Mode: Coding – Write an Ansible playbook to deploy a WAS application and restart the JVM safely.`
- `Mode: Coding – Generate PowerShell to onboard a new Windows server, install required features, and configure Splunk UF.`

---

## 2. Troubleshooting Mode

**Use when:** you’re debugging incidents, errors, performance, or logs.

**Trigger:**  
`Mode: Troubleshooting`

**Expected sections:**

1. Executive Summary  
2. Diagnostic Analysis  
3. Investigation Plan  
4. Fix / Permanent Resolution  
5. Risk & Verification  

**Example prompts:**

- `Mode: Troubleshooting – Here are DB2 connection errors from WAS; help me identify likely causes and checks.`
- `Mode: Troubleshooting – Splunk is missing logs from one Kofax Workflow Agent. Here are excerpts and config.`
- `Mode: Troubleshooting – BAW task completion is slow. Here are thread dumps and database metrics.`

---

## 3. Productivity Mode

**Use when:** you need documents, plans, emails, or structured thinking.

**Trigger:**  
`Mode: Productivity`

**Expected sections:**

1. Executive Summary  
2. Intent Interpretation  
3. Structured Plan  
4. Final Output (docs/templates/strategies)  
5. Risks & Next Steps  

**Example prompts:**

- `Mode: Productivity – Draft an engineering strategy for modernizing FileNet integrations using SpringBoot microservices.`
- `Mode: Productivity – Create a runbook template for DB2 performance incidents.`
- `Mode: Productivity – Write an executive summary for our Kofax → FileNet → BAW workflow migration.`

---

## 4. Architect Mode

**Use when:** you want solution design, modernization plans, or high-level patterns.

**Trigger:**  
`Mode: Architect`

**Expected sections:**

1. Executive Summary  
2. Requirements & Constraints  
3. Architecture Overview  
4. Component Design  
5. Sequence Diagram / Flow Description  
6. HA/DR/Scaling/Observability Considerations  
7. Risks & Tradeoffs  

**Example prompts:**

- `Mode: Architect – Design an architecture to replace a monolithic Kofax-to-ECM integration with SpringBoot microservices and MQ.`
- `Mode: Architect – Propose an end-to-end solution for FileNet, ICN plugins, BAW workflows, and DocuSign for contract approval.`
- `Mode: Architect – Define how we should monitor WAS, DB2, and BAW using Splunk and Prometheus.`

---

## 5. Team Mode

**Use when:** you’re planning, delegating, or structuring team delivery.

**Trigger:**  
`Mode: Team`

**Expected sections:**

1. Executive Summary  
2. Goal & Scope  
3. Team Roles & Delegation Plan  
4. Work Breakdown (Epics → Stories → Tasks)  
5. Communication & Stakeholder Strategy  
6. Delivery Roadmap / Milestones  
7. Risks, Dependencies & Next Steps  

**Example prompts:**

- `Mode: Team – Break down the work for a new ICN plugin + BAW workflow into epics and stories for a 3-sprint delivery.`
- `Mode: Team – Create a plan for DB2 upgrade across environments with owners, milestones, and risk tracking.`
- `Mode: Team – Plan a cross-team effort to integrate Kofax, FileNet, and DocuSign.`

---

## 6. Personal Mode

**Use when:** you need non-work planning (only when appropriate at work).

**Trigger:**  
`Mode: Personal`

**Expected sections:**

1. Executive Summary  
2. Clarified Intent  
3. Structured Plan  
4. Final Output  
5. Risks & Constraints  

**Example prompts:**

- `Mode: Personal – Help me structure a learning plan to deepen DB2 performance tuning and ICN plugin development.`
- `Mode: Personal – Plan how to balance project work with certification study time over the next 8 weeks.`

---

## Mode Blending

You can combine modes for richer output:

- `Mode: Architect + Coding – Design the solution and then give me the core SpringBoot+DB2 microservice implementation.`
- `Mode: Team + Productivity – Create a roadmap and also draft the stakeholder update email.`
