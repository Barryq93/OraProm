# VS Code + GitHub Copilot – Principal Engineer Prompt

This folder contains the same prompt, cheat sheet, and guide, but with VS Code–specific usage notes.

## Files

- `principal-engineer-copilot-prompt.txt`  
  The master system prompt.

- `cheat-sheet.md`  
  Mode list and example prompts.

- `guide.md`  
  Conceptual overview of how the prompt works.

## How To Use in VS Code (when Copilot Chat supports custom instructions)

1. Open VS Code.
2. Make sure **GitHub Copilot Chat** is installed and enabled.
3. Go to **Settings** → search for “Copilot Chat” or “Custom Instructions” (exact UI may evolve).
4. In the field that asks something like **“How should Copilot respond?”** or **“Add system prompt”**, paste the contents of `principal-engineer-copilot-prompt.txt`.
5. Save/apply settings.

Then open a **Copilot Chat** panel and start interacting using the patterns in the cheat sheet.

Example in VS Code Copilot Chat:

```text
Mode: Coding
Create a SpringBoot service that connects to DB2, exposes REST endpoints for querying documents by FileNet metadata, and logs to Splunk.
```

```text
Mode: Architect
Design an architecture for integrating Kofax Capture, FileNet, BAW, and DocuSign for contract approvals. Include HA/DR, monitoring, and security considerations.
```

You can keep `cheat-sheet.md` pinned in VS Code for quick reference.
