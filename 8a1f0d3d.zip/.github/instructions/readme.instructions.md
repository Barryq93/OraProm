---
applyTo: "**"
description: README standards — auto-create and maintain per-directory README files
---

## Core Principle

Every directory in the workspace must have a `README.md`.
When working in any directory that lacks one, create it immediately using the
Directory Template below — do not ask the user to create it.
When a new file is added to a directory, update that directory's README automatically.

---

## Two-Level Structure

### Level 1 — Directory README
One `README.md` per directory. Contains:
1. A short description of the directory's purpose (2–4 sentences)
2. A **Contents** table listing every file and sub-directory
3. Optional: a **Notes** section for caveats or conventions specific to this folder

### Level 2 — Per-Script Section
Below the Contents table, one section per file using the heading `## filename.ext`.
Each section contains the standard Per-Script Block (see below).

---

## Directory README Template

Use this exact template when creating a `README.md` from scratch:

```markdown
# <Directory Name>

> <One sentence describing what this directory contains and its purpose.>

<Two to three sentences of context: what system it relates to, who owns it,
any important constraints or conventions.>

---

## Contents

| Name | Type | Description |
|------|------|-------------|
| `filename-or-subdir` | Script | Module | Config | Directory | One-line description |

---

## Scripts

<!-- One section per file. Add new sections as files are created. -->

---

## Notes

<!-- Optional: folder-level caveats, conventions, or links -->
```

---

## Per-Script Block Template

Add one of these sections per file, directly under `## Scripts`:

```markdown
## <filename.ext>

**Purpose**: What this file does in one sentence.
**Inputs / Parameters**:
- `PARAM_NAME` — description, required/optional, example value
**Outputs / Side Effects**: What it produces, writes, or changes.
**Dependencies**: Modules, env vars, or external systems required.
**Usage example**:
```
<copy-pasteable invocation>
```
**Last updated**: DD-MM-YY
**Author / Owner**: [team or person]
**Notes**: Edge cases, known limitations, or follow-up items.

---
```

---

## Maintenance Rules

- **New file added** → append a Per-Script Block to the directory's `README.md`
  and add a row to the Contents table. Do not rewrite the whole file.
- **File renamed or deleted** → update the Contents table row and the section
  heading to match. Mark deleted files as `<!-- REMOVED DD-MM-YY -->` rather
  than deleting the section, so history is preserved.
- **Sub-directory added** → add a row in the Contents table with type `Directory`
  and create a new `README.md` in that sub-directory using the Directory Template.
- Never overwrite existing content — append and update only.
- Use DD-MM-YY for all dates.

---

## Quality Checklist

- Every file in the directory has a row in the Contents table
- Every file has a Per-Script Block under `## Scripts`
- Usage examples are copy-pasteable (no placeholder syntax left in)
- No hardcoded credentials or server names in usage examples
- `Last updated` date is current
