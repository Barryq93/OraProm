---
applyTo: "**/tungsten/**"
description: Tungsten Total Agility (TTA) expert rules — auto-activates in tungsten/
---

## Identity — Read This First

**Tungsten Total Agility (TTA)** is Tungsten Automation's intelligent process
automation platform. It is a **separate product** from Kofax Capture.

- Do NOT conflate TTA with Kofax Capture. They are different products from the
  same vendor. Never apply Kofax Capture assumptions to TTA code or design.
- TTA covers: document capture, forms processing, workflow orchestration,
  business rules, and integration with external systems (including CM8).
- TTA is the strategic, growing platform in this workspace. Treat it as a
  first-class system alongside CM8 and DB2.

---

## Version Safety

- **Current workspace version: 2026.1**
- Never assume that an API, COM object, property, or REST endpoint exists
  without verifying against 2026.1 documentation.
- If behaviour differs between versions, flag it explicitly.
- When the version is unknown in a given context, state that and ask before
  proceeding. Never silently assume.

---

## API Patterns — COM vs REST

TTA exposes two integration surfaces. Always clarify which is in use before
writing any integration code.

### COM Automation
- Used for local/server-side automation, typically from PowerShell or scripting hosts.
- COM objects are version-specific — confirm the ProgID is valid for 2026.1.
- Never invoke a COM method without first checking it is present in this version.
- Always release COM objects explicitly to prevent memory leaks:
  ```powershell
  [System.Runtime.InteropServices.Marshal]::ReleaseComObject($obj) | Out-Null
  ```
- Log the COM ProgID and version in the file header comment.

### REST API
- Preferred for integration with CM8, Spring Boot microservices, and external systems.
- Always confirm the endpoint path against TTA 2026.1 API docs before use.
- Use environment variables for base URL, credentials, and tokens — never hardcode.
- Include `Content-Type: application/json` on all POST/PUT requests unless the
  endpoint explicitly requires multipart.
- Handle paginated responses explicitly — never assume a single page returns all results.
- Log the API base URL variable name (not the value) in the file header `Deps` line.

---

## File Header Template

Every script, config, or integration file under `tungsten/` must begin with this block:

```
# ============================================================
# File    : <filename>
# Purpose : <one sentence>
# TTA Ver : 2026.1
# API     : COM | REST | Both | N/A
# Created : DD-MM-YY
# Updated : DD-MM-YY
# Author  : <team or person>
# Deps    : <env vars, modules, or external systems required>
# Notes   : <any version-specific caveats or follow-up items>
# ============================================================
```

Use DD-MM-YY for all dates. No HH:MM required in the header (use it in log lines).

---

## Terminology

Use these terms consistently. Do not invent synonyms.

| Term | Meaning |
|------|---------|
| **TTA** | Tungsten Total Agility — the platform |
| **Workflow** | A TTA process definition (not a "flow" or "pipeline") |
| **Activity** | A step within a TTA workflow |
| **Document Class** | TTA's document categorisation unit |
| **Batch** | A set of documents processed together in TTA capture |
| **Integration Server** | The TTA component that exposes REST/COM to external systems |
| **Export Connector** | TTA component that pushes documents to CM8 or other targets |
| **Field** | A metadata field on a TTA Document Class (not "attribute" or "property") |

---

## Design Checklist

Before submitting any TTA design, integration, or script:

- [ ] Version confirmed as 2026.1 — no assumptions from prior versions
- [ ] API surface stated explicitly (COM / REST / Both)
- [ ] TTA is not referred to as "Kofax Capture" anywhere in the output
- [ ] All credentials and hostnames in environment variables
- [ ] COM objects released explicitly (if COM path used)
- [ ] REST endpoints verified against 2026.1 docs (if REST path used)
- [ ] File header block present and complete
- [ ] Terminology matches the table above
- [ ] MermaidJS diagram offered for any workflow or integration design
- [ ] ADR written if a technology choice or trade-off was made
- [ ] README updated in the affected `tungsten/` sub-directory

---

## CM8 Integration Notes

When TTA integrates with CM8 via Export Connector or REST:
- Target CM8 EE 8.7.0 FP4 — NOT FileNet P8
- Use CM8 REST API or CMIS 1.0 — never the FileNet Java API
- Document Class Fields in TTA must be mapped explicitly to CM8 item type attributes
- Log the CM8 endpoint variable name in the file header `Deps` line

---

## Folder Conventions

```
tungsten/
├── ideas/           ← unstructured exploration, spike notes, early concepts
├── <workflow-name>/ ← one folder per TTA workflow or integration
│   ├── README.md    ← auto-created per readme.instructions.md
│   └── ...
└── README.md        ← workspace-level README for the tungsten/ root
```

- Never put scripts directly in `tungsten/` root — use a named sub-directory.
- The `ideas/` folder is free-form; normal README rules still apply.
- Sub-directory names must match the TTA workflow name exactly (lowercase, hyphens).
