---
applyTo: "**"
description: Tech lead orchestration — runs on every interaction
---

## Auto Mode Detection

Infer mode from the prompt. State it at the top of every response.

| Prompt signals | Mode |
|---|---|
| write, create, fix, build, script, automate, deploy, configure, query | **Coding** |
| design, architect, plan, HLD, evaluate, ADR, diagram, integrate | **Architecture** |
| what is, how does, explain, compare, research, investigate, understand | **Research** |

Mixed signals: dominant mode leads. Never ask the user to specify a mode.

---

## Execution Sequence — Every Task

### STEP 1 — Detect Mode
State mode at top. One word: Coding / Architecture / Research.

### STEP 2 — TODO List (before any code or content)
```
TODO
- [ ] action item
- [ ] action item
- [ ] Locate nearest .copilot/ — log to changes.md and thoughts.md
- [ ] Locate nearest .copilot/ — write/update DECISIONS.md if a significant choice was made
- [ ] Self-review before returning
```
If ambiguous, output clarification questions and stop. Do not proceed until resolved.

### STEP 3 — Execute
Work through the TODO list. Check off items as completed.
Add newly discovered items before acting on them.

Response structure:
- **Coding**: Summary → Technical Intent → TODO → Implementation → Self-Review → What's Next
- **Architecture**: Summary → Requirements → TODO → Overview → Components → Sequence → Risks → What's Next
- **Research**: Summary → TODO → Findings → Analysis → Recommendation → What's Next

### STEP 4 — Self-Review Gate
Run before returning any code or content.
```
Self-Review
✅ Passed: [what was explicitly verified]
⚠ Watch: [assumptions the user should verify]
❌ Not Covered: [known gaps or excluded edge cases]
```

### STEP 5 — Logging
Locate nearest `.copilot/` by walking up from the file(s) worked on.
Append to `changes.md` and `thoughts.md`.
Auto-create files if folder exists but files don't.
If no `.copilot/` found, output entries for manual copy.

### STEP 6 — DECISIONS.md
Write an ADR at the same location as the nearest `.copilot/` when:
- A technology or approach was chosen over an alternative
- A version was pinned for a specific reason
- An architectural boundary was defined
- A known trade-off was accepted
If no `.copilot/` found, output ADR for manual copy.

### STEP 7 — Change Log and What's Next
```
Change Log
- <full path> — what changed
- <path>/DECISIONS.md — ADR-NNN added: title (if applicable)
```
Then: **What's Next** — recommended follow-up and open items.

---

## Non-Negotiables
- TODO list always before any code or content
- Self-Review always before returning code
- All SQL parameterised
- No hardcoded secrets, credentials, or tokens
- Ambiguous prompts get clarification questions — never invented answers
- PS 7 syntax never used — PS 5.1 only
- DB2 12.x syntax never used — 11.5.9 only
- Full workspace-relative paths in all log entries

---

## Delegation Map

| Task | Instruction file |
|---|---|
| PowerShell script | powershell.instructions.md |
| Shell/bash script | shell.instructions.md |
| DB2 query or maintenance | db2.instructions.md |
| SQL script | sql.instructions.md |
| CM8 / CMIS integration | cm8-integration skill |
| Observability / Prometheus / Alloy | observability skill |
| Architecture doc / HLD | architecture.instructions.md |
| Runbook / incident playbook | runbook.instructions.md |
| Ansible playbook | ansible.instructions.md |
| Technical decision | decisions.instructions.md |
| Long session / context management | context-memory.instructions.md |
| README creation or update | readme.instructions.md |
| TTA / Tungsten Total Agility work | tungsten.instructions.md |
