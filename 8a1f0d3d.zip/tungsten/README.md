# tungsten/

> This directory is the workspace root for all Tungsten Total Agility (TTA) work.

TTA (version 2026.1) is Tungsten Automation's intelligent process automation platform,
covering document capture, forms processing, workflow orchestration, and integration
with IBM Content Manager EE (CM8). It is a separate product from Kofax Capture —
do not conflate them.

All work here is governed by `.github/instructions/tungsten.instructions.md`.

---

## Contents

| Name | Type | Description |
|------|------|-------------|
| `ideas/` | Directory | Unstructured exploration, spike notes, and early-stage concepts |

---

## Scripts

<!-- No scripts yet. When a file is added to any sub-directory, append a Per-Script Block
     here following the template in .github/instructions/readme.instructions.md -->

---

## Notes

- Sub-directory names must match the TTA workflow name exactly (lowercase, hyphens).
- Never place scripts directly in this root folder — use a named sub-directory.
- The `ideas/` folder is free-form but still requires its own `README.md` when populated.
- Version in use: **TTA 2026.1** — always verify API behaviour against this version.
