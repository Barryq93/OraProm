# Tungsten Total Agility

Exploratory workspace for Tungsten Total Agility (TTA), formerly Kofax Total Agility.
Contains architecture designs, integration patterns, and sample .NET code for the
on-prem Integration Server deployment.

**Status**: Research and design phase — nothing here is production-deployed yet
**TTA Version**: TBD
**.NET Target**: TBD (samples default to .NET Framework 4.8 until confirmed)

---

## Modules in Scope

| Module | Description |
|--------|-------------|
| Capture | Document ingestion, separation, release scripts, validation |
| Transformation / OCR | Field extraction, classification, DB2 lookups, learning sets |
| Workflow | Process definitions, human tasks, integration activities, custom assemblies |

---

## Folder Structure

Subdirectories are created per workflow or per feature as work progresses.
The ideas/ folder (when present) contains exploratory drafts — not committed designs.

tungsten/
+-- README.md               (this file)
+-- ideas/                  exploratory concepts, ADRs marked Proposed
+-- workflow-name/          one folder per workflow or integration pattern
    +-- README.md           auto-maintained per readme.instructions.md
    +-- designs/            HLD docs and MermaidJS diagrams
    +-- samples/            .NET sample code (.cs, .csproj)

---

## How Copilot Behaves Here

tungsten.instructions.md activates automatically for all files in this folder.
Copilot acts as a TTA subject matter expert covering Capture, Transformation, and Workflow.

Key behaviours:
- All .NET samples include a mandatory file header with TTA version flag and module
- COM interop: always explicit Marshal.ReleaseComObject() in try/finally
- Version-specific APIs flagged with a warning note inline
- All designs include a MermaidJS diagram
- Integration designs follow the TTA Integration Design Checklist
- TTA and Kofax Capture are never conflated

---

## Relationship to Kofax Capture

This environment runs both Kofax Capture (legacy, still live) and TTA (planned/new).
They are separate products. Designs here are TTA-specific unless explicitly noted.
Migration path considerations are flagged where relevant.

---

## Always-Active Rules (inherited from workspace)

- README.md created/updated after any file work per readme.instructions.md
- DECISIONS.md updated after any significant technical choice (Status: Proposed for ideas/)
- No hardcoded credentials, server names, or license strings
- Every .NET file has a header block
- All designs include a MermaidJS diagram

---

## Contents

| Item | Type | Description |
|------|------|-------------|
| (empty — rows added as work begins) | | |
