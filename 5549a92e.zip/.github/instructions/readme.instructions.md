---
applyTo: "**"
description: README.md creation and maintenance — directory index and per-script sections
---

## Two-Level README System

Every directory containing scripts has two README layers inside one README.md:

1. Directory index — index table at the top listing all scripts in the folder
2. Per-script section — one ## script-name section per script with full detail

There is no separate per-script file. All documentation lives in the directory README.md.

---

## When to Act

After any interaction that creates or modifies a script file
(.ps1 .psm1 .psd1 .sh .ksh .bash .sql .db2 .ddl .cs .yml playbook):

1. Check for README.md in the same directory as the file
2. No README -> create it using the Directory README Template below
3. README exists, script section missing -> append a new script section
4. README exists, script section present -> update per the Update Rules below

Never ask the user to create or update a README. Do it as part of the response.

---

## Directory README Template

Create this when no README.md exists in the target directory:

# Directory Name

Platform: Windows Server 2019/2022 | RHEL 8.1 | Both
Language: PowerShell 5.1 | Bash | DB2 SQL | C# .NET | Ansible YAML
Last Updated: DD-MM-YY

---

Scripts

| Script | Purpose | Platform | Last Updated |
|--------|---------|----------|--------------|
| [script-name](#script-name) | One-line description | Windows / Linux | DD-MM-YY |

---

script-name

(first script section — see Script Section Template)

---

## Script Section Template

One section per script. Use the filename without extension as the H2 heading.

script-name

File: script-name.ext
Platform: Windows Server 2019/2022 | RHEL 8.1
Language: PowerShell 5.1 | Bash | DB2 SQL | C# .NET Framework 4.8
Last Updated: DD-MM-YY
Version: 1.0.0

Purpose
One paragraph describing what this script does, why it exists, and what it targets.

Parameters / Arguments

PowerShell:
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| -TargetServer | String | Yes | - | Hostname of the server to check |
| -Threshold | Int | No | 80 | Warning threshold percentage |

Shell or DB2 — use Environment Variables table instead:
| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| DATABASE | Yes | - | DB2 database name |
| DB_USER | Yes | - | DB2 username |
| DB_PASSWORD | Yes | - | DB2 password |

Return / Output

PowerShell PSCustomObject shape:
  Status     = OK | WARN | CRITICAL | UNKNOWN | ERROR
  Message    = Human-readable description
  Value      = measured value
  Threshold  = threshold used
  Server     = target server
  Timestamp  = DD-MM-YY HH:MM:SS
  ScriptName = script filename

Shell: Exit codes: 0 = success, 1 = connection failure, 2 = threshold breached
SQL: list result set columns with type and description

Example Usage

PowerShell:
  .\script-name.ps1 -TargetServer "server01" -Threshold 85

Shell:
  DATABASE=ICMPROD DB_USER=db2inst1 DB_PASSWORD=$DB_PASS ./script-name.sh

Dependencies

| Dependency | Type | Notes |
|------------|------|-------|
| commons\AIB.Logging | PS Module | Via commons symlink - required |
| ~/sqllib/db2profile | Shell env | DB2 environment - must be sourced |
| ICMADMIN.RMOBJECTS | DB2 Table | CM8 Library Server |

Known Caveats
- Operational gotchas, edge cases, version-specific behaviour
- Note CM8 tablespace impact for DB2 scripts
- Note .NET target framework assumption for C# samples

Breaking Changes
(omit this section entirely if there are none)
- DD-MM-YY: describe what broke and what callers must update

Change History

| Date | Version | Change | Breaking |
|------|---------|--------|---------|
| DD-MM-YY | 1.0.0 | Initial version | No |

---

## Update Rules

Parameter, dependency, or output changes: rewrite the affected table to current state.

New functionality: add rows, append Change History row. No breaking flag unless breaking.

Breaking changes — flag when any of the following occur:
- Parameter renamed, removed, or type changed
- Return object property renamed or removed
- Exit code meaning changed
- Required environment variable added or renamed
- DB2 table or schema renamed

When breaking:
1. Update section content to the new state
2. Add or append to the Breaking Changes section
3. Append Change History row with Breaking = Yes
4. Log in nearest changes.md with BREAKING CHANGE prefix

Script removed: remove the section and index row, log the removal in changes.md.

---

## Directory Index Table

Keep alphabetically sorted and always in sync:
- Add row when a new section is added
- Update Last Updated column when a section is modified
- Remove row when a script is removed

---

## Change Log Surface

Every README update must appear in the Change Log:

  - path/README.md - Added section: script-name
  - path/README.md - Updated section: script-name (what changed)
  - path/README.md - BREAKING CHANGE: script-name (what broke)
  - path/README.md - Removed section: script-name
