---
applyTo: "**/tungsten/**,**/tungsten-total-agility/**,**/tta/**"
description: Tungsten Total Agility expert domain context
---

# Tungsten Total Agility — Expert Domain

When working in this directory you are a subject matter expert in Tungsten Total Agility (TTA),
formerly Kofax Total Agility. Apply this domain knowledge alongside all other active instructions.

---

## Product Identity

- Tungsten Total Agility (TTA) is the rebranded name for Kofax Total Agility
- Do not conflate with Kofax Capture — a separate, older product still live in this environment
- TTA is a unified intelligent automation platform deployed on-prem as the Integration Server
- Modules in scope: Capture, Transformation / OCR, Workflow

---

## Version Handling

TTA version is TBD for this workspace:
- Never assume a specific version number
- Flag version-specific features explicitly:
  Warning — Version-specific: this API requires TTA 7.6+. Confirm against your installed version.
- Prefer patterns that work across TTA 7.x and 8.x unless a version is confirmed

.NET target is also TBD:
- SDK and COM automation patterns: default to .NET Framework 4.8
- REST API patterns: prefer .NET 6 but note .NET Framework 4.8 is viable
- Always flag the assumption at the top of any .NET file:
  // Target: .NET Framework 4.8 — adjust if using .NET 6+

---

## Modules in Scope

### Capture
- Document ingestion via watched folders, MFP, email, API
- Batch class configuration and separation profiles
- Release scripts (output to CM8, file system, REST endpoints)
- Validation stations and custom validation scripts

### Transformation / OCR
- Field extraction using locators (format, zone, database, script)
- Classification and document type routing
- Fuzzy DB2 lookups — note CM8 tablespace impact
- Learning set management
- Custom script locators and formatters

### Workflow
- Process definitions, tasks, gateways, swimlanes
- Human task forms and assignments
- Integration activities (REST, SOAP, file, database)
- TTA workflow agents and custom activity assemblies (.NET)
- Process variables and data mapping

---

## .NET Sample Code Standards

### File Header (mandatory on all .cs files)
// =============================================================================
// File:        FileName.cs
// Purpose:     One-line description
// Module:      TTA Capture | Transformation | Workflow | Communications Manager
// Author:      [name]
// Created:     DD-MM-YY
// Modified:    DD-MM-YY
// Target:      .NET Framework 4.8 — adjust if using .NET 6+
// TTA Version: TBD — flag any version-specific APIs used
// Notes:       Prerequisites, operational notes, known caveats
// =============================================================================

### Code Rules
- Never hardcode server URLs, credentials, API keys, or license strings
- Use app.config or appsettings.json for all config — note which in the header
- All COM interop objects must be explicitly released via Marshal.ReleaseComObject()
- Wrap COM calls in try/finally to guarantee release on exception
- Do not swallow COMException — log the TTA error code
- Comments explain why, not what

### COM Interop Pattern
object comObj = null;
try
{
    comObj = new TtaComClass();
    // operations
}
finally
{
    if (comObj != null)
    {
        Marshal.ReleaseComObject(comObj);
        comObj = null;
    }
    GC.Collect();
    GC.WaitForPendingFinalizers();
}

### REST API Pattern
// TTA base URL from config — never hardcode
// TTA uses session tokens — refresh before expiry
var client = new HttpClient();
client.BaseAddress = new Uri(config["TTA:BaseUrl"]);
client.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", await GetTtaTokenAsync(config));

---

## Architecture and Design Standards

All designs use MermaidJS:
- flowchart TD — process flows, capture pipelines, integration topology
- sequenceDiagram — API interactions, release script flows
- stateDiagram-v2 — document lifecycle, workflow case states, batch states

### TTA Integration Design Checklist
- [ ] TTA module identified (Capture / Transformation / Workflow)
- [ ] Integration method defined (SDK/COM, REST, file-based, database)
- [ ] .NET target confirmed or flagged as TBD
- [ ] CM8 integration point identified if documents flow to ECM
- [ ] DB2 lookup tables identified — CM8 tablespace impact noted
- [ ] Error handling defined — what happens to a failed batch or document?
- [ ] Retry and dead-letter strategy defined
- [ ] Volume and throughput estimate included
- [ ] Monitoring hook identified
- [ ] Rollback or manual recovery process documented

---

## Folder Structure Convention

Subdirectories are per-workflow or per-feature — do not invent subfolder names.
An ideas/ folder is valid and treated as draft/exploratory:
- README maintained as normal per readme.instructions.md
- DECISIONS.md entries marked Status: Proposed (not Accepted)

---

## TTA vs Kofax Capture

This environment runs both products — they are separate:
- Do not conflate them when designing or reviewing
- When a pattern applies to both, call out the distinction explicitly
- Migration from Kofax Capture to TTA is a valid use case — flag migration
  considerations when relevant

---

## Terminology Reference

| Term | Meaning |
|------|---------|
| Batch Class | Kofax Capture grouping definition — NOT used in TTA |
| Process Definition | TTA Workflow template (TTA equivalent of a Kofax Capture batch class) |
| Activity | A step in a TTA workflow process |
| Locator | TTA Transformation field extraction component |
| Validation Script | Custom .NET code run at the TTA validation station |
| Release Script | Custom .NET code that exports processed documents to a target system |
| Integration Activity | TTA Workflow step calling an external system (REST, SOAP, DB) |
| Custom Assembly | .NET DLL deployed to TTA to extend workflow activities |
| Separation Profile | TTA Capture rule for splitting multi-document batches |
| Field Type | TTA Transformation named extraction target (like a form field) |
