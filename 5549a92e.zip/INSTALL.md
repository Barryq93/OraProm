# Copilot Setup — Update Package
## Session changes: 07-May-2026

This package contains every file that changed or was created across this session.
Apply all five files — they have interdependencies.

---

## Files and where they go

| File in this zip | Action | Destination in your workspace |
|------------------|--------|-------------------------------|
| `.github/copilot-instructions.md` | REPLACE | `.github/copilot-instructions.md` |
| `.github/instructions/tech-lead.instructions.md` | REPLACE | `.github/instructions/tech-lead.instructions.md` |
| `.github/instructions/readme.instructions.md` | NEW | `.github/instructions/readme.instructions.md` |
| `.github/instructions/tungsten.instructions.md` | NEW | `.github/instructions/tungsten.instructions.md` |
| `tungsten/README.md` | NEW | `tungsten/README.md` at your workspace root (create the folder) |

No other files need to change.

---

## What changed and why

### `.github/copilot-instructions.md` — 4 line edits

Primary Stack:
- Kofax Capture line updated — flagged as legacy platform, still live
- TTA added as a new stack entry (version TBD, on-prem Integration Server, .NET TBD)

Version Pinning:
- Kofax Capture pin updated — do not conflate with TTA; use tungsten.instructions.md
- TTA pin added — version TBD, always flag version-specific APIs with a warning

### `.github/instructions/tech-lead.instructions.md` — 3 areas updated

Delegation Map — two new rows added:
- Tungsten Total Agility (TTA) work  |  tungsten.instructions.md
- README creation or update          |  readme.instructions.md

STEP 5 (Write README.md) — rewritten to:
- Reference readme.instructions.md explicitly
- Enforce the two-level system (directory index + per-script sections)

STEP 2 TODO template and Non-Negotiables — README item now references readme.instructions.md

### `.github/instructions/readme.instructions.md` — NEW (always active)

Governs all README creation and maintenance across the workspace.

Two-level system enforced:
- One README.md per directory (never per-script files)
- Directory index table at top, alphabetically sorted
- One ## script-name section per script with: purpose, parameters, return/output,
  example usage, dependencies, known caveats, breaking changes, change history

Update rules:
- Relevant changes: rewrite affected tables to current state
- New functionality: append rows + Change History row
- Breaking changes: update content + Breaking Changes section + Change History row
  marked Yes + changes.md entry prefixed BREAKING CHANGE
- Script removed: delete section + index row + log removal in changes.md

### `.github/instructions/tungsten.instructions.md` — NEW (auto-activates)

Activates automatically for: **/tungsten/**, **/tta/**, **/tungsten-total-agility/**

Makes Copilot a TTA subject matter expert:
- Modules covered: Capture, Transformation/OCR, Workflow
- Version handling: TTA and .NET both TBD — all version-specific APIs flagged
- .NET file header template mandatory on all .cs files
- COM interop pattern: explicit Marshal.ReleaseComObject() in try/finally
- REST API pattern: session token handling
- TTA Integration Design Checklist (10 items)
- TTA vs Kofax Capture distinction enforced — they are separate products
- Terminology reference (10 terms)

### `tungsten/README.md` — NEW

Starter README for the tungsten/ folder. Documents: purpose, modules in scope,
folder structure convention (per-workflow subfolders + ideas/), Copilot behaviour,
relationship to Kofax Capture.

---

## Also update your workspace root README.md (manual)

Three small additions to your root README.md to keep the directory structure accurate:

Add to the ALWAYS ACTIVE block:
  readme.instructions.md    # README format, per-script sections, update rules

Add to the AUTO-ACTIVATES ON FILE TYPE block:
  tungsten.instructions.md  # tungsten/**  — TTA expert domain, .NET patterns

Add to the root directory tree:
  tungsten/                 # Tungsten Total Agility designs and .NET samples
      README.md

---

## Post-install verification

- [ ] Open a .cs file inside tungsten/ — Copilot should apply TTA COM interop pattern
- [ ] Ask Copilot to write a script — TODO list should reference readme.instructions.md
- [ ] Delegation Map in tech-lead should show both new rows (TTA and README)
- [ ] Confirm tungsten.instructions.md activates automatically (not manually referenced)
