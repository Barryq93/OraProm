# Copilot Setup — Installation Guide

## What's In This Package

```
.github/
  copilot-instructions.md          ← always-on workspace context
  instructions/
    tech-lead.instructions.md      ← 7-step execution sequence, self-review, mode detection
    decisions.instructions.md      ← ADR format, newest-first, index, first-run template
    context-memory.instructions.md ← context pulse, drift detection, session checkpoints
    runbook.instructions.md        ← incident playbook structure + platform diagnostic commands
    powershell.instructions.md     ← PS 5.1, AIB.Logging, commons import, return shape
    shell.instructions.md          ← RHEL 8.1 bash standards, logging pattern
    db2.instructions.md            ← DB2 11.5.9, connect pattern, CM8 schema rules
    sql.instructions.md            ← DB2 syntax rules, ICMADMIN qualification
    architecture.instructions.md   ← MermaidJS types, ADR format, promotion pipeline
    ansible.instructions.md        ← FQCN, idempotency, vault pattern
  skills/
    powershell-script/SKILL.md     ← scaffold PS monitoring scripts
    shell-script/SKILL.md          ← scaffold DB2/Linux shell scripts
    db2-health-check/SKILL.md      ← DB2 health and diagnostic queries
    cm8-integration/SKILL.md       ← CM8 REST/CMIS design review
    ansible-playbook/SKILL.md      ← Ansible playbook generation
    architecture-doc/SKILL.md      ← design docs and MermaidJS diagrams
    observability/SKILL.md         ← Prometheus, Pushgateway, Alloy, Loki, alert rules
  prompts/
    new-adr.prompt.md              ← /new-adr
    new-ps-script.prompt.md        ← /new-ps-script
    new-db2-script.prompt.md       ← /new-db2-script
    new-runbook.prompt.md          ← /new-runbook
    log-session.prompt.md          ← /log-session
    promote-to-adr.prompt.md       ← /promote-to-adr

.copilot-templates/
  changes.md                       ← copy to .copilot/changes.md in any working directory
  thoughts.md                      ← copy to .copilot/thoughts.md in any working directory
  context.md                       ← copy to .copilot/context.md in any working directory

DECISIONS.md                       ← first-run blank template — copy to workspace root
```

---

## Step 1 — Place the .github folder

Copy the `.github/` folder to the root of your `CODING` folder (the root open in VS Code).

```
CODING/
├── .github/               ← place here
│   ├── copilot-instructions.md
│   ├── instructions/
│   ├── skills/
│   └── prompts/
├── architecture/
├── db2/
├── git/
├── powershell/
├── shell/
├── python/
└── workingFolder/
```

---

## Step 2 — Enable instruction files in VS Code

Open VS Code Settings (Ctrl+, or Cmd+,) and confirm these are enabled:

| Setting | Value |
|---------|-------|
| `github.copilot.chat.codeGeneration.useInstructionFiles` | ✅ Enabled |
| `github.copilot.chat.reviewSelection.useInstructionFiles` | ✅ Enabled |
| `github.copilot.chat.testGeneration.useInstructionFiles` | ✅ Enabled |

Skills are **only active in Agent mode**. Use the dropdown next to the Copilot Chat input
to switch to Agent mode when you want skills to activate automatically.

---

## Step 3 — Create the commons symlink (PowerShell)

The `powershell.instructions.md` file expects a `commons` symlink in your
PowerShell script directories that points to your shared AIB.Logging module.

Run this once from an elevated PowerShell prompt for each directory that needs it:

```powershell
# Adjust the target path to your actual shared library location
New-Item -ItemType SymbolicLink `
  -Path "C:\path\to\CODING\powershell\commons" `
  -Target "C:\path\to\shared\AIB.Logging"
```

Or create a single top-level `commons` symlink and reference it via `$PSScriptRoot\..\commons`
depending on your folder depth.

---

## Step 4 — Set up .copilot/ in working directories

The `.copilot/` folder enables session logging (changes.md and thoughts.md).
Set it up in any directory you actively work in.

```powershell
# Example: set up in powershell/ folder
New-Item -ItemType Directory -Path "C:\path\to\CODING\powershell\.copilot"
Copy-Item .copilot-templates\changes.md "C:\path\to\CODING\powershell\.copilot\changes.md"
Copy-Item .copilot-templates\thoughts.md "C:\path\to\CODING\powershell\.copilot\thoughts.md"
Copy-Item .copilot-templates\context.md "C:\path\to\CODING\powershell\.copilot\context.md"
```

Repeat for `shell/`, `db2/`, `architecture/`, `workingFolder/`, or any active repo in `git/`.

**Logging only happens when a `.copilot/` folder exists** — Copilot will not create one for you.

---

## Step 5 — Place DECISIONS.md

Copy `DECISIONS.md` (the blank first-run template) to your workspace root:

```
CODING/
└── DECISIONS.md    ← here
```

Copilot will append ADR entries to this file during agent sessions.
The `decisions.instructions.md` will also auto-create it from the template if it is missing.

---

## Step 6 — Add .copilot/ to .gitignore

The `.copilot/` folders are working session logs, not source control artifacts.
Add this to your root `.gitignore`:

```
.copilot/
```

---

## Prompt Reference

Invoke prompts from the Copilot Chat input with `/`:

| Prompt | Use |
|--------|-----|
| `/new-adr` | Generate a new ADR with MermaidJS diagram |
| `/new-ps-script` | Scaffold a PS 5.1 monitoring script |
| `/new-db2-script` | Scaffold a DB2 shell script |
| `/new-runbook` | Create an incident runbook |
| `/log-session` | Write full session summary to .copilot/ |
| `/promote-to-adr` | Promote a workingFolder draft to architecture/ |

---

## Skills Reference

Skills activate automatically in **Agent mode** when your prompt matches their description.

| Skill | Triggers when you mention... |
|-------|------------------------------|
| `powershell-script` | create / fix / scaffold a PowerShell script |
| `shell-script` | create / fix a shell or bash script |
| `db2-health-check` | DB2 health, monitoring, tablespace, locks |
| `cm8-integration` | CM8 API, CMIS, item types, Spring Boot + CM8 |
| `ansible-playbook` | Ansible playbook, automation, server config |
| `architecture-doc` | design doc, HLD, system diagram, ADR |
| `observability` | Prometheus, Alloy, Pushgateway, Loki, metrics, alerting |

---

## Quick-Start Tip

After placing the files, type `/init` in Copilot Chat (Agent mode).
Copilot will analyse the workspace and refine `copilot-instructions.md` automatically.
