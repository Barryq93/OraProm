---
applyTo: "**"
description: Context accuracy and session coherence for long working sessions
---

## Mandatory Context Pulse

Before responding to any request involving code, scripts, architecture, or file changes:

```
Context Pulse
- Current task: [one sentence]
- Files in scope: [list]
- Key decisions locked: [max 5 from this session]
- Assumptions I am carrying: [anything inferred but not confirmed]
- Confidence: High | Medium | Low
```

If confidence is **Low** on any item, resolve before proceeding.

---

## Drift Detection — Hard Stop

Stop and flag before proceeding if:
- About to reference a variable, function, or file not visible in current context
- Unsure whether a prior decision was confirmed or only suggested
- About to make a change that contradicts something from earlier in the session

```
Context Drift Detected
Issue: [what is unclear]
Last known state: [what was agreed]
Action required: [what to clarify]
```

Never silently resolve drift by guessing.

---

## Session Checkpoints

After every 5 exchanges on the same task, output unprompted:

```
Session Checkpoint
✅ Done: [completed items]
🔄 Remaining: [outstanding]
🔒 Decisions locked: [confirmed choices]
❓ Open questions: [unresolved or deferred]
```

---

## Token Efficiency Rules

- Never repeat code already shown unless explicitly asked
- Prefer diffs and targeted edits over full file rewrites
- For large files, work section-by-section and confirm before moving on
- If a full file rewrite is necessary, state why first

---

## Context Boundary Rules

- Do not carry assumptions from one task into an unrelated new task
- Treat each new file opened as a new scope boundary
- If a prior decision is relevant but not visible: ask the user to re-share it
