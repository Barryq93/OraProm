---
applyTo: "**/db2/**,**/*.db2,**/*.ddl"
description: DB2-specific shell scripts — IBM DB2 LUW 11.5.9 for CM8
---

## Version
Target: **DB2 LUW 11.5.9** — flag anything requiring a higher fix pack.
DB2 12.x syntax must never be used.

## Connection Pattern
```bash
. ~/sqllib/db2profile
db2 connect to "$DATABASE" user "$DB_USER" using "$DB_PASSWORD"
# operations
db2 connect reset
```
- Credentials from env vars: `$DATABASE`, `$DB_USER`, `$DB_PASSWORD`
- Always connect and disconnect explicitly
- Use `db2 -x` for scriptable output (no column headers)
- Check return codes after critical operations:
  ```bash
  db2 "SOME SQL"
  RC=$?
  if [ $RC -ne 0 ]; then log "ERROR: DB2 command failed RC=$RC"; exit $RC; fi
  ```

## CM8 Awareness
- Primary schema: `ICMADMIN` — qualify all CM8 tables: `ICMADMIN.<TABLE>`
- Note CM8 impact in comments for scripts touching tablespaces
- Include RUNSTATS recommendation comments after large data changes
