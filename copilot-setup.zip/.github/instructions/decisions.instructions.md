---
applyTo: "**"
description: Rules for writing and maintaining DECISIONS.md
---

## When to Write an Entry

Write a new ADR when:
- A technology, tool, or platform was chosen over an alternative
- A version was pinned for a specific reason
- An architectural boundary was defined
- A security or compliance constraint shaped the implementation
- A known limitation or trade-off was consciously accepted

Do NOT write entries for trivial naming or formatting choices.

---

## Entry Format

```markdown
## ADR-NNN — Short decision title

**Date**: DD-MM-YY
**Status**: Proposed | Accepted | Superseded by ADR-NNN
**Mode**: Coding | Architecture | Research
**Component**: ECM | DB2 | Kofax | Observability | Ansible | Scripting | etc.
**Jira**: JIRA-XXX (if applicable)

### Context
Why did this decision need to be made?

### Decision
What was decided, in one clear sentence.

### Reasoning
- **Chosen**: name — why
- **Rejected**: name — why rejected

### Consequences
What does this make easier? What does it make harder?

### References
- Link or document title

---
```

---

## Superseding a Decision

1. Change old entry Status to `Superseded by ADR-NNN`
2. New entry references the old in its Context
3. Never delete old entries

---

## DECISIONS.md File Structure

Entries are **newest first**. File structure:

```markdown
# Decisions Log

This file records all significant technical decisions made in this project.
Last updated: DD-MM-YY

---

## Index

| ADR | Title | Component | Status | Date |
|-----|-------|-----------|--------|------|

---

## Decisions

(entries here, newest first)
```

---

## First-Run Template

If DECISIONS.md does not exist at the workspace root, create it:

```markdown
# Decisions Log

This file records all significant technical decisions made in this project.
Last updated: DD-MM-YY

---

## Index

| ADR | Title | Component | Status | Date |
|-----|-------|-----------|--------|------|

---

## Decisions

<!-- ADR entries go here, newest first -->
```

---

## Change Log Surface

Every time DECISIONS.md is written, include in the response:
```
Change Log
- DECISIONS.md — ADR-NNN added: [title]
```
