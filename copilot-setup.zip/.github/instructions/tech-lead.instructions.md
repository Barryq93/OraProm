---
applyTo: "**"
description: Tech lead orchestration — runs on every interaction
---

## Auto Mode Detection

Infer mode from the prompt. State it at the top of every response.

| Prompt signals | Mode |
|---|---|
| write, create, fix, build, script, automate, deploy, configure, query | **Coding** |
| design, architect, plan, HLD, evaluate, ADR, diagram, integrate | **Architecture** |
| what is, how does, explain, compare, research, investigate, understand | **Research** |

Mixed signals: dominant mode leads. Never ask the user to specify a mode.

---

## Execution Sequence — Every Task

### STEP 1 — Detect Mode
State the mode at the top. One word: Coding / Architecture / Research.

### STEP 2 — TODO List (before any code or content)
```
TODO
- [ ] action item
- [ ] action item
- [ ] Update .copilot/changes.md and .copilot/thoughts.md if .copilot/ exists
- [ ] Update DECISIONS.md if a significant technical choice is made
- [ ] Self-review before returning
```
If ambiguous, output:
```
Missing Information
1. [targeted question]
```
Do not proceed past STEP 2 until ambiguity is resolved.

### STEP 3 — Execute
Work through the TODO list. Check off items as completed.
Add newly discovered items to the TODO before acting on them.

Response structure by mode:
- **Coding**: Summary → Technical Intent → TODO → Implementation → Self-Review → What's Next
- **Architecture**: Summary → Requirements → TODO → Overview → Components → Sequence → Risks → What's Next
- **Research**: Summary → TODO → Findings → Analysis → Recommendation → What's Next

### STEP 4 — Self-Review Gate
Run before returning any code. Output the result.
```
Self-Review
✅ Passed: [what was explicitly verified]
⚠ Watch: [assumptions the user should verify]
❌ Not Covered: [known gaps or excluded edge cases]
```

### STEP 5 — .copilot/ Logging
Append to `changes.md` and `thoughts.md` per copilot-instructions.md format.
If not in agent mode, output the log entries for manual copy.

### STEP 6 — DECISIONS.md
Write an ADR entry when:
- A technology, tool, or approach was chosen over an alternative
- A version was pinned for a specific reason
- An architectural boundary was defined
- A known trade-off was consciously accepted
If not in agent mode, output the full ADR block for manual copy.

### STEP 7 — Change Log and What's Next
```
Change Log
- filename — what changed
- DECISIONS.md — ADR-NNN added: title (if applicable)
```
Then: **What's Next** — recommended follow-up and open items.

---

## Non-Negotiables

- TODO list always before any code or content
- Self-Review always before returning code
- All SQL parameterised
- No hardcoded secrets, credentials, or tokens
- Ambiguous prompts get clarification questions — never invented answers
- PS 7 syntax never used — PS 5.1 only
- DB2 12.x syntax never used — 11.5.9 only
- If not in agent mode, surface content for manual copy — never silently skip

---

## Delegation Map

| Task Type | Instruction File |
|---|---|
| PowerShell script | powershell.instructions.md |
| Shell/bash script | shell.instructions.md |
| DB2 query or maintenance | db2.instructions.md |
| SQL script | sql.instructions.md |
| CM8 / CMIS integration | cm8-integration skill |
| Observability / Prometheus / Alloy | observability skill |
| Architecture doc / HLD | architecture.instructions.md |
| Runbook / incident playbook | runbook.instructions.md |
| Ansible playbook | ansible.instructions.md |
| Technical decision | decisions.instructions.md |
| Long session / context management | context-memory.instructions.md |
