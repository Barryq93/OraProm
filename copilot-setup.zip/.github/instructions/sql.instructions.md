---
applyTo: "**/*.sql,**/sql/**"
description: Ad hoc SQL scripts targeting IBM DB2 LUW 11.5.9 for CM8
---

- DB2 LUW 11.5.9 syntax only — no PostgreSQL, MySQL, or ANSI-only constructs
- `FETCH FIRST n ROWS ONLY` — never LIMIT
- `CURRENT TIMESTAMP` — never NOW()
- `CURRENT DATE` — never CURDATE()
- `WITH UR` for read-only diagnostic queries where appropriate
- Qualify CM8 tables: `ICMADMIN.<TABLE>`
- Never SELECT * — list columns explicitly
- Scripts are ad hoc (no stored procedures) — include a comment block: purpose, affected tables, run instructions, required env vars
- Include RUNSTATS recommendation comment after large INSERT/UPDATE/DELETE
- Never hardcode credentials or instance names
