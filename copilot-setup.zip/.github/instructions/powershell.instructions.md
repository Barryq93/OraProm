---
applyTo: "**/*.ps1,**/*.psm1,**/*.psd1,**/powershell/**,**/Powershell/**"
description: PowerShell monitoring scripts for Windows servers — PS 5.1 only
---

## Version
- Target: **PowerShell 5.1** (Windows PowerShell) — NOT PS 7
- No PS 7 syntax: no ternary (?:), no null coalescing (??), no parallel foreach
- `#Requires -Version 5.1` at the top of every script

## Logging
- Import AIB.Logging from the commons symlink in the script's directory:
  ```powershell
  Import-Module "$PSScriptRoot\commons\AIB.Logging"
  ```
- NEVER use Write-Host, Write-Output, Write-Verbose, Write-Warning, or Write-Error
- ALL output via: `Write-Log -Level {LEVEL} -Message {MESSAGE}`

## Style
- `[CmdletBinding()]` and `param()` block on every script
- PSScriptAnalyzer-compatible: no aliases, approved verbs
- `$PSScriptRoot` for all relative paths — never hardcode
- `try/catch` around all meaningful operations
- No hardcoded credentials, server names, or connection strings

## Return Object
```powershell
[PSCustomObject]@{
    Status     = 'OK'  # OK | WARN | CRITICAL | UNKNOWN | ERROR
    Message    = 'Description'
    Value      = $measuredValue
    Threshold  = $Threshold
    Server     = $TargetServer
    Timestamp  = (Get-Date -Format 'dd-MM-yy HH:mm:ss')
    ScriptName = $MyInvocation.MyCommand.Name
}
```

## Commons Symlink
- Always named `commons`, lives in the same directory as the script
- Create: `New-Item -ItemType SymbolicLink -Name commons -Target "C:\path\to\shared\lib"`
