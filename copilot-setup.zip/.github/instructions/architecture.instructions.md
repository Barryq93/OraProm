---
applyTo: "**/architecture/**,**/workingFolder/**"
description: Architecture design documents and draft decision records
---

## Diagrams
All design docs use MermaidJS. Choose by use case:
- `sequenceDiagram` — API flows, integration interactions
- `flowchart TD` — system topology, process flows
- `erDiagram` — DB2 schema documentation
- `classDiagram` — object/data model design
- `stateDiagram-v2` — document lifecycle, workflow states

Always offer a MermaidJS diagram when designing any flow or integration.

## ADR Format
```markdown
# [JIRA-XXX] Title

**Status**: Proposed | Accepted | Superseded by ADR-NNN
**Date**: DD-MM-YY
**Jira**: JIRA-XXX
**Mode**: Coding | Architecture | Research
**Component**: ECM | DB2 | Kofax | Observability | etc.

## Context
Why is this decision needed?

## Decision
What was decided?

## Consequences
Trade-offs, CM8/DB2 implications, operational impact.

## Diagram
(MermaidJS here)
```

## Promotion Pipeline
- `workingFolder/` = drafts in progress
- `architecture/` = promoted, accepted decisions
- Append `Promote to ADR?: yes/maybe/no` to `.copilot/thoughts.md` when creating docs
