---
applyTo: "**/runbook*,**/incident*,**/playbook*"
description: Runbook and incident playbook standards for the platform
---

## Writing Principle
Runbooks are used under pressure. Write for speed and clarity.
Every command must be specific and copy-pasteable.

---

## Runbook Structure

```markdown
# Runbook — [Component] [Incident Title]

**Severity**: P1 | P2 | P3
**Component**: ECM | DB2 | Kofax | WAS | Observability | Platform
**Platform**: Windows 2019/2022 | RHEL 8.1 | Both
**Last Updated**: DD-MM-YY
**Owner**: [team or person]
**Alert**: [Prometheus alert name, if applicable]

---

## Symptoms
- Prometheus alert name / Grafana panel
- User-reported symptoms
- Log patterns

---

## Immediate Actions (first 5 minutes)
Mark elevated access steps with 🔐
Mark irreversible steps with ⚠ IRREVERSIBLE

1.
2.

---

## Diagnostic Steps

### Check 1 — [Hypothesis]
[command]
Expected output if this is the cause:

---

## Resolution Procedures

### Option A — [Most common]
Steps...

### Option B — [Alternative]
Steps...

---

## Escalation Criteria
- [Condition] → Escalate to [person/team] via [channel]

---

## Post-Incident Checks
1.
2.

---

## Known Causes

| Date | Root Cause | Resolution | Notes |
|------|-----------|------------|-------|
| | No incidents recorded yet | | |
```

---

## Platform Diagnostic Commands

Include these in runbooks as needed.

### DB2 — RHEL 8.1
```bash
. ~/sqllib/db2profile
db2 list applications show detail
db2 get snapshot for locks on $DBNAME | grep -A5 "Lock wait"
db2 "SELECT SUBSTR(STMT_TEXT,1,80), ELAPSED_TIME_MIN, AGENT_ID
     FROM SYSIBMADM.LONG_RUNNING_SQL
     ORDER BY ELAPSED_TIME_MIN DESC FETCH FIRST 10 ROWS ONLY"
db2 "SELECT TBSP_NAME, TBSP_STATE,
     DECIMAL(FLOAT(TBSP_USED_PAGES)/FLOAT(TBSP_TOTAL_PAGES)*100,5,2) AS PCT_USED
     FROM SYSIBMADM.TBSP_UTILIZATION ORDER BY PCT_USED DESC"
cat ~/sqllib/db2dump/DIAG0000/db2diag.log | tail -100
```

### ECM / WAS — Windows
```powershell
Get-Service -DisplayName "WebSphere*" | Select-Object Name, Status
Get-Content "C:\...\SystemOut.log" -Tail 100
Invoke-WebRequest -Uri "http://ce-host:9080/wsi/FNCEWS40MTOM" -UseBasicParsing
```

### Kofax — Windows
```powershell
Get-Service -DisplayName "Kofax*" | Select-Object DisplayName, Status
Get-EventLog -LogName Application -Source "Kofax*" -Newest 50 |
    Select-Object TimeGenerated, EntryType, Message
Get-ChildItem "C:\Kofax\*" -Filter "*.log" |
    Sort-Object LastWriteTime -Descending | Select-Object -First 5
```

### Observability Stack
```bash
systemctl status alloy
journalctl -u alloy -n 100 --no-pager
curl http://pushgateway:9091/metrics | grep kofax_capture
curl http://prometheus:9090/api/v1/targets | python3 -m json.tool | grep -A3 "health"
curl http://loki:3100/ready
```

```powershell
Get-Service Alloy | Select-Object Status
Get-Content "C:\Program Files\GrafanaLabs\Alloy\alloy.log" -Tail 100
```

---

## Quality Checklist

- Every command is copy-pasteable, not illustrative
- All paths reflect actual install locations
- Escalation names real people or teams
- `runbook_url` in the alert rule points to this file
- Known Causes has at least "No incidents recorded yet"
- Irreversible steps marked ⚠ IRREVERSIBLE
- Elevated access steps marked 🔐
