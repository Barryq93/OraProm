---
applyTo: "**/*.sh,**/*.ksh,**/*.bash,**/shell/**"
description: General Linux shell scripts for RHEL 8.1
---

- Always start with `#!/usr/bin/env bash` and `set -euo pipefail`
- Log with DD-MM-YY HH:MM:SS timestamps:
  ```bash
  log() { echo "[$(date '+%d-%m-%y %H:%M:%S')] $*"; }
  ```
- Never hardcode credentials or hostnames — use environment variables
- UPPER_SNAKE_CASE for env/config variables
- Quote all variable expansions: "$VAR" not $VAR
- Idempotent where possible
- Comment block at top: purpose, usage, required env vars
