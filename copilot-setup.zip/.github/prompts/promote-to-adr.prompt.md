---
mode: ask
description: Promote a workingFolder draft or thoughts entry to a formal ADR in architecture/
---

Review the following draft or thoughts entry and produce a complete, polished
ADR ready to move to `architecture/`:

{{source_content_or_filename}}

Apply the standard ADR format from decisions.instructions.md:
- Status: Accepted
- Date in DD-MM-YY
- Include or improve the MermaidJS diagram
- Sharpen the Consequences section to reflect what was actually decided
- Filename: kebab-case, save to architecture/

After saving, append to `.copilot/changes.md` noting the promotion.
Update DECISIONS.md: change status on workingFolder entry to Accepted and update the index.
