---
mode: agent
description: Create a new runbook or incident playbook for the platform
---

Create a runbook for the following incident scenario: {{incident_scenario}}

Follow the runbook structure from runbook.instructions.md:
- Severity (P1/P2/P3), Component, Platform, Owner, Last Updated (DD-MM-YY)
- Symptoms section with Prometheus alert name if applicable
- Immediate Actions (first 5 minutes) — numbered, specific, copy-pasteable commands
- Diagnostic Steps organised by hypothesis
- Resolution Procedures (Option A / Option B)
- Escalation Criteria
- Post-Incident Checks
- Known Causes table (at minimum "No incidents recorded yet")

Mark irreversible steps with ⚠ IRREVERSIBLE.
Mark steps requiring elevated access with 🔐.
Include pre-built diagnostic commands from runbook.instructions.md where relevant.
Save to the appropriate directory and append to `.copilot/changes.md`.
