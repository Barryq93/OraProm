---
mode: agent
description: Scaffold a new DB2 shell script for CM8 database operations on RHEL 8.1
---

Scaffold a DB2 shell script that does the following: {{what_the_script_does}}

Requirements:
- `#!/usr/bin/env bash` + `set -euo pipefail`
- Source DB2 environment: `. ~/sqllib/db2profile`
- Log function with DD-MM-YY HH:MM:SS timestamps
- DB2 connection using env vars: $DATABASE, $DB_USER, $DB_PASSWORD
- Explicit connect and disconnect
- Return code check after every DB2 command
- DB2 11.5.9 syntax: FETCH FIRST n ROWS ONLY, CURRENT TIMESTAMP, ICMADMIN.<TABLE>
- Comment block at top: purpose, usage, required env vars
- No hardcoded credentials or instance names
