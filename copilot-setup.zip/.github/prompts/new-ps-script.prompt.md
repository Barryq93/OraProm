---
mode: agent
description: Scaffold a new PowerShell monitoring script using AIB.Logging and PS 5.1
---

Scaffold a PowerShell monitoring script that does the following: {{what_to_monitor}}

Requirements:
- `#Requires -Version 5.1` at the top
- Import AIB.Logging from `$PSScriptRoot\commons\AIB.Logging`
- Use `Write-Log -Level {LEVEL} -Message {MESSAGE}` — no Write-Host or Write-Error
- CmdletBinding + param block with at minimum: -TargetServer, -Threshold
- Wrap logic in try/catch with error logging
- Return [PSCustomObject] with: Status, Message, Value, Threshold, Server, Timestamp, ScriptName
- PSScriptAnalyzer-compatible (PS 5.1)
- Timestamp format: dd-MM-yy HH:mm:ss
