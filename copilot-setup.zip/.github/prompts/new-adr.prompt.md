---
mode: ask
description: Generate a new Architecture Decision Record for the CM8/platform environment
---

Create an Architecture Decision Record (ADR) for the following decision: {{decision_topic}}

Use this format:

```markdown
# [{{jira_number}}] {{decision_topic}}

**Status**: Proposed
**Date**: (today in DD-MM-YY)
**Jira**: {{jira_number}}
**Mode**: Architecture
**Component**: (ECM | DB2 | Kofax | Observability | Scripting | etc.)

## Context
Why is this decision needed? What constraints exist in the CM8/DB2/Kofax environment?

## Decision
What was decided?

## Consequences
Trade-offs, CM8 API or DB2 performance implications, operational impact.

## Diagram
(MermaidJS diagram — choose the most appropriate type for this decision)
```

Save to `workingFolder/` with a descriptive kebab-case filename.
Append to `.copilot/thoughts.md` with `Promote to ADR?: maybe`.
Update DECISIONS.md index and add a new ADR entry.
