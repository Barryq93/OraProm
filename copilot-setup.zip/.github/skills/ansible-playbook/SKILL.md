---
name: ansible-playbook
description: Create or review Ansible playbooks for platform configuration, CM8 setup, or DB2 tasks. Use when asked to automate server configuration or create Ansible tasks.
---

1. Always use FQCN: `ansible.builtin.copy`, `ansible.builtin.template`, etc.
2. All tasks must be idempotent
3. Variables in `vars/` or `group_vars/` — never hardcoded in task files
4. Sensitive values use `ansible-vault` — add comment `# vault-encrypted`
5. Use `become: true` at task level only
6. Include `tags:` on every task
7. Add `# Test with: ansible-playbook --check --diff` at top of every playbook
8. Group into roles when playbook exceeds ~20 tasks
9. YAML: 2-space indent, explicit string quoting where ambiguous
