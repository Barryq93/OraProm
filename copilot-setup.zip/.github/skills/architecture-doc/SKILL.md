---
name: architecture-doc
description: Create or update architecture design documents, ADRs, or system design diagrams for the CM8/DB2/Kofax platform. Use when asked to document a design decision, create a system diagram, or write up a technical design.
---

1. Always include at least one MermaidJS diagram. Choose by use case:
   - `sequenceDiagram` — API flows, system interactions
   - `flowchart TD` — process flows, system topology
   - `erDiagram` — DB2 schema or data model
   - `classDiagram` — object/data structure design
   - `stateDiagram-v2` — document lifecycle, workflow states

2. ADR format (see decisions.instructions.md for the full format)

3. New docs go to `workingFolder/` — only promote to `architecture/` when accepted

4. Always mention:
   - Which systems are involved (CM8 8.7.0 FP4, DB2 11.5.9, Kofax/TTA, Spring Boot)
   - Any DB2 or CM8 tablespace/performance implications
   - REST vs CMIS vs Java SDK — always REST or CMIS, never Java SDK

5. After creating, append to `.copilot/thoughts.md` with `Promote to ADR?: yes/maybe/no`

6. Update DECISIONS.md if a significant architectural choice was made
