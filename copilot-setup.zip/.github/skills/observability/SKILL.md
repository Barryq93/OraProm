---
name: observability
description: Design or build Prometheus metrics, Grafana Alloy River config, Pushgateway PowerShell integration, Loki log pipelines, or Prometheus alert rules for the CM8/DB2/Kofax/WAS platform. Use when asked about monitoring, metrics, alerting, dashboards, Grafana Alloy, Loki, Pushgateway, or Prometheus.
---

## Environment

- **OS mix**: Windows Server 2019/2022 (Kofax, WAS, ECM App Engine) | RHEL 8.1 (ECM Content Engine, DB2)
- **Metrics pipeline**: PowerShell scripts → Pushgateway → Prometheus → Grafana/Mimir
- **Logs**: Grafana Alloy → Loki (operational) + Splunk (compliance/SIEM)
- **Alloy syntax**: River `.alloy` files ONLY — never legacy Grafana Agent YAML format
- **PowerShell target**: 5.1 — use `Write-Log -Level {LEVEL} -Message {MESSAGE}` for all script logging
- **Alert routing label**: `team: documents` on all alert rules

---

## Metric Naming Convention

Format: `platform_component_measurement_unit`
All lowercase, underscores only, no hyphens.

| Component | Example Metric |
|-----------|---------------|
| CM8 Library Server | `cm_library_server_response_ms` |
| CM8 Resource Manager | `cm_resource_manager_response_ms` |
| DB2 Tablespace | `db2_tablespace_used_bytes{tablespace="USERSPACE1"}` |
| DB2 Lock Waits | `db2_lock_waits_active_total` |
| DB2 Log Utilisation | `db2_log_utilisation_pct` |
| Kofax Batch Queue | `kofax_capture_batch_queue_depth_total{state="error"}` |
| WAS JVM Heap | `was_jvm_heap_used_pct{host="HOST"}` |
| Windows Service | `windows_service_up{service="KofaxCapture",host="HOST"}` — 1=up, 0=down |

**Standard labels on all metrics**: `host`, `environment`, `component`, `platform`

---

## Pushgateway PowerShell Integration

Use this function pattern in every monitoring script that pushes to Prometheus.
Place it in the `commons` shared library and import via `$PSScriptRoot\commons\AIB.Observability`.

```powershell
#Requires -Version 5.1

function Push-MetricToGateway {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]  [string]$PushgatewayUrl,
        [Parameter(Mandatory=$true)]  [string]$JobName,
        [Parameter(Mandatory=$true)]  [string]$MetricName,
        [Parameter(Mandatory=$true)]  [double]$Value,
        [Parameter(Mandatory=$false)] [hashtable]$Labels = @{},
        [Parameter(Mandatory=$false)] [ValidateSet("gauge","counter")] [string]$Type = "gauge",
        [Parameter(Mandatory=$false)] [string]$Help = ""
    )

    # Build label grouping path for the Pushgateway URL
    $labelPath = ($Labels.GetEnumerator() | ForEach-Object { "$($_.Key)/$($_.Value)" }) -join "/"
    $uri = "$PushgatewayUrl/metrics/job/$JobName"
    if ($labelPath) { $uri = "$uri/$labelPath" }

    # Build Prometheus text exposition format
    $labelStr = ($Labels.GetEnumerator() | ForEach-Object { '$(' + $_.Key + ')="' + $_.Value + '"'  }) -join ","
    $metricLine = if ($labelStr) { "${MetricName}{${labelStr}} $Value" } else { "$MetricName $Value" }
    $payload = "# HELP $MetricName $Help`n# TYPE $MetricName $Type`n${metricLine}`n"

    try {
        Invoke-RestMethod -Uri $uri -Method Post -Body $payload `
            -ContentType "text/plain; charset=utf-8" -UseBasicParsing
        Write-Log -Level INFO -Message "Metric pushed: $MetricName=$Value to $JobName"
    }
    catch {
        Write-Log -Level ERROR -Message "Pushgateway push failed for ${MetricName}: $_"
    }
}

function Remove-PushgatewayJob {
    <#
    .SYNOPSIS
        Delete all metrics for a completed one-shot job.
        MANDATORY after every one-shot script run — stale metrics persist otherwise.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)] [string]$PushgatewayUrl,
        [Parameter(Mandatory=$true)] [string]$JobName
    )
    try {
        Invoke-RestMethod -Uri "$PushgatewayUrl/metrics/job/$JobName" `
            -Method Delete -UseBasicParsing
        Write-Log -Level INFO -Message "Pushgateway job deleted: $JobName"
    }
    catch {
        Write-Log -Level WARN -Message "Failed to delete Pushgateway job ${JobName}: $_"
    }
}
```

**Critical Pushgateway rules**:
- Always call `Remove-PushgatewayJob` after a completed one-shot job — stale metrics persist until the next scrape otherwise
- Use `gauge` for point-in-time values (queue depth, heap, disk, response time)
- Use `counter` only for monotonically increasing values (total batches processed, total errors)
- `honor_labels: true` on the Pushgateway scrape target in Alloy — this is not optional
- One `$JobName` per monitoring script — never reuse a job name across unrelated scripts
- Never hardcode `$PushgatewayUrl` — pass as parameter or read from env var

---

## Grafana Alloy River Syntax Patterns

Always use River syntax `.alloy` files. Never use the legacy YAML Grafana Agent format.
Credentials and endpoints always via `env()` — never hardcoded.

```alloy
// ============================================================
// Scrape: Pushgateway (Windows PowerShell monitoring scripts)
// ============================================================
prometheus.scrape "pushgateway" {
  targets = [{ __address__ = env("PUSHGATEWAY_HOST") }]
  scrape_interval = "60s"
  honor_labels    = true  // CRITICAL: preserves job/instance labels pushed by scripts
  forward_to      = [prometheus.remote_write.mimir.receiver]
}

// ============================================================
// Scrape: Windows hosts via windows_exporter
// ============================================================
prometheus.scrape "windows_hosts" {
  targets = [
    { __address__ = "kofax-host-01:9182",  component = "kofax", platform = "windows" },
    { __address__ = "ecm-appeng-01:9182",   component = "ecm",   platform = "windows" },
  ]
  scrape_interval = "60s"
  forward_to      = [prometheus.remote_write.mimir.receiver]
}

// ============================================================
// Scrape: Linux hosts via node_exporter (ECM CE, DB2)
// ============================================================
prometheus.scrape "linux_hosts" {
  targets = [
    { __address__ = "ecm-ce-01:9100",  component = "ecm", platform = "linux" },
    { __address__ = "db2-host-01:9100", component = "db2", platform = "linux" },
  ]
  scrape_interval = "30s"
  forward_to      = [prometheus.remote_write.mimir.receiver]
}

// ============================================================
// Logs: Windows Event Log → Loki (Kofax Application events)
// ============================================================
loki.source.windowsevent "kofax_app_log" {
  eventlog_name         = "Application"
  use_incoming_timestamp = false
  forward_to            = [loki.write.default.receiver]
  labels = {
    job       = "windows_eventlog",
    component = "kofax",
    platform  = "windows",
  }
}

// ============================================================
// Remote write — Mimir
// ============================================================
prometheus.remote_write "mimir" {
  endpoint {
    url = env("MIMIR_REMOTE_WRITE_URL")
    basic_auth {
      username = env("MIMIR_USERNAME")
      password = env("MIMIR_PASSWORD")
    }
  }
}

// ============================================================
// Remote write — Loki
// ============================================================
loki.write "default" {
  endpoint {
    url = env("LOKI_PUSH_URL")
  }
}
```

**Alloy rules**:
- Never hardcode URLs, credentials, or hostnames — always `env()`
- `honor_labels = true` on every Pushgateway scrape — non-negotiable
- One `forward_to` chain per signal type — never mix metric and log receivers
- Label at collection time; avoid relabelling post-collection where possible
- One `.alloy` file per host or logical grouping — do not create monolithic configs

---

## Prometheus Alert Rule Standards

```yaml
# alert-rules-documents-platform.yml
groups:
  - name: documents.platform.critical
    rules:
      - alert: DB2TablespaceHighUsage
        expr: db2_tablespace_used_bytes / db2_tablespace_total_bytes * 100 > 85
        for: 5m
        labels:
          severity: critical
          component: db2
          team: documents
        annotations:
          summary: "DB2 tablespace {{ $labels.tablespace }} critically high on {{ $labels.host }}"
          description: >
            Tablespace {{ $labels.tablespace }} on {{ $labels.host }} is
            {{ $value | humanizePercentage }} used. Investigate and extend if required.
          runbook_url: "https://wiki.internal/runbooks/db2-tablespace"

      - alert: KofaxBatchQueueDepthHigh
        expr: kofax_capture_batch_queue_depth_total{state="error"} > 500
        for: 10m
        labels:
          severity: warning
          component: kofax
          team: documents
        annotations:
          summary: "Kofax error batch queue elevated on {{ $labels.host }}"
          description: >
            {{ $value }} batches in error state on {{ $labels.host }}.
            Threshold: 500 warn / 1000 critical.
          runbook_url: "https://wiki.internal/runbooks/kofax-batch-queue"

      - alert: WindowsServiceDown
        expr: windows_service_up == 0
        for: 2m
        labels:
          severity: critical
          component: platform
          team: documents
        annotations:
          summary: "Service {{ $labels.service }} is DOWN on {{ $labels.host }}"
          description: "Windows service {{ $labels.service }} has been down for more than 2 minutes."
          runbook_url: "https://wiki.internal/runbooks/windows-service-down"
```

**Alert rule standards**:
- Always include `for:` — no instant-fire alerts on transient spikes
- Always include `runbook_url` annotation pointing to an actual runbook
- `severity` values: `critical`, `warning`, `info` — consistent across all rules
- `team: documents` label on every rule for routing
- Humanize values in descriptions: `humanize`, `humanizePercentage`, `humanizeDuration`
- Use `rate()` for dashboard trend panels; `irate()` only for sudden-spike alerting
- Use recording rules for any expression used in both a dashboard and an alert rule

---

## Grafana Dashboard Conventions

- Dashboard titles: "[Component] Health" or "[Component] Overview"
  — e.g. "DB2 Tablespace Health", "Kofax Capture Pipeline", "CM8 Response Times"
- All dashboards must have template variables: `component`, `environment`, `host`
- Never hardcode the datasource UID — always use a datasource template variable
- Panel titles describe what is measured: "Tablespace Used %" not "db2_ts_used/total*100"
- Gauge and stat panel thresholds must match the corresponding alert rule thresholds exactly
- Tag all dashboards: `documents-platform`, `sre`, and the component name
- Include a "Last data received" stat panel so operators can confirm Alloy/Pushgateway is live
- Stat panels for service up/down: green=1 (up), red=0 (down) — no ambiguity
