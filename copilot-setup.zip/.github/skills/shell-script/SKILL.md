---
name: shell-script
description: Scaffold or review a Linux shell script for DB2 operations or general platform tasks on RHEL 8.1. Use when asked to create, fix, or improve a shell or bash script.
---

1. Always start with:
   ```bash
   #!/usr/bin/env bash
   set -euo pipefail
   ```
2. Log with timestamps in DD-MM-YY format:
   ```bash
   log() { echo "[$(date '+%d-%m-%y %H:%M:%S')] $*"; }
   ```
3. For DB2 scripts:
   - Use environment variables: `$DATABASE`, `$DB_USER`, `$DB_PASSWORD`
   - Source DB2 environment first: `. ~/sqllib/db2profile`
   - Connect and disconnect explicitly
   - Check return codes after every DB2 command
   - Qualify CM8 tables as `ICMADMIN.<TABLE>`
   - Target DB2 LUW 11.5.9 syntax only
4. Quote all variable expansions
5. Never hardcode credentials, hostnames, or instance names
6. Add a comment block at top: purpose, usage, required env vars

DB2 script skeleton:
```bash
#!/usr/bin/env bash
set -euo pipefail

# Purpose: <describe purpose>
# Usage: DATABASE=<db> DB_USER=<user> DB_PASSWORD=<pass> ./script.sh
# Required env vars: DATABASE, DB_USER, DB_PASSWORD

log() { echo "[$(date '+%d-%m-%y %H:%M:%S')] $*"; }

. ~/sqllib/db2profile

log "Connecting to $DATABASE"
db2 connect to "$DATABASE" user "$DB_USER" using "$DB_PASSWORD"

# Main logic here

db2 connect reset
log "Done"
```
