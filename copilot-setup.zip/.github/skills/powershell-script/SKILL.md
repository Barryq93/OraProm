---
name: powershell-script
description: Scaffold or review a PowerShell monitoring script for Windows servers using AIB.Logging and PS 5.1. Use when asked to create, fix, or improve a PowerShell script.
---

1. Start with `#Requires -Version 5.1` — PS 7 syntax is never used
2. Import AIB.Logging from the commons symlink:
   ```powershell
   Import-Module "$PSScriptRoot\commons\AIB.Logging"
   ```
3. Never use Write-Host, Write-Output, Write-Warning, Write-Error, or Write-Verbose
   — all output goes through `Write-Log -Level {LEVEL} -Message {MESSAGE}`
4. Every script must have `[CmdletBinding()]` and a `param()` block
5. Wrap meaningful operations in try/catch; log errors with `Write-Log -Level ERROR`
6. Return a `[PSCustomObject]` with: Status (OK/WARN/CRITICAL/UNKNOWN), Message, Value, Threshold, Server, Timestamp, ScriptName
7. Use `$PSScriptRoot` for all path references — no hardcoded paths
8. No hardcoded credentials, server names, or paths — use parameters
9. PSScriptAnalyzer-compatible: no aliases, approved verbs, no positional parameters

Skeleton:
```powershell
#Requires -Version 5.1
Import-Module "$PSScriptRoot\commons\AIB.Logging"

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]  [string]$TargetServer,
    [Parameter(Mandatory=$false)] [int]$Threshold = 80
)

try {
    Write-Log -Level INFO -Message "Starting on $TargetServer"

    # Main logic here

    Write-Log -Level INFO -Message "Completed successfully"
    return [PSCustomObject]@{
        Status     = 'OK'
        Message    = 'Description of result'
        Value      = $null
        Threshold  = $Threshold
        Server     = $TargetServer
        Timestamp  = (Get-Date -Format 'dd-MM-yy HH:mm:ss')
        ScriptName = $MyInvocation.MyCommand.Name
    }
}
catch {
    Write-Log -Level ERROR -Message "Failed on $TargetServer`: $_"
    return [PSCustomObject]@{
        Status     = 'ERROR'
        Message    = $_.Exception.Message
        Value      = $null
        Threshold  = $Threshold
        Server     = $TargetServer
        Timestamp  = (Get-Date -Format 'dd-MM-yy HH:mm:ss')
        ScriptName = $MyInvocation.MyCommand.Name
    }
}
```
