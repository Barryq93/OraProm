---
name: db2-health-check
description: Generate DB2 health check or diagnostic scripts for CM8 — tablespace monitoring, lock analysis, log space, bufferpool, connection counts. Use when asked about DB2 health, monitoring, diagnostics, or performance.
---

Target: IBM DB2 LUW 11.5.9 only. Flag anything requiring a higher fix pack.

Coverage areas (generate based on what is asked):
- **Tablespace utilisation**: SYSCAT.TABLESPACES, MON_GET_TABLESPACE
- **Active connections**: MON_GET_CONNECTION
- **Lock waits**: MON_GET_LOCKS, MON_GET_APPL_LOCKWAIT
- **Log utilisation**: MON_GET_TRANSACTION_LOG
- **Bufferpool hit ratios**: MON_GET_BUFFERPOOL
- **Long-running queries**: SYSIBMADM.LONG_RUNNING_SQL
- **CM8-specific tables**: ICMADMIN.ICMUT00100, ICMADMIN.ICMFILESEG, ICMADMIN.RMOBJECTS

Rules:
1. Define thresholds as variables at the top of any shell wrapper
2. Use `db2 -x` for scriptable output
3. Credentials from env vars: `$DATABASE`, `$DB_USER`, `$DB_PASSWORD`
4. Source DB2 environment: `. ~/sqllib/db2profile`
5. Log with DD-MM-YY HH:MM:SS timestamps
6. Check return codes after every DB2 command
7. Include comments noting CM8 impact for tablespace or storage queries
8. SQL must use DB2 11.5.9 syntax: `FETCH FIRST n ROWS ONLY`, `CURRENT TIMESTAMP`, schema-qualified tables
