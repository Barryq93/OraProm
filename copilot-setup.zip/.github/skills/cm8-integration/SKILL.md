---
name: cm8-integration
description: Help design or document CM8 REST API or CMIS 1.0 integrations, Spring Boot service patterns, or document workflow flows. Use when asked about CM8 APIs, item types, object stores, or document workflows.
---

This is IBM Content Manager EE 8.7.0 FP4 — NOT FileNet P8.
Never use com.filenet.api.* or P8/FileNet terminology.

## API References
- CM8 REST API: https://www.ibm.com/docs/en/content-manager/8.7.0?topic=support-rest-api-documentation
- CMIS 1.0: https://docs.oasis-open.org/cmis/CMIS/v1.0/cmis-spec-v1.0.html
- Always prefer REST or CMIS — never suggest the FileNet Java API

## Spring Boot — Design & Review Only
Role is architecture, API contract design, and code review.
The development team owns implementation. Never produce implementation controller/service/repository code.

## Key Integration Patterns (for design review)
- Base path: `/cm8app/cm8rest/v1/`
- Auth: Bearer token (JWT) — token refresh is mandatory; tokens expire ~30 min
- PID handling: PIDs contain spaces — must be URL-encoded before use in path
- Query limit: Always set `limit` explicitly; never use `limit=0` in production (returns all items, exhausts memory)
- Multipart ordering: attributes JSON array MUST come before file streams — common failure point
- CMIS: Use for BAW integration only; CMIS 1.0 does not support multi-part content or annotations

## Common Failure Patterns to Flag in Review
1. Token not refreshed — 401 mid-session
2. Multipart form: file streams sent before attributes JSON
3. PID not URL-encoded — spaces cause 400
4. Item type name case mismatch — Library Server returns "not found" silently
5. Query with no limit — hangs on large repositories
6. Content URL cached — RM token in part URL is time-limited, must be fetched immediately

## When Designing Flows
- Always produce a MermaidJS sequenceDiagram showing the integration
- Label each step with HTTP method and endpoint
- Show error/fault paths as well as happy path
- Note any DB2/tablespace implications for bulk document operations
