# Workspace Context

## Role
Platform Engineer / SRE / Solution Architect in enterprise document management.
Primary focus: scripting, system operations, and solution design — not deep application development.

## Primary Systems
- **IBM Content Manager EE 8.7.0 FP4** (CM8)
  — This is CM8 EE, NOT FileNet P8. Never suggest com.filenet.api.* or P8 terminology.
  — REST API: https://www.ibm.com/docs/en/content-manager/8.7.0?topic=support-rest-api-documentation
  — CMIS 1.0: https://docs.oasis-open.org/cmis/CMIS/v1.0/cmis-spec-v1.0.html
  — Always use REST or CMIS. Never the FileNet Java API.
- **DB2 LUW 11.5.9** — backing database for CM8. All SQL must target 11.5.9 exactly.
- **Kofax Capture / Tungsten Total Agility** — document capture, integration server on-prem
- **Spring Boot Microservices** — support and design only; not implementation
- **Windows Server 2019/2022** — hosts PowerShell monitoring; PS 5.1 target
- **RHEL 8.1** — hosts DB2 and ECM Content Engine; bash scripts here

## Folder Structure
- `architecture/`  — promoted design docs (MD + MermaidJS); source of truth
- `git/`           — active repos: PS monitoring, Ansible, SQL, Spring Boot
- `powershell/`    — standalone Windows monitoring scripts
- `shell/`         — general Linux shell scripts
- `db2/`           — DB2-specific shell scripts
- `python/`        — simple utility scripts
- `workingFolder/` — draft design decisions not yet promoted to architecture/

## Date Format
Always DD-MM-YY HH:MM (Irish format) in all generated content, logs, comments, ADRs.
Example: 06-05-26 11:45

## Sensitive Values — Never Hardcode
DB2 credentials, CM8 server hostnames, connection strings, tokens.
Always use environment variables or a config parameter with a comment.

## General Behaviour
- Prefer working output over explanation unless asked otherwise
- For DB2 tasks, note impact on CM8 tablespaces where relevant
- When designing flows, always offer a MermaidJS diagram
- PS 7 syntax must never be used — target is PS 5.1 only
- DB2 12.x syntax must never be used — target is 11.5.9

---

## Session Logging — MANDATORY

After every agent interaction where code, scripts, configs, or docs are created or modified,
append entries to `.copilot/changes.md` and `.copilot/thoughts.md` IF a `.copilot/` folder
exists in the current working directory or any parent directory.

**How to find it**: walk up from the file being edited until you find `.copilot/`. If none
exists anywhere in the path, skip logging silently — do NOT create one.

### Append to `.copilot/changes.md`

```
## [DD-MM-YY HH:MM] — <one-line summary>

**Files affected**: list each file
**What changed**: brief description
**Why**: problem it solves or reason for change
**Alternatives rejected**: options considered and why rejected
**Caveats**: known limitations, follow-up needed, or risks

---
```

### Append to `.copilot/thoughts.md`

```
## [DD-MM-YY HH:MM] — <one-line summary>

**Context**: what was being worked on and why
**Reasoning**: thought process behind the approach
**Open questions**: anything unresolved or worth revisiting
**Promote to ADR?**: yes / no / maybe — one line reason

---
```

### Logging Rules
- Always append — never overwrite
- Be specific: reference actual filenames, function names, DB2 tables, CM8 endpoints
- Trivial changes still get logged briefly
- `Promote to ADR?` signals whether to move the decision to `workingFolder/` or `architecture/`
