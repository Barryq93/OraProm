# Decisions Log

This file records all significant technical decisions made in this project.
Generated and maintained by GitHub Copilot under principal engineer guidance.
Last updated: 2025-01-01

---

## Index

| ADR | Title | Component | Status | Date |
|-----|-------|-----------|--------|------|
| ADR-001 | ECM API pinned to P8 Java API (not Content Services) | ECM | Accepted | 2025-01-01 |
| ADR-002 | DB2 target version pinned to 11.5.9 LUW | DB2 | Accepted | 2025-01-01 |
| ADR-003 | PowerShell target runtime is 5.1 (not 7+) | Scripting | Accepted | 2025-01-01 |
| ADR-004 | Pushgateway as Windows-to-Prometheus bridge | Observability | Accepted | 2025-01-01 |
| ADR-005 | Spring Boot scope limited to architecture and design only | Architecture | Accepted | 2025-01-01 |
| ADR-006 | Grafana Alloy using River syntax (.alloy files) | Observability | Accepted | 2025-01-01 |
| ADR-007 | Splunk and Loki co-exist with separate responsibilities | Observability | Accepted | 2025-01-01 |

---

## Decisions

---

## ADR-007: Splunk and Loki co-exist with separate responsibilities

**Date:** 2025-01-01
**Status:** Accepted
**Mode:** Architecture
**Component:** Observability

### Context
Both Splunk and Loki are present in the environment. A decision was needed on
whether to consolidate or maintain both, and what each is responsible for.

### Decision
Splunk handles compliance, audit, and SIEM workloads. Loki handles operational
observability (dashboard-linked log queries, alerting, incident investigation).

### Reasoning
- Option chosen: Co-exist with defined boundaries — Splunk is already established
  for compliance and cannot be replaced due to regulatory requirements. Loki is
  lower-cost for high-volume operational logs and integrates natively with Grafana.
- Option rejected: Splunk-only — cost-prohibitive for high-volume operational logs
  at Splunk ingest pricing.
- Option rejected: Loki-only — Splunk is a compliance requirement, not optional.

### Consequences
Two log pipelines to maintain. Engineers must know which system to query for which
purpose. Alloy config must route to both where required.

### References
- Internal: observability.instructions.md — Splunk/Loki co-existence section

---

## ADR-006: Grafana Alloy using River syntax (.alloy files)

**Date:** 2025-01-01
**Status:** Accepted
**Mode:** Architecture
**Component:** Observability

### Context
Grafana has released multiple agents: original Grafana Agent (YAML), Grafana Agent
Flow (River syntax), and Grafana Alloy (successor, River syntax). The project
needed to standardise on one.

### Decision
All Alloy configuration uses River syntax in `.alloy` files. Legacy Grafana Agent
YAML format is not used.

### Reasoning
- Option chosen: Grafana Alloy (River syntax) — current actively maintained product,
  component-based pipeline model is more maintainable than monolithic YAML scrape configs.
- Option rejected: Grafana Agent YAML — deprecated, being phased out by Grafana Labs.
- Option rejected: Prometheus scrape configs directly — no log collection capability.

### Consequences
Engineers must learn River syntax. Copilot must not produce legacy YAML Agent config.
`.alloy` file extension must be associated with HCL in VS Code for syntax highlighting.

### References
- [Grafana Alloy documentation](https://grafana.com/docs/alloy/latest/)
- [Migration guide from Agent to Alloy](https://grafana.com/docs/alloy/latest/migrate/)

---

## ADR-005: Spring Boot scope limited to architecture and design only

**Date:** 2025-01-01
**Status:** Accepted
**Mode:** Architecture
**Component:** Architecture

### Context
Spring Boot microservices exist in the wider documents domain. The SRE/DBA/Architect
role involves designing these services but a separate development team owns implementation.

### Decision
All Spring Boot outputs are limited to: API contracts (OpenAPI), component diagrams,
integration patterns, deployment topology, and security model. No implementation code.

### Reasoning
- Prevents creating confusion or conflict with the development team's implementation choices.
- Architecture artefacts are the correct deliverable for this role.
- Implementation code produced outside the dev team's patterns would introduce inconsistency.

### Consequences
Any request for Spring Boot controller/service/repository code must be redirected to
the development team. Design artefacts (OpenAPI specs, ADRs, HLDs) are in scope.

### References
- Internal: architect.instructions.md — Spring Boot scope boundary section

---

## ADR-004: Pushgateway as Windows-to-Prometheus bridge

**Date:** 2025-01-01
**Status:** Accepted
**Mode:** Architecture
**Component:** Observability

### Context
Kofax Capture, WAS, and ECM App Engine run on Windows Server. Prometheus scrapes
via pull model. Windows hosts run PowerShell monitoring scripts on a schedule
(not persistent exporters for all metrics).

### Decision
PowerShell monitoring scripts push metrics to Pushgateway using HTTP POST in
Prometheus text format. Prometheus scrapes Pushgateway on its standard interval.

### Reasoning
- Option chosen: Pushgateway — decouples script execution schedule from Prometheus
  scrape interval. Scripts can be one-shot scheduled tasks without running a persistent process.
- Option rejected: windows_exporter only — doesn't cover application-level metrics
  (Kofax queue depth, ECM response time) without custom collectors.
- Option rejected: Prometheus remote_write from PowerShell — more complex, requires
  persistent HTTP listener, overkill for scheduled monitoring scripts.

### Consequences
Stale metrics risk if DELETE is not called after one-shot jobs. `honor_labels = true`
is mandatory on the Pushgateway scrape target. Pushgateway is a single point of failure
for all Windows-origin metrics.

### References
- [Pushgateway best practices](https://prometheus.io/docs/practices/pushing/)
- Internal: observability.instructions.md — Pushgateway integration section

---

## ADR-003: PowerShell target runtime is 5.1 (not 7+)

**Date:** 2025-01-01
**Status:** Accepted
**Mode:** Coding
**Component:** Scripting

### Context
Scripts run on Windows Server 2019 and 2022. PowerShell 7+ is available but not
universally deployed. Scripts must run reliably on all hosts without a pre-installation step.

### Decision
All PowerShell scripts target PS 5.1 (Windows PowerShell). PS 7+ features must not
be used unless the script is explicitly marked as PS 7+ only.

### Reasoning
- Windows Server 2019/2022 ships with PS 5.1 by default.
- PS 7+ must be explicitly installed — not guaranteed on all hosts.
- PS 5.1 is sufficient for all current scripting requirements.

### Consequences
PS 7+ syntax (parallel foreach, ternary operators, null coalescing) must not be used.
PSScriptAnalyzer is configured to enforce PS 5.1 compatibility.
If PS 7+ is needed for a specific script, it must be documented in the script header.

### References
- [PowerShell compatibility table](https://learn.microsoft.com/en-us/powershell/scripting/whats-new/differences-from-windows-powershell)
- Internal: powershell.instructions.md

---

## ADR-002: DB2 target version pinned to 11.5.9 LUW

**Date:** 2025-01-01
**Status:** Accepted
**Mode:** Coding
**Component:** DB2

### Context
The ECM platform uses DB2 LUW. The installed version is 11.5.9. Some DB2 features,
syntax, and behaviour differ across fix packs and major versions.

### Decision
All DB2 SQL, scripts, and tooling targets DB2 LUW 11.5.9 exactly.
Any syntax or feature requiring a higher fix pack must be explicitly flagged.

### Reasoning
- Ensures generated SQL runs on the actual instance without silent incompatibilities.
- DB2 12.x has syntax differences that would produce runtime errors on 11.5.9.
- Fix pack-specific features have been a source of production issues historically.

### Consequences
Must flag when using features that were introduced after 11.5.9.
Version must be re-evaluated when the DB2 instance is upgraded.

### References
- [IBM DB2 11.5 documentation](https://www.ibm.com/docs/en/db2/11.5)
- [DB2 fix pack history](https://www.ibm.com/support/pages/db2-distributed-fix-pack-centralized-page)

---

## ADR-001: ECM API pinned to P8 Java API (not Content Services)

**Date:** 2025-01-01
**Status:** Accepted
**Mode:** Architecture
**Component:** ECM

### Context
IBM FileNet Content Manager 8.7.4 supports both the legacy P8 Java API and the
newer Content Services REST/GraphQL API introduced in later versions. Code must
work with the installed 8.7.4 version.

### Decision
All ECM code uses the P8 Java API (`com.filenet.api.*`). Content Services GraphQL
or REST APIs are not used unless explicitly requested and version-verified.

### Reasoning
- ECM 8.7.4 does not fully support Content Services API features available in later versions.
- P8 Java API is stable, well-documented, and supported for 8.7.4.
- Using newer APIs risks runtime failures on the actual installed version.

### Consequences
Generated ECM code uses `Factory.*` pattern and P8 connection model.
Must be re-evaluated when ECM is upgraded beyond 8.7.4.

### References
- [IBM FileNet P8 8.7.4 Java API documentation](https://www.ibm.com/docs/en/filenet-p8-platform/5.5.x)
- [IBM ECM compatibility matrix](https://www.ibm.com/support/pages/ibm-filenet-content-manager-detailed-system-requirements)
