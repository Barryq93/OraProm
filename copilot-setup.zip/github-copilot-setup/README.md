# GitHub Copilot Setup — Documents Platform

Principal engineer configuration for VS Code GitHub Copilot.
Derived from the Teams custom instruction — decomposed into a layered skill system.

**Environment:** Windows Server 2019/2022 + RHEL 8.1
**Stack:** IBM ECM 8.7.4, DB2 11.5.9, Kofax Capture/KTM/RTTI, WAS, Prometheus, Grafana Alloy, Loki, Splunk

---

## Directory Structure

```
.
├── README.md                                # This file
├── DECISIONS.md                             # ★ Persistent decisions log — all ADRs
├── .vscode/
│   ├── settings.json                        # VS Code + Copilot workspace settings
│   └── PSScriptAnalyzerSettings.psd1        # PSScriptAnalyzer rules (PS 5.1 target)
│
└── .github/
    ├── copilot-instructions.md              # ★ Always-on: persona, stack, version pins, global rules
    │
    ├── instructions/                        # Skill files — behavioural overlays
    │   │
    │   │── ALWAYS ACTIVE (applyTo: "**") ─────────────────────────────────
    │   ├── tech-lead.instructions.md        # 🧠 Orchestrator: auto-mode, delegation, self-review
    │   ├── context-memory.instructions.md   # 🔄 Context pulse, drift detection, checkpoints
    │   ├── code-review.instructions.md      # 👁  Passive review lens — active on all code
    │   ├── security.instructions.md         # 🔒 Security rules — always enforced
    │   ├── decisions.instructions.md        # 📓 DECISIONS.md format and update rules
    │   │
    │   │── AUTO-ACTIVATES ON FILE TYPE ────────────────────────────────────
    │   ├── powershell.instructions.md       # ⚙️  .ps1/.psm1/.psd1 — PS 5.1, headers, Kofax COM
    │   ├── shell.instructions.md            # 🐚 .sh/.ksh/.bash — DB2 shell patterns, RHEL 8.1
    │   ├── db2-dba.instructions.md          # 🗄️  .sql/.db2/.ddl — DB2 11.5.9 LUW standards
    │   ├── observability.instructions.md    # 📊 .alloy/.promql/alert*.yml — metrics, Alloy, Loki
    │   ├── github-actions.instructions.md   # 🔁 .github/workflows/*.yml — CI/CD pipelines
    │   ├── ansible.instructions.md          # 📦 playbooks/**/*.yml — mixed Windows/Linux roles
    │   │
    │   │── MANUALLY REFERENCE ─────────────────────────────────────────────
    │   ├── ecm.instructions.md              # 📄 ECM 8.7.4 P8 Java API, ICN, Kofax integration
    │   ├── hld.instructions.md              # 📐 HLD structure, Mermaid diagrams, ADR format
    │   ├── sre-monitoring.instructions.md   # 🚨 Monitoring standards, thresholds, Splunk patterns
    │   ├── runbook.instructions.md          # 📋 Runbook format, platform diagnostic commands
    │   └── architect.instructions.md        # 🏗️  Design principles, Spring Boot scope boundary
    │
    └── workflows/                           # Invokable task workflows (.prompt.md)
        ├── feature-build.prompt.md          # End-to-end: clarify → plan → implement → review
        ├── hld-build.prompt.md              # Full HLD production (all 15 sections)
        ├── bug-investigation.prompt.md      # Investigation → fix → RCA
        ├── code-review.prompt.md            # Full structured review: security + domain + quality
        ├── sre-incident.prompt.md           # Live incident triage → resolution → PIR
        ├── observability-build.prompt.md    # Alerts, dashboards, Alloy config, Pushgateway
        ├── refactor.prompt.md               # Safe refactor with behaviour preservation
        └── db2-migration.prompt.md          # Schema/data migration with mandatory safeguards
```

---

## How the Layers Work

```
copilot-instructions.md       Always loaded. Stack context, version pins, persona, global rules.

instructions/*.md              Behavioural overlays. Auto-load by file type or manually reference.
                               tech-lead + context-memory + code-review + security + decisions
                               = always active on every response.

workflows/*.prompt.md          Invokable multi-step task definitions. Reference in Copilot Chat.
                               All active instruction files are in scope when a workflow runs.
```

---

## Auto Mode Detection

Copilot infers the mode from your prompt — you never need to specify it:

| Prompt signals | Mode applied |
|---|---|
| write / build / fix / script / create / configure | **Coding** |
| design / architect / plan / HLD / evaluate / diagram | **Architecture** |
| what is / explain / compare / research / investigate | **Research** |

Mixed signals → dominant mode leads, blend noted in response.

---

## Persistent Files (maintained automatically)

| File | What it tracks |
|---|---|
| `DECISIONS.md` | All significant technical decisions — why, what was rejected, references |
| `README.md` (this file) | Project structure and usage |
| `README.md` (per directory) | Created/updated after any file work in that directory |

---

## Quick Reference — Workflows

| Situation | Use |
|---|---|
| Building a new feature | `#feature-build.prompt.md` |
| Building an HLD | `#hld-build.prompt.md` |
| Building alerts / dashboards | `#observability-build.prompt.md` |
| Investigating a bug | `#bug-investigation.prompt.md` |
| Live incident | `#sre-incident.prompt.md` |
| Reviewing code | `#code-review.prompt.md` |
| Safe refactor | `#refactor.prompt.md` |
| DB2 schema / data migration | `#db2-migration.prompt.md` |

---

## Observability — Metric Naming Convention

```
<platform>_<component>_<measurement>_<unit>

ecm_was_jvm_heap_used_bytes
db2_tablespace_used_bytes{tablespace, instance}
kofax_capture_batch_queue_depth_total{state}
windows_service_up{service, host}
```

Standard labels on all metrics: `host`, `environment`, `component`, `platform`

---

## Always-Active Rules

- Mode auto-detected — never specify it manually
- README.md created/updated after any file work
- DECISIONS.md updated after any significant technical choice
- Every script has a header block
- Every response has a self-review block
- All SQL parameterised
- No hard-coded secrets
- Version-pinned: ECM 8.7.4, DB2 11.5.9 LUW, PS 5.1, RHEL 8.1

---

## Maintenance

When Copilot gives a poor output, update the relevant skill file rather than re-prompting.
Review trigger: after any platform change (ECM fix pack, DB2 upgrade, Kofax version change).
