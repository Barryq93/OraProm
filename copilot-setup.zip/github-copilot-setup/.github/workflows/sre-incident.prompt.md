---
mode: agent
description: Live incident response workflow for the documents platform
tools: [codebase, terminalLastCommand, readFile]
---

# SRE Incident Response Workflow

Time matters during incidents. This workflow is structured for speed and clarity.
Apply sre-monitoring.instructions.md and the relevant domain skill throughout.

## Step 1 — Triage (first 2 minutes)
Answer these immediately:
- Which component is affected? (ECM / DB2 / Kofax / WAS / KTM)
- Is this a full outage or degraded service?
- What is the user / business impact right now?
- What changed recently? (deployment, config change, scheduled job)

## Step 2 — Immediate Stabilisation
Identify and action anything that can reduce impact *right now* without making things worse.
Document every action taken with timestamp.

## Step 3 — Diagnostic
Apply the relevant runbook if one exists.
If not, apply the bug-investigation workflow diagnostics.
Check:
- Relevant service logs (WAS, ECM, DB2 diagnostics)
- DB2: lock waits, long-running SQL, tablespace health
- Kofax: batch queue depth, stuck batches, error batches
- Windows Event Log for Kofax hosts
- Splunk for correlated events across components

## Step 4 — Hypothesise & Test
List 2–3 causes. Test the most likely first.
Do not apply a fix to production without documenting the expected outcome and rollback plan.

## Step 5 — Resolution
Apply the fix. Verify resolution with the post-incident checks from the relevant runbook.
Confirm with impacted users or teams before closing.

## Step 6 — Post-Incident Record
Produce a brief PIR (Post-Incident Review) entry:
```
## Incident: [Title]
Date / Time: 
Duration: 
Severity: P1 / P2 / P3
Component: 
Summary: [2-3 sentences]
Root Cause: 
Resolution: 
Timeline: [key events with timestamps]
Action Items: [what changes prevent recurrence — owner + target date]
```

Add the root cause to the Known Causes section of the relevant runbook.
