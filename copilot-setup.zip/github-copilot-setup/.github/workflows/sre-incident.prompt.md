---
mode: agent
description: Live incident response workflow for the documents platform
tools: [codebase, terminalLastCommand, readFile]
---

# SRE Incident Response Workflow

Time matters during incidents. This workflow is structured for speed and clarity.
Apply sre-monitoring.instructions.md and the relevant domain skill throughout.

## Step 1 — Triage (first 2 minutes)
Answer these immediately:
- Which component is affected? (ECM / DB2 / Kofax / WAS / KTM)
- Is this a full outage or degraded service?
- What is the user / business impact right now?
- What changed recently? (deployment, config change, scheduled job)

## Step 2 — Immediate Stabilisation
Identify and action anything that can reduce impact *right now* without making things worse.
Document every action taken with timestamp.

## Step 3 — Diagnostic
Apply the relevant runbook if one exists.
If not, apply the bug-investigation workflow diagnostics.
Check:
- Relevant service logs (WAS, ECM, DB2 diagnostics)
- DB2: lock waits, long-running SQL, tablespace health
- Kofax: batch queue depth, stuck batches, error batches
- Windows Event Log for Kofax hosts
- Splunk for correlated events across components

## Step 4 — Hypothesise & Test
List 2–3 causes. Test the most likely first.
Do not apply a fix to production without documenting the expected outcome and rollback plan.

## Step 5 — Resolution
Apply the fix. Verify resolution with the post-incident checks from the relevant runbook.
Confirm with impacted users or teams before closing.

## Step 6 — Post-Incident Record
Produce a brief PIR (Post-Incident Review) entry:
```
## Incident: [Title]
Date / Time: 
Duration: 
Severity: P1 / P2 / P3
Component: 
Summary: [2-3 sentences]
Root Cause: 
Resolution: 
Timeline: [key events with timestamps]
Action Items: [what changes prevent recurrence — owner + target date]
```

Add the root cause to the Known Causes section of the relevant runbook.

## Step 7 — Write Persistent Files

Using the file write tool — do not describe these actions, execute them:

1. **Runbook** — update the Known Causes table in the relevant runbook with the
   root cause, resolution, and date from this incident.
   If no runbook exists for this component, create one using `runbook.instructions.md`.

2. **DECISIONS.md** — if the resolution involved a non-obvious technical choice
   or a workaround that should be remembered, write an ADR entry.

3. **README.md** — update in any directory where files were modified during resolution.

If not in agent mode, tell the user:
> "I cannot write files in Ask mode. Switch to Agent mode and re-run, or copy the following content manually:"
> [output full content for each file]

---

## Documentation (always runs — see tech-lead.instructions.md)

The tech-lead execution sequence governs all documentation for this workflow.
Steps 5 and 6 of that sequence are mandatory and run automatically after this workflow completes:
- **Step 5** — Write README.md in every affected directory (file write, not a description)
- **Step 6** — Write DECISIONS.md for any qualifying technical decisions (file write, not a description)

These are not optional follow-up suggestions. They are part of the task.
