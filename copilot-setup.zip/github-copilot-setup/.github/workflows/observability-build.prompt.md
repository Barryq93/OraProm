---
mode: agent
description: Build Prometheus alert rules, Grafana dashboards, or Alloy pipeline config
tools: [codebase, readFile, writeFile]
---

# Observability Build Workflow

Apply observability.instructions.md throughout.
All outputs must align with the metric naming conventions defined there.

## Step 1 — Context Pulse
Run the context pulse from context-memory.instructions.md.

## Step 2 — Classify the Request
Determine what is being built:
- **Alert rules** — Prometheus YAML rule file
- **Dashboard** — Grafana JSON model or Grafonnet
- **Alloy pipeline** — scrape config, log collection, or remote write
- **Pushgateway integration** — PowerShell metric push from monitoring script
- **LogQL / PromQL query** — standalone query for investigation or dashboard panel

State the classification and confirm before proceeding.

## Step 3 — Metric Alignment Check
Before writing any query, alert, or dashboard:
- Confirm the exact metric names being used (from observability.instructions.md conventions)
- Confirm the label set (host, environment, component, platform)
- If a new metric is needed: define its name, type, labels, and help string FIRST
- Ensure metric names from PowerShell Pushgateway scripts align with what dashboards query

## Step 4 — Platform Scope
Confirm which platform(s) are in scope:
- Windows Server 2019/2022 (windows_exporter / Pushgateway metrics)
- RHEL 8.1 (node_exporter metrics)
- Both

## Step 5 — Implement
Follow the standards in observability.instructions.md:
- Alert rules: include `for`, `severity`, `team`, `runbook_url` on every rule
- Alloy config: use `env()` for all external URLs and credentials — no hardcoding
- Dashboards: include `$datasource`, `$environment`, `$host` template variables
- Pushgateway: include the DELETE step for one-shot jobs

## Step 6 — Threshold Alignment
If producing alert rules or dashboard thresholds:
- Confirm thresholds match the values in sre-monitoring.instructions.md
- If new thresholds are being set, document the reasoning

## Step 7 — Runbook Link
For every new alert rule, either:
- Link to an existing runbook URL in the `runbook_url` annotation, OR
- Flag that a runbook needs to be created and use the runbook.instructions.md format

## Step 8 — Self-Review Gate
Run the self-review from tech-lead.instructions.md.
Specifically verify:
- No hardcoded credentials or URLs in Alloy config
- All alert rules have required annotations
- Metric names are consistent across scripts, alerts, and dashboards
- `honor_labels = true` present on any Pushgateway scrape target
