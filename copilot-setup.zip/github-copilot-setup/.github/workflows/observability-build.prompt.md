---
mode: agent
description: Build Prometheus alert rules, Grafana dashboards, or Alloy pipeline config
tools: [codebase, readFile, writeFile]
---

# Observability Build Workflow

Apply observability.instructions.md throughout.
All outputs must align with the metric naming conventions defined there.

## Step 1 — Context Pulse
Run the context pulse from context-memory.instructions.md.

## Step 2 — Classify the Request
Determine what is being built:
- **Alert rules** — Prometheus YAML rule file
- **Dashboard** — Grafana JSON model or Grafonnet
- **Alloy pipeline** — scrape config, log collection, or remote write
- **Pushgateway integration** — PowerShell metric push from monitoring script
- **LogQL / PromQL query** — standalone query for investigation or dashboard panel

State the classification and confirm before proceeding.

## Step 3 — Metric Alignment Check
Before writing any query, alert, or dashboard:
- Confirm the exact metric names being used (from observability.instructions.md conventions)
- Confirm the label set (host, environment, component, platform)
- If a new metric is needed: define its name, type, labels, and help string FIRST
- Ensure metric names from PowerShell Pushgateway scripts align with what dashboards query

## Step 4 — Platform Scope
Confirm which platform(s) are in scope:
- Windows Server 2019/2022 (windows_exporter / Pushgateway metrics)
- RHEL 8.1 (node_exporter metrics)
- Both

## Step 5 — Implement
Follow the standards in observability.instructions.md:
- Alert rules: include `for`, `severity`, `team`, `runbook_url` on every rule
- Alloy config: use `env()` for all external URLs and credentials — no hardcoding
- Dashboards: include `$datasource`, `$environment`, `$host` template variables
- Pushgateway: include the DELETE step for one-shot jobs

## Step 6 — Threshold Alignment
If producing alert rules or dashboard thresholds:
- Confirm thresholds match the values in sre-monitoring.instructions.md
- If new thresholds are being set, document the reasoning

## Step 7 — Runbook Link
For every new alert rule, either:
- Link to an existing runbook URL in the `runbook_url` annotation, OR
- Flag that a runbook needs to be created and use the runbook.instructions.md format

## Step 8 — Self-Review Gate
Run the self-review from tech-lead.instructions.md.
Specifically verify:
- No hardcoded credentials or URLs in Alloy config
- All alert rules have required annotations
- Metric names are consistent across scripts, alerts, and dashboards
- `honor_labels = true` present on any Pushgateway scrape target

## Step 9 — Write Persistent Files

Using the file write tool — do not describe these actions, execute them:

1. **The output files** — write all alert rules, Alloy config, or dashboard JSON
   to their correct paths in the workspace.

2. **README.md** — create or update in every directory that received a new or
   modified file. For observability config directories, include: what is monitored,
   scrape targets, alert rule files, and how to validate the config.

3. **DECISIONS.md** — write ADR entries for any significant choices made:
   - Metric naming decisions
   - Threshold values chosen and why
   - Routing decisions (Loki vs Splunk for a given log source)
   - Alloy pipeline design choices
   - Pushgateway vs direct scrape decisions

If not in agent mode, tell the user:
> "I cannot write files in Ask mode. Switch to Agent mode and re-run, or copy the following content manually:"
> [output full content for each file]

---

## Documentation (always runs — see tech-lead.instructions.md)

The tech-lead execution sequence governs all documentation for this workflow.
Steps 5 and 6 of that sequence are mandatory and run automatically after this workflow completes:
- **Step 5** — Write README.md in every affected directory (file write, not a description)
- **Step 6** — Write DECISIONS.md for any qualifying technical decisions (file write, not a description)

These are not optional follow-up suggestions. They are part of the task.
