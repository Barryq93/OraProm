---
mode: agent
description: Safe, structured refactoring with behaviour preservation verification
tools: [codebase, readFile, writeFile, terminalLastCommand]
---

# Refactor Workflow

Refactoring has a different risk profile to new code — existing behaviour must be preserved.
Never refactor and change behaviour in the same step.

## Step 1 — Context Pulse
Run the context pulse from context-memory.instructions.md.
Identify all files that will be touched by this refactor.

## Step 2 — Define the Scope
Confirm:
- What is the specific smell or problem being addressed?
- What is explicitly OUT of scope (behaviour that must not change)?
- Are there dependent scripts, jobs, or systems that consume the output of this code?
- Is there an existing test suite to run before and after?

If any of these are unclear, output `## Missing Information` and ask.

## Step 3 — Behaviour Baseline
Before changing a single line:
- Document the current behaviour: inputs, outputs, side effects, error states
- Identify any implicit contracts (log output format, exit codes, metric names, file paths)
- Note anything that downstream systems depend on — these are protected

## Step 4 — Refactor Plan
Produce a step-by-step plan. Each step must be:
- A single, atomic change
- Safe to stop after (no half-refactored state)
- Independently verifiable

Get confirmation before proceeding.

## Step 5 — Implement (one step at a time)
Apply the relevant skill file standards for the code type.
After each step:
- Show a diff of what changed
- Confirm the protected behaviours are still intact
- Pause for confirmation before the next step

## Step 6 — Verification
For each protected behaviour identified in Step 3:
- How do we verify it still works?
- If a test exists — run it
- If no test exists — write a verification procedure and flag that a test should be added

## Step 7 — Self-Review Gate
Run the full self-review from tech-lead.instructions.md.

## Step 8 — Change Log & Refactor Summary
```
## Refactor Summary
What changed: [technical description]
Why: [the problem this solves]
What was NOT changed: [protected behaviours confirmed intact]
Tests added: [any new tests or verification procedures]
Follow-up: [any remaining debt or follow-on work flagged]
```

## Step 9 — Write Persistent Files

Using the file write tool — do not describe these actions, execute them:

1. **README.md** — update in every directory where files were modified.
   If the refactor changed the public interface, usage, or prerequisites, update those sections.

2. **DECISIONS.md** — write an ADR entry for the refactor if it involved a real choice:
   - Why this refactoring approach over another
   - Any trade-offs accepted (e.g. short-term duplication during transition)
   - Patterns introduced or removed and why

If not in agent mode, tell the user:
> "I cannot write files in Ask mode. Switch to Agent mode and re-run, or copy the following content manually:"
> [output full content for each file]

---

## Documentation (always runs — see tech-lead.instructions.md)

The tech-lead execution sequence governs all documentation for this workflow.
Steps 5 and 6 of that sequence are mandatory and run automatically after this workflow completes:
- **Step 5** — Write README.md in every affected directory (file write, not a description)
- **Step 6** — Write DECISIONS.md for any qualifying technical decisions (file write, not a description)

These are not optional follow-up suggestions. They are part of the task.
