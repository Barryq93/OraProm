---
mode: agent
description: Safe DB2 schema change or data migration workflow with mandatory safeguards
tools: [codebase, readFile, writeFile]
---

# DB2 Migration Workflow

Schema changes and data migrations are high-risk, often irreversible operations.
This workflow enforces safeguards that protect production data.

## Step 1 — Context Pulse
Run the context pulse from context-memory.instructions.md.

## Step 2 — Migration Classification
Classify the change before anything else:

| Class | Examples | Risk |
|-------|---------|------|
| **Additive** | New table, new nullable column, new index | Low — generally reversible |
| **Modifying** | Column type change, constraint change, rename | Medium — requires validation |
| **Destructive** | DROP TABLE/COLUMN, TRUNCATE, data delete | HIGH — irreversible |

State the classification explicitly. If **Destructive**, require explicit confirmation
before producing any scripts.

## Step 3 — Gather Requirements
Confirm before writing any SQL:
1. Target database and schema name
2. DB2 version (must be 11.5.9 LUW unless told otherwise)
3. Expected row counts for affected tables (pre-check)
4. Maintenance window availability (online vs offline change)
5. Is ECM / FileNet the owner of this schema? (If yes — extra caution — see ECM note below)
6. Who needs to approve and sign off?

## Step 4 — Pre-Migration Script
Produce a pre-migration verification script FIRST:

```sql
-- Pre-migration checks (run and record output BEFORE migration)
-- 1. Row counts for affected tables
SELECT COUNT(*) AS pre_count FROM SCHEMA.TABLE_NAME;

-- 2. Tablespace free space (ensure enough room)
SELECT TBSP_NAME, 
       (TBSP_TOTAL_PAGES - TBSP_USED_PAGES) * TBSP_PAGE_SIZE / 1024 / 1024 AS FREE_MB
FROM SYSIBMADM.TBSP_UTILIZATION
WHERE TBSP_NAME = 'USERSPACE1';

-- 3. Active connections (migrate only with minimal connections)
SELECT COUNT(*) AS active_connections FROM SYSIBMADM.APPLICATIONS;

-- 4. Table lock check
SELECT TABNAME, LOCKNAME FROM SYSCAT.TABLES WHERE TABSCHEMA = 'SCHEMA';
```

## Step 5 — Migration Script
Produce the migration SQL following db2-dba.instructions.md standards.

Every migration script must include:
- Header block with script name, purpose, target DB, author, date, DB2 version
- Pre-conditions check at the top
- The migration statements
- Post-migration verification queries
- **Rollback script in a separate block** (see below)

```sql
-- =============================================================================
-- MIGRATION:    MYYYYMMDD_add_document_index.sql
-- PURPOSE:      Add index on DOCUMENT_ID for query performance
-- DB:           ECMDB / ICMADMIN schema
-- AUTHOR:       [name]
-- CREATED:      YYYY-MM-DD
-- DB2 VERSION:  11.5.9 LUW
-- RISK CLASS:   Additive
-- APPROVED BY:  [name / ticket]
-- =============================================================================

-- PRE-CONDITION: Verify table exists
SELECT COUNT(*) FROM SYSCAT.TABLES 
WHERE TABSCHEMA = 'ICMADMIN' AND TABNAME = 'DOCTYPES';
-- Expected: 1 row. If 0, STOP.

-- MIGRATION
CREATE INDEX ICMADMIN.IDX_DOCTYPE_DOCID 
    ON ICMADMIN.DOCTYPES (DOCUMENT_ID ASC)
    ALLOW REVERSE SCANS
    COLLECT DETAILED STATISTICS;

RUNSTATS ON TABLE ICMADMIN.DOCTYPES 
    WITH DISTRIBUTION AND DETAILED INDEXES ALL;

-- POST-MIGRATION VERIFICATION
SELECT INDNAME, TABNAME, COLNAMES 
FROM SYSCAT.INDEXES 
WHERE INDSCHEMA = 'ICMADMIN' AND TABNAME = 'DOCTYPES';
-- Expected: new index visible in output
```

## Step 6 — Rollback Script (mandatory)
Produce a rollback script for every migration — in a separate file:

```sql
-- =============================================================================
-- ROLLBACK:     ROLLBACK_MYYYYMMDD_add_document_index.sql
-- ROLLS BACK:   MYYYYMMDD_add_document_index.sql
-- WARNING:      Test rollback in UAT before running in prod
-- =============================================================================
DROP INDEX ICMADMIN.IDX_DOCTYPE_DOCID;

-- Verify removal
SELECT COUNT(*) FROM SYSCAT.INDEXES 
WHERE INDSCHEMA = 'ICMADMIN' AND INDNAME = 'IDX_DOCTYPE_DOCID';
-- Expected: 0
```

## Step 7 — ECM Schema Warning

If the target schema is managed by FileNet / ECM (ICMADMIN or equivalent):

> ⚠️ **ECM Managed Schema**
> Schema changes to ECM-owned tables can corrupt the object store or break P8 API operations.
> The following must be confirmed before proceeding:
> - IBM FileNet documentation reviewed for this change
> - Change tested against a full ECM UAT environment (not just DB2)
> - ECM services stopped or in maintenance mode during migration
> - IBM support ticket raised if this is an unsupported schema modification

## Step 8 — Post-Migration Checklist

```
## Migration Sign-Off Checklist
- [ ] Pre-migration row counts recorded
- [ ] Migration script executed without errors
- [ ] Post-migration verification queries ran and output matches expected
- [ ] Rollback script tested in UAT
- [ ] ECM services restarted and tested (if ECM schema)
- [ ] DB2 RUNSTATS executed on affected tables
- [ ] Change logged in the change management system
- [ ] Rollback script retained and accessible
```
