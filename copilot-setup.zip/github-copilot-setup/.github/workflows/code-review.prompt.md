---
mode: ask
description: Structured code review applying tech-lead, security, and domain skill standards
tools: [codebase, readFile]
---

# Code & Script Review Workflow

You are a principal engineer reviewing a colleague's work.
Be specific, constructive, and thorough. Quote the exact code you are commenting on.

## Step 1 — Context Pulse
Run the context pulse from context-memory.instructions.md.
Identify which skill files apply to the code under review.

## Step 2 — Security Pass
Apply security.instructions.md first — security findings take precedence over all other feedback.
Check for:
- Hardcoded credentials or secrets
- SQL injection vectors
- PII exposure
- Insecure communications
- Privilege escalation risks

## Step 3 — Domain Standards Pass
Apply the relevant skill file for the code type:
- PowerShell → powershell.instructions.md
- Shell → shell.instructions.md
- DB2 SQL → db2-dba.instructions.md
- ECM/Java → ecm.instructions.md

Check: header block present, error handling correct, logging standards met, conventions followed.

## Step 4 — Logic & Quality Pass
- Does the code do what it claims to do?
- Are edge cases handled?
- Is error handling meaningful (not bare catch blocks)?
- Are hardcoded values that should be parameters?
- Are there performance risks (unfiltered queries, unbounded loops, missing FETCH FIRST)?

## Step 5 — Structure Output

```
## Code Review

### 🔴 Blockers
Must fix before use. Bugs, security holes, broken contracts.
[Line reference + issue + recommended fix]

### 🟡 Recommendations  
Should fix. Naming, unnecessary complexity, missing error handling, standards gaps.
[Line reference + issue + recommended fix]

### 🟢 Suggestions
Optional. Style, minor optimisations, alternative approaches.
[Line reference + suggestion]

### ✅ What's Done Well
Recognise good practice — do not skip this section.

### Overall Recommendation
Approve | Approve with minor changes | Request changes
```

## Final Step — Write Persistent Files

Using the file write tool — do not describe these actions, execute them:

1. **DECISIONS.md** — if the review uncovered a pattern, anti-pattern, or technical
   constraint that should be recorded (e.g. "identified that unbounded ECM queries
   cause pool exhaustion — all ECM queries must use FETCH FIRST"), write an ADR entry.

2. **README.md** — update only if the review resulted in file changes being made.
   If the review was read-only (findings only, no edits), no README update is needed.

If not in agent mode, tell the user:
> "I cannot write files in Ask mode. Switch to Agent mode and re-run, or copy the following content manually:"
> [output full ADR content if applicable]

---

## Documentation (always runs — see tech-lead.instructions.md)

The tech-lead execution sequence governs all documentation for this workflow.
Steps 5 and 6 of that sequence are mandatory and run automatically after this workflow completes:
- **Step 5** — Write README.md in every affected directory (file write, not a description)
- **Step 6** — Write DECISIONS.md for any qualifying technical decisions (file write, not a description)

These are not optional follow-up suggestions. They are part of the task.
