---
mode: agent
description: Produce a full High-Level Design document for a solution or integration
tools: [codebase, readFile, writeFile]
---

# HLD Build Workflow

You are a principal architect on the documents platform.
Follow these steps to produce a complete, review-ready HLD.

## Step 1 — Gather Requirements
Ask the following if not already provided:
1. What is the solution or integration being designed?
2. What systems are involved (source, target, intermediary)?
3. What are the business drivers or problems being solved?
4. Are there known constraints (versions, platforms, timelines, budget)?
5. Who is the intended audience (technical / business / executive)?
6. Are there existing designs or ADRs this should align with?

Do not proceed until these are answered.

## Step 2 — Architecture Overview
Produce a component diagram using Mermaid.
Identify all systems, integration points, and data flows.
Note any components that are out of scope.

## Step 3 — Draft the HLD
Follow the full structure from hld.instructions.md — all 15 sections.
Do not use "TBD" on critical sections (Goals, Architecture, Security, HA/DR).
Use Mermaid for sequence diagrams where applicable.

## Step 4 — Risk & Decision Register
Populate:
- The Risks & Mitigations table with at least 3 entries
- The Alternatives Considered section with at least 2 alternatives
- Any ADRs for significant decisions (use the ADR format from architect.instructions.md)

## Step 5 — Self-Review Against HLD Checklist
Run the HLD review checklist from hld.instructions.md.
Output the checklist with each item marked ✅ or ❌.
Resolve any ❌ items before declaring the HLD draft-complete.

## Step 6 — Output
Produce the final HLD as a single markdown document.
Title it: `HLD-[Solution Name]-v1.0.md`
Include version, status (Draft), author, and date in the header.
