---
applyTo: "**"
---

# Shell Scripting

Default shell: **bash**. Support ksh and sh when targeting AIX or legacy UNIX environments
(common in IBM stack). Always confirm target OS and shell before writing.

---

## Mandatory Script Header

```bash
#!/usr/bin/env bash
# =============================================================================
# SCRIPT:       script_name.sh
# PURPOSE:      One-line description
# DESCRIPTION:  Full description including context and background
# USAGE:        ./script_name.sh [options]
# PARAMETERS:   -p PARAM   Description of parameter
# DEPENDENCIES: List external tools, binaries, environment requirements
# ASSUMPTIONS:  What this script takes for granted about the environment
# LIMITATIONS:  Known edge cases not handled
# AUTHOR:       [name / Copilot]
# CREATED:      YYYY-MM-DD
# MODIFIED:     YYYY-MM-DD
# VERSION:      1.0.0
# ENVIRONMENT:  RHEL 7+ / AIX 7.x / etc.
# =============================================================================
set -euo pipefail
```

`set -euo pipefail` is mandatory on all bash scripts unless there is an explicit
documented reason to omit it. Comment why if omitting.

---

## Error Handling

```bash
# Trap for unexpected errors
trap 'echo "[ERROR] Script failed at line $LINENO. Exit code: $?" >&2; cleanup; exit 1' ERR

cleanup() {
    # release locks, temp files, connections
    rm -f "$LOCKFILE" 2>/dev/null || true
}

# Logging
log() {
    local level="$1"; shift
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $*" | tee -a "$LOG_FILE"
}

log INFO "Starting process"
log ERROR "Something failed" >&2
```

- All errors to stderr: `>&2`
- Always use `trap ERR` for unexpected failure capture
- `cleanup()` function for any script that creates temp files, locks, or connections

---

## DB2 / ECM Shell Patterns

```bash
# DB2 environment setup — always source before db2 commands
. /home/db2inst1/sqllib/db2profile

# Run DB2 command and capture output + return code
db2 connect to MYDB > /dev/null
RC=$?
if [[ $RC -ne 0 ]]; then
    log ERROR "DB2 connect failed with RC=$RC"
    exit $RC
fi

# Always disconnect cleanly
trap 'db2 terminate 2>/dev/null; cleanup' EXIT
```

- Always source `db2profile` before DB2 commands
- Check return codes explicitly — `$?` after every DB2 call
- Disconnect in a `trap EXIT` block, not inline

---

## Secrets & Credentials

```bash
# ✅ Correct
DB_PASSWORD="${DB_PASSWORD:?DB_PASSWORD environment variable is required}"
API_KEY=$(cat /etc/app/secrets/api_key 2>/dev/null) || { log ERROR "Cannot read API key"; exit 1; }

# ❌ Never
DB_PASSWORD="mypassword123"
```

- Use `${VAR:?message}` to enforce required env vars with a clear error
- Read secrets from files with restricted permissions (400/600), not inline
- Never echo or log credential values

---

## Style Rules

- 4-space indentation
- `[[ ]]` over `[ ]` for conditionals in bash
- Quote all variable expansions: `"$var"`, `"${array[@]}"`
- Use `local` for all function-scoped variables
- Functions before main logic
- Constants in UPPER_CASE, variables in lower_case
- Long scripts: use a `main()` function and call it at the end

```bash
main() {
    parse_args "$@"
    validate_environment
    run_process
}

main "$@"
```
