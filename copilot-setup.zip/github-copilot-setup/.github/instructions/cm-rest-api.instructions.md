---
applyTo: "**"
---

# IBM Content Manager REST API — Integration Skill

**Base path:** `/cm8app/cm8rest/v1/`
**Auth:** Bearer token (JWT) obtained from `/login`
**Docs:** https://www.ibm.com/docs/en/content-manager/8.7.0?topic=support-rest-api-documentation
**Requires:** FP4 privilege `CLIENT_REST_PRIVILEGE` assigned to the calling user/role

This skill applies when designing, building, or reviewing any Spring Boot microservice,
script, or integration that calls the CM8 REST API.

---

## Authentication Pattern

Tokens are short-lived (default 30 minutes — check `tokenDuration` from `/ping`).
Always implement token refresh. Never hardcode credentials.

```java
// Spring Boot — CM8 token management (WebClient pattern)
@Component
public class Cm8TokenService {

    private final WebClient webClient;
    private String cachedToken;
    private Instant tokenExpiry;

    public Cm8TokenService(@Value("${cm8.base-url}") String baseUrl) {
        this.webClient = WebClient.builder().baseUrl(baseUrl).build();
    }

    public String getToken() {
        if (cachedToken == null || Instant.now().isAfter(tokenExpiry.minusSeconds(60))) {
            cachedToken = fetchToken();
            tokenExpiry = Instant.now().plusSeconds(1800); // 30 min default
        }
        return cachedToken;
    }

    private String fetchToken() {
        // Credentials must come from environment / secrets management — never hardcoded
        Map<String, String> body = Map.of(
            "servername", System.getenv("CM8_SERVER_NAME"),
            "username",   System.getenv("CM8_USERNAME"),
            "password",   System.getenv("CM8_PASSWORD")
        );
        return webClient.post()
            .uri("/login")
            .contentType(MediaType.APPLICATION_JSON)
            .bodyValue(body)
            .retrieve()
            .bodyToMono(String.class)
            .block(); // Bearer token returned as plain text
    }
}
```

---

## Key API Operations

### Health Check / Ping
```
GET /cm8app/cm8rest/v1/ping
```
Returns: `status`, `version`, `tokenDuration`, `enableConnectionPool`
Use this to verify connectivity and discover the token lifetime before login.

---

### Item Type Discovery
```
GET /cm8app/cm8rest/v1/itemtypes
GET /cm8app/cm8rest/v1/itemtypes?classification=2          // Documents only
GET /cm8app/cm8rest/v1/itemtypes/{name}
GET /cm8app/cm8rest/v1/itemtypes/{name}?include=attributes // FP3+: includes attribute definitions
```

**Classification values:**
| Value | Meaning |
|---|---|
| 0 | Item |
| 1 | Resource Item |
| 2 | Document |
| 3 | Folder |

**Attribute type codes** (from `?include=attributes` response):
| Type | Data type |
|---|---|
| 1 | Character / VarChar |
| 9 | Timestamp |
| 3 | Integer |
| 4 | Decimal |
| 6 | Date |

---

### Querying Items

Query body is a **path expression** (plain text, `Content-Type: text/plain`):

```
POST /cm8app/cm8rest/v1/items/query?limit=50&retrieve=attributes&latestVersion=true

Body: /ItemTypeName[@AttributeName = 'value']
```

**Query parameter reference:**
| Parameter | Values | Default |
|---|---|---|
| `limit` | integer, 0=unlimited | 50 — always set explicitly |
| `retrieve` | `attributes` \| `partsMetaData` \| `partsACL` | PIDs only |
| `latestVersion` | `true` \| `false` | `true` |
| `retrieveCheckoutDetail` | `true` \| `false` | `false` |

**Query path syntax:**
```
/InvoiceDocument                                           -- all items of type
/InvoiceDocument[@INVOICE_NUMBER = '12345']               -- attribute match
/InvoiceDocument[@CREATETS > '2024-01-01']                -- date filter
/InvoiceDocument[@STATUS = 'APPROVED'][@YEAR = '2024']    -- compound filter
/NOINDEX[@VERSIONID = 1]                                   -- specific version
```

**Never query without a limit** — the CM8 library server will return all matching items
and can exhaust memory on both the server and the calling microservice.

---

### Retrieving a Specific Item
```
GET /cm8app/cm8rest/v1/items/{pid}
GET /cm8app/cm8rest/v1/items/{pid}?retrieve=partsMetaData&version=latest
GET /cm8app/cm8rest/v1/items/{pid}?version=all             // all versions
GET /cm8app/cm8rest/v1/items/{pid}?checkout=true           // check out on retrieve
```

**PID handling** — PIDs contain spaces and must be URL-encoded:
```java
String encodedPid = URLEncoder.encode(pid, StandardCharsets.UTF_8);
// "86 3 ICM8..." → "86+3+ICM8..."
```

---

### Creating an Item (with content parts)

```
POST /cm8app/cm8rest/v1/itemtypes/{itemTypeName}/items
Content-Type: multipart/form-data
```

Multipart form parts — **order matters**:
1. `attributes` (JSON array) — must come before part file streams
2. `parts` (JSON object) — content/annotation/notelog part metadata
3. `contentParts1`, `contentParts2`... — file streams in order
4. `annotationParts1`... — annotation streams
5. `notelogParts1`... — notelog streams

```java
// Spring Boot — multipart item creation
MultipartBodyBuilder builder = new MultipartBodyBuilder();

// Attributes
builder.part("attributes", List.of(
    Map.of("name", "INVOICE_NUMBER", "value", invoiceNumber),
    Map.of("name", "CUSTOMER_ID",    "value", customerId)
));

// Parts metadata
Map<String, Object> partsMetadata = Map.of(
    "contentParts", List.of(Map.of(
        "mimetype", "application/pdf",
        "partType", "ICMBASE",
        "originalFileName", filename,
        "size", fileBytes.length
    ))
);
builder.part("parts", partsMetadata);

// File stream — must be after metadata
builder.part("contentParts1", new ByteArrayResource(fileBytes))
    .filename(filename)
    .contentType(MediaType.APPLICATION_PDF);

webClient.post()
    .uri("/itemtypes/{name}/items", itemTypeName)
    .header("Authorization", "Bearer " + tokenService.getToken())
    .contentType(MediaType.MULTIPART_FORM_DATA)
    .body(BodyInserters.fromMultipartData(builder.build()))
    .retrieve()
    .bodyToMono(Cm8CreateResponse.class)
    .block();
```

**Part types:**
| partType | Purpose |
|---|---|
| `ICMBASE` | Primary content (PDF, TIFF, etc.) |
| `ICMANNOTATION` | Annotation overlay (`application/vnd.ibm.modcap`) |
| `ICMNOTELOG` | Note log (`text/plain`) |

---

### Updating an Item
```
PUT /cm8app/cm8rest/v1/items/{pid}
```
Body: JSON array of `{"name": "ATTR", "value": "newValue"}` objects.
Returns new PID (version increments on update).

---

### Moving an Item (FP2+)
```
POST /cm8app/cm8rest/v1/items/{pid}/move
```
Body: `{"destinationItemType": "TargetItemTypeName"}`

---

### Creating a Folder
```
POST /cm8app/cm8rest/v1/itemtypes/{name}/folders
Content-Type: application/json
Body: [{"name": "ATTR", "value": "val"}]
```

---

## Spring Boot Integration Patterns

### CM8 REST Client Configuration

```yaml
# application.yml — environment-specific, never commit credentials
cm8:
  base-url: ${CM8_BASE_URL}          # e.g. http://cm8host:9080/cm8app/cm8rest/v1
  server-name: ${CM8_SERVER_NAME}    # Library server name
  username: ${CM8_USERNAME}
  password: ${CM8_PASSWORD}
  token-duration-seconds: 1800
  connection-timeout-ms: 5000
  read-timeout-ms: 30000
```

### Error Handling

```java
webClient.get()
    .uri("/items/{pid}", encodedPid)
    .header("Authorization", "Bearer " + tokenService.getToken())
    .retrieve()
    .onStatus(HttpStatus::is4xxClientError, response -> {
        if (response.statusCode() == HttpStatus.UNAUTHORIZED) {
            // Token expired — invalidate cache and retry
            tokenService.invalidateToken();
        }
        return response.bodyToMono(String.class)
            .map(body -> new Cm8ClientException("CM8 client error: " + body));
    })
    .onStatus(HttpStatus::is5xxServerError, response ->
        response.bodyToMono(String.class)
            .map(body -> new Cm8ServerException("CM8 server error: " + body))
    )
    .bodyToMono(Cm8ItemResponse.class);
```

### Response Model

```java
// Core response wrapper — all CM8 REST responses include "status"
public record Cm8Response(String status) {}

public record Cm8CreateResponse(String status, String pid) {}

public record Cm8QueryResponse(String status, List<Cm8Item> items) {}

public record Cm8Item(
    String itemId,
    String version,
    String pid,
    String createdUserid,
    String createdTimestamp,
    String updatedUserid,
    String updatedTimestamp,
    String itemtypeName,
    String aclName,
    List<Cm8Attribute> attributes,
    Cm8Parts parts,
    boolean isDocument,
    boolean isFolder,
    boolean isItem
) {}

public record Cm8Attribute(String name, int type, String value) {}

public record Cm8ContentPart(
    String pid, String mimetype, String url,
    long size, String originalFileName, String partType,
    String rmName, String smsCollName
) {}
```

---

## Security Rules for CM8 REST Integration

- Credentials in environment variables only — never in application.yml committed to source control
- Use a dedicated CM8 service account for each microservice — not ICMADMIN
- Token must not be logged or exposed in API responses
- Content part URLs from CM8 responses contain time-limited tokens — do not cache or share these URLs
- Validate item type name against known types before calling — prevents unintended type creation
- Apply `limit` on all query calls — never pass `limit=0` in production code without explicit approval

---

## Common Failure Patterns

- **401 mid-session** — token expired, not refreshed; implement token expiry tracking
- **Multipart ordering error** — part file streams sent before metadata JSON; order is mandatory
- **PID not URL-encoded** — spaces in PID cause 400; always URL-encode before use in path
- **Query returns empty with no error** — item type name case mismatch; names are case-sensitive
- **Large result set hangs** — no `limit` set on query; default is 50 but code that overrides to 0 will retrieve everything
- **Content URL expired** — RM token in part URL is time-limited; fetch content immediately, do not cache the URL
