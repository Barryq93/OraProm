---
applyTo: "**"
---

# Decisions Log — DECISIONS.md

Every significant technical decision must be written to `DECISIONS.md` at the
workspace root using the file write tool. Do not describe the update — write the file.

---

## This Is a File Write Action, Not a Text Description

When a decision qualifies for logging:
1. Read the current `DECISIONS.md` to get the latest ADR number and index
2. Append the new entry at the top of the Decisions section (newest first)
3. Update the index table
4. Update the "Last updated" date
5. Write the file

If you cannot write files (not in agent mode), tell the user:
> "I cannot write DECISIONS.md in Ask mode. Switch to Agent mode and re-run,
> or copy this entry manually:"
> [output the full ADR block]

---

## When to Write an Entry

Write a new ADR entry when any of the following are true:

- A technology, tool, library, or platform was chosen over an alternative
- A pattern or approach was selected and another was rejected
- A version was pinned for a specific reason (compatibility, stability, support)
- An architectural boundary was defined
- A security or compliance constraint shaped the implementation
- A known limitation or trade-off was consciously accepted
- An external source (doc, RFC, IBM technote, blog post) was consulted and
  influenced the decision

Do NOT write entries for:
- Trivial naming or formatting choices
- Decisions fully self-evident from the code
- Intermediate steps in a task that did not involve a real choice

When confirming an existing decision is still valid, update that entry's date
and add a confirmation note — do not create a new ADR.

---

## Entry Format

```markdown
## ADR-[NNN]: [Short decision title]

**Date:** YYYY-MM-DD
**Status:** Accepted | Superseded by ADR-NNN | Under Review
**Mode:** Coding | Architecture | Research
**Component:** [ECM | DB2 | Kofax | Observability | Ansible | etc.]

### Context
Why did this decision need to be made? What situation or constraint forced it?

### Decision
What was decided, in one clear sentence.

### Reasoning
Why this option over the alternatives? Be specific.
- Option chosen: [name] — [why]
- Option rejected: [name] — [why rejected]
- Option rejected: [name] — [why rejected]

### Consequences
What does this decision make easier? What does it make harder or impossible?
What technical debt, if any, does it incur?

### References
- [Link or document title](url)
- [IBM technote / redbook / release note](url)
- Internal: [runbook / HLD / ticket reference]
```

---

## DECISIONS.md File Structure

The file must maintain this structure. Preserve all existing entries when writing:

```markdown
# Decisions Log

This file records all significant technical decisions made in this project.
Generated and maintained by GitHub Copilot under principal engineer guidance.
Last updated: YYYY-MM-DD

---

## Index
| ADR | Title | Component | Status | Date |
|-----|-------|-----------|--------|------|

---

## Decisions

[entries in reverse chronological order — newest first]
```

---

## Superseding a Decision

When a prior decision is reversed or updated:
1. Change the old entry Status to `Superseded by ADR-NNN`
2. Add the new entry referencing the old one in its Context section
3. Do not delete old entries — the history matters

---

## Surfacing in Change Log

Every time DECISIONS.md is written, include in the response Change Log:
```
- DECISIONS.md — written: added ADR-[NNN]: [title]
- DECISIONS.md — written: confirmed ADR-[NNN] still valid
```
