---
applyTo: "**"
---

# Decisions Log — DECISIONS.md

Every significant technical decision made during a session must be recorded in
`DECISIONS.md` at the workspace root. This file is the institutional memory of
the project — it explains *why* the codebase is the way it is.

---

## When to Add an Entry

Add an entry when any of the following are true:

- A technology, tool, library, or platform was chosen over an alternative
- A pattern or approach was selected (and another was rejected)
- A version was pinned for a specific reason (compatibility, stability, support)
- An architectural boundary was defined (e.g. "Spring Boot = design only")
- A security or compliance constraint shaped the implementation
- A known limitation or trade-off was consciously accepted
- An external source (doc, RFC, blog post, IBM technote) was consulted and influenced the decision

Do NOT add entries for:
- Trivial naming or formatting choices
- Decisions that are fully self-evident from the code
- Intermediate steps in a task that didn't involve a real choice

---

## Entry Format

```markdown
## ADR-[NNN]: [Short decision title]

**Date:** YYYY-MM-DD
**Status:** Accepted | Superseded by ADR-NNN | Under Review
**Mode:** Coding | Architecture | Research
**Component:** [ECM | DB2 | Kofax | Observability | Ansible | etc.]

### Context
Why did this decision need to be made? What situation or constraint forced it?

### Decision
What was decided, in one clear sentence.

### Reasoning
Why this option over the alternatives? Be specific.
- Option chosen: [name] — [why]
- Option rejected: [name] — [why rejected]
- Option rejected: [name] — [why rejected]

### Consequences
What does this decision make easier? What does it make harder or impossible?
What technical debt, if any, does it incur?

### References
- [Link or document title](url)
- [IBM technote / redbook / release note](url)
- Internal: [runbook / HLD / ticket reference]
```

---

## DECISIONS.md File Structure

The file must maintain these sections in order:

```markdown
# Decisions Log

This file records all significant technical decisions made in this project.
Generated and maintained by GitHub Copilot under principal engineer guidance.
Last updated: YYYY-MM-DD

---

## Index
| ADR | Title | Component | Status | Date |
|-----|-------|-----------|--------|------|

---

## Decisions

[entries in reverse chronological order — newest first]
```

---

## Updating the Index

Every time a new entry is added, update the index table at the top.
Keep the index as the fast-navigation reference — entries are the detail.

---

## Superseding a Decision

When a prior decision is reversed or updated:
1. Change the old entry's `Status` to `Superseded by ADR-NNN`
2. Add the new entry referencing the old one in its Context section
3. Do not delete old entries — the history of why decisions changed is valuable

---

## Surfacing in Responses

When a decision is logged, the response must include in the Change Log:

```
- DECISIONS.md — added ADR-[NNN]: [title]
```

When research or architecture work confirms an existing decision, note it:

```
- DECISIONS.md — confirmed ADR-[NNN] still valid (no change required)
```
