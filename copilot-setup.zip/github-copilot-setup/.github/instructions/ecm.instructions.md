---
applyTo: "**"
---

# IBM ECM / FileNet Content Manager 8.7.4

All ECM work targets **FileNet Content Manager 8.7.4** using the **P8 Java API**.
Do not use Content Services GraphQL API or newer REST APIs unless explicitly requested —
those are post-8.7.4 features.

---

## API Baseline

```java
// Standard P8 API imports for ECM 8.7.4
import com.filenet.api.core.*;
import com.filenet.api.util.*;
import com.filenet.api.query.*;
import com.filenet.api.collection.*;
import com.filenet.api.constants.*;
import com.filenet.api.exception.*;

// Connection pattern
UserContext uc = UserContext.get();
Subject subject = UserContext.createSubject(conn, username, password, "FileNetP8WSI");
uc.pushSubject(subject);
try {
    Domain domain = Factory.Domain.fetchInstance(conn, null, null);
    ObjectStore os = Factory.ObjectStore.fetchInstance(domain, "OBJECT_STORE_NAME", null);
    // work
} finally {
    uc.popSubject();
}
```

- Always push/pop subject in a try/finally block
- Always close connections and iterators explicitly
- Use `Factory` pattern for all object instantiation
- Never use deprecated `Domain.getObjectStore()` — use `Factory.ObjectStore.fetchInstance()`

---

## Content Engine Query (FQL)

```java
// FQL — FileNet Query Language (SQL-like, not standard SQL)
SearchSQL searchSQL = new SearchSQL();
searchSQL.setSelectList("This, DocumentTitle, DateCreated");
searchSQL.setFromClauseInitialValue("Document");
searchSQL.setWhereClause("DateCreated > " + SearchSQL.formatDate(startDate));
searchSQL.setMaxRecords(500);  // Always limit — ECM result sets can be massive

SearchScope scope = new SearchScope(os);
DocumentSet results = (DocumentSet) scope.fetchObjects(searchSQL, null, null, true);
```

- FQL is not SQL — date formats and operators differ
- Always set `setMaxRecords()` — unbounded queries on large repositories will kill performance
- Prefer FQL over SQL for Content Engine searches
- For large result sets, use page-based retrieval with `continuation tokens`

---

## ICN Plugin Development

```java
// EDS (External Data Service) service pattern
@WebServlet("/EDSService")
public class MyEDSService extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        // parse incoming JSON, return property definitions
    }
}
```

- ICN plugins use Dojo AMD modules — always declare dependencies in `define([],...)`
- EDS services must return valid JSON conforming to the ICN EDS specification
- Actions/menus registered via plugin.xml descriptor
- Never block the Dojo event thread — async all I/O operations

---

## Kofax Integration Patterns

When writing scripts or code that interfaces between Kofax and ECM:

- Kofax Capture → ECM: use the FileNet Export Connector or custom Release Script (VB/C#)
- KTM extraction results → ECM document properties: map via Kofax Index Values
- RTTI → ECM: triggered post-release; assume RTTI has read access to the batch XML
- Always validate document class and property template existence before attempting to store
- Log the ECM GUID of stored documents for traceability back to Kofax batch IDs

---

## WAS Deployment Notes

- ECM 8.7.4 runs on WebSphere Application Server (WAS)
- For WAS restarts or deployments: notify DBA — connection pools will drop
- JVM heap settings for P8 Application Engine: do not change without testing
- WAS shared libraries for P8 API JARs — path must match deployment cell config

---

## Common Failure Patterns (flag these in review)

- Not closing `UpdatingBatch` — causes locks on the object store
- Fetching full document content when only metadata is needed — huge performance cost
- Not checking `EngineRuntimeException` error codes — error handling is too generic
- Querying without specifying the object store — defaults can produce unexpected results
- Not handling `VersionSeries` vs `Document` — version-aware operations need the series
