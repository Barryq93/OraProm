---
applyTo: "**"
---

# IBM Content Manager Enterprise Edition 8.7.0 FP4

This is **IBM Content Manager** — NOT IBM FileNet Content Manager (P8).
These are completely different products with different APIs, schemas, and architecture.
Never use `com.filenet.api.*` or P8/FileNet/Content Engine terminology.

**Version:** 8.7.0 Fix Pack 4 (8.7.00.400) — published February 21, 2025
**Reference:** https://www.ibm.com/docs/en/content-manager/8.7.0

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│              IBM Content Manager                     │
│                                                      │
│  ┌─────────────────┐    ┌──────────────────────┐    │
│  │  Library Server  │    │   Resource Manager   │    │
│  │  (metadata /     │    │   (binary content /  │    │
│  │   index / query) │    │    storage volumes)  │    │
│  └────────┬─────────┘    └──────────┬───────────┘    │
│           │                         │                │
│           └──────────┬──────────────┘                │
│                      │                               │
│              DB2 11.5.9 LUW                          │
│         (ICMADMIN schema — library server)           │
│         (ICMRM schema — resource manager)            │
└─────────────────────────────────────────────────────┘
         ↑
   IBM Content Navigator (ICN) — web client / admin UI
   WebSphere Application Server or Liberty (FP4)
```

Key components:
- **Library Server** — metadata, item types, attributes, security, querying
- **Resource Manager** — binary content (parts), storage volumes, migration, replication
- **System Administration Client** — Java Swing admin tool
- **Configuration Manager** — installation/configuration tool (cmcfgmgr_CM)
- **ICN** — web-based client and admin interface (FP4: full admin via ICN supported)

---

## Java SDK — `com.ibm.mm.sdk.*`

Always use the IBM Content Manager Java SDK. Never use FileNet/P8 API classes.

```java
// Correct imports for IBM Content Manager
import com.ibm.mm.sdk.server.*;
import com.ibm.mm.sdk.common.*;
import com.ibm.mm.sdk.common.DKConstant;

// Connection pattern
DKDatastoreICM datastore = new DKDatastoreICM();
try {
    datastore.connect("libraryServerName", "userId", "password", "");
    // work
} finally {
    datastore.disconnect();
    datastore.destroy();
}
```

**Core classes:**

| Class | Purpose |
|---|---|
| `DKDatastoreICM` | Repository connection |
| `DKLobICM` | Document / item object |
| `DKNVPairICM` | Attribute name-value pair |
| `DKSearchScope` | Query execution scope |
| `DKResults` | Query result set |
| `DKRetrieveOptionsICM` | Content retrieval options |
| `DKPidICM` | Persistent identifier (PID) for documents |
| `DKPartICM` | Document part (content object) |

---

## Always Disconnect and Destroy

Connection leaks are a critical failure mode in CM environments.

```java
DKDatastoreICM datastore = new DKDatastoreICM();
try {
    datastore.connect(host, userId, password, "");
    // work
} catch (DKException e) {
    // log DKException — always includes error code
    throw new RuntimeException("CM connect failed: " + e.getErrorCode() + " " + e.getMessage(), e);
} finally {
    try { datastore.disconnect(); } catch (Exception ignored) {}
    try { datastore.destroy(); } catch (Exception ignored) {}
}
```

- Always `disconnect()` then `destroy()` in a finally block
- Never reuse a datastore connection across threads — connections are not thread-safe
- For connection pooling use `CMBConnectionPool` (REST Services) or container-managed datasource

---

## Querying — XML Query / ICQRY

IBM Content Manager uses an XML-based query language, not FQL or SQL directly.

```java
// Build a query for item type "InvoiceDocument"
String xmlQuery = "<QUERY ITEMTYPE='InvoiceDocument'>" +
    "<CONDITION>" +
    "  <ATTRIBUTE name='InvoiceDate' operator='GT'>" +
    "    <VALUE>2024-01-01</VALUE>" +
    "  </ATTRIBUTE>" +
    "</CONDITION>" +
    "<MAXRESULTS>500</MAXRESULTS>" +
    "</QUERY>";

DKSearchScope searchScope = new DKSearchScope(datastore);
DKResults results = (DKResults) searchScope.evaluate(xmlQuery, 
    DKConstant.DK_CM_SEARCH, null);

try {
    DKDDO ddo = results.fetch();
    while (ddo != null) {
        // process document
        ddo = results.fetch();
    }
} finally {
    results.close();   // Always close result sets
}
```

- Always set `MAXRESULTS` — unbounded queries on large repositories will cause severe performance issues
- Always close `DKResults` in a finally block — unclosed results hold server-side cursors
- Item type names are case-sensitive and must match the library server definition exactly

---

## Retrieving Content (Parts)

```java
DKLobICM document = (DKLobICM) datastore.createDDO("InvoiceDocument", 
    DKConstant.DK_CM_DOCUMENT);
document.setPid(pid);
document.retrieve(DKConstant.DK_CM_CONTENT_YES);

try {
    DKPartICM part = (DKPartICM) document.getPartList().getFirstPart();
    if (part != null) {
        InputStream contentStream = part.getContent();
        // process content stream
    }
} finally {
    document.destroy();
}
```

- Use `DK_CM_CONTENT_NO` when only metadata is needed — never retrieve full content unnecessarily
- Retrieving content for large documents without streaming will cause out-of-memory on the JVM
- Always `destroy()` document objects in finally blocks

---

## Key DB2 Tables (ICMADMIN schema)

These are the core Library Server and Resource Manager tables.
Always filter aggressively — these tables can be very large.

```sql
-- Library Server — core tables
ICMADMIN.ICMSTDOCUMENTS      -- All stored items (primary item table)
ICMADMIN.ICMSTCOMPATTRS      -- Component attributes
ICMADMIN.ICMSTCOMPDEFS       -- Component type definitions
ICMADMIN.ICMSTNLSKEYWORDS    -- Item type / keyword names (NLS)

-- Resource Manager — critical operational tables
ICMADMIN.RMOBJECTS           -- All managed content objects (can be 100M+ rows)
ICMADMIN.RMREPLICATION       -- Replication tracking
ICMADMIN.RMCONFIGURATION     -- Resource manager runtime configuration
ICMADMIN.RMVOLUMES           -- Storage volume definitions
```

FP4 recommended indexes (from fix pack readme — add if not present):
```sql
-- Improves fix pack install and replication performance
CREATE INDEX IDX_REP1 ON ICMADMIN.RMREPLICATION 
    (PROCESSTIMEOUT ASC, REP_REPLICATETYPE ASC);
RUNSTATS ON TABLE ICMADMIN.RMREPLICATION 
    WITH DISTRIBUTION AND DETAILED INDEXES ALL;

-- Improves background RM performance
CREATE INDEX IDX_OBJ_STATUS ON ICMADMIN.RMOBJECTS 
    (OBJ_STATUS ASC, OBJ_REFERENCEDDATE ASC, OBJ_STAGEDVOLUMEID ASC);
RUNSTATS ON TABLE ICMADMIN.RMOBJECTS 
    WITH DISTRIBUTION AND DETAILED INDEXES ALL;
```

---

## Configuration Files

```
cmbicmsrvs.ini    — Library server connection configuration
                    Location: IBMCMROOT/config/
                    Key: ICMSCHEMA=ICMADMIN (must be UPPERCASE — Turkish locale issue)

cmbicmenv.ini     — Environment / server registry
                    Server entries must NOT have $v2- prefix for V8.7 GA compatibility
                    Use com.ibm.mm.sdk.util.cmbenvicm to manage entries safely
```

---

## REST Services (FP4)

FP4 adds full Liberty support with Java 21. REST Services are the preferred
integration path for new microservice integrations.

```
Base URL:  http://host:port/CMBRest/v1/
Auth:      Basic auth or token-based (configured in WAS/Liberty)
Key APIs:  GET  /itemtypes
           GET  /itemtypes/{name}?include=attributes  (FP3+)
           GET  /items/{pid}
           POST /items
           PUT  /items/{pid}
           POST /items/{pid}/move  (FP2+)
```

- New in FP4: privilege required to use REST Services (`CLIENT_REST_PRIVILEGE`)
- JDBC connection pooling supported in WAS and Liberty (FP3+)
- `CMBConnectionPool` for multi-server access

---

## Resource Manager Services

The Resource Manager runs background services that must be managed carefully:

| Service | Purpose | Impact if stopped |
|---|---|---|
| Purger | Deletes expired/orphaned objects | Content accumulates |
| Migrator | Moves content between storage volumes | Tiered storage doesn't function |
| Stager | Stages content for fast retrieval | Performance degrades |
| Replicator | Replicates content to replica volumes | Replicas go stale |

**Always stop RM services before:**
- Applying fix packs
- Major DB2 maintenance
- Storage volume changes

Stop via System Administration Client or RM Administration Console.
Never kill the WAS/Liberty process directly — graceful shutdown ensures in-flight operations complete.

---

## FP4 Specific — What Changed

Flag these in any code or config that references earlier behaviour:

- **DB2 12** now supported (in addition to 11.5.x) — flag DB2 version-specific syntax
- **TLS 1.3 minimum** supported — do not configure TLS 1.2-only connections
- **IBMJCEPlusFIPS** replaces IBMJCEFIPS in the RM — crypto provider references must use new name
- **GSKit** no longer installed by CM when using DB2 — use DB2's bundled GSKit
- **Outside In viewer engine (CMBOutsideInViewerEngine)** deprecated — do not use in new code
- **Liberty + Java 21** now supported for REST Services and Web Services
- **Threshold cycle** removed from RM Cycles tab — do not reference it in admin scripts
- **Item types** now support up to 415 attributes per component (was 250 before FP3)

---

## Kofax Integration

When writing scripts or code that interfaces between Kofax Capture and Content Manager:

- Kofax → CM: use the IBM Content Manager Release Script or custom release script
- Release scripts use the CM Java SDK (`com.ibm.mm.sdk.*`) — not FileNet API
- Log the CM PID (Persistent Identifier) of stored documents for traceability back to Kofax batch IDs
- Validate item type and attribute existence before attempting to store
- The Library Server returns `DKException` with specific error codes — always log the code, not just the message

---

## Common Failure Patterns (flag in review)

- Not closing `DKResults` — holds server-side cursors, causes Library Server resource exhaustion
- Not calling `destroy()` on document objects — memory leak in long-running processes
- Querying without `MAXRESULTS` — catastrophic on large repositories
- Reusing datastore connections across threads — race conditions, corrupt state
- Item type names in wrong case — Library Server returns "not found" with no clear message
- Connecting with admin credentials in application code — use a dedicated application account with least privilege
- Reading `cmbicmsrvs.ini` path from a hardcoded location — must be configurable per environment
