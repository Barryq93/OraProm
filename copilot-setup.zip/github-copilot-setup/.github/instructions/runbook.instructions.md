---
applyTo: "**/*runbook*,**/*runbook*,**/*incident*,**/*playbook*"
---

# Runbook & Operational Playbook Standards

Runbooks are operational documentation — they are used under pressure by engineers
who may not be the original author. Write for clarity and speed, not elegance.

---

## Runbook Structure (mandatory sections)

```markdown
# Runbook: [Component] — [Incident Title]

**Severity:**     P1 / P2 / P3
**Component:**    ECM | DB2 | Kofax | WAS | KTM | RTTI | Observability
**Platform:**     Windows 2019/2022 | RHEL 8.1 | Both
**Last Updated:** YYYY-MM-DD
**Owner:**        [team / person]
**Alert:**        [Prometheus alert name that triggers this runbook, if applicable]

---

## Symptoms
What the engineer observes that leads them here.
- Prometheus alert name / Grafana panel
- User-reported symptoms
- Log patterns (include exact log strings where possible)

---

## Immediate Actions (first 5 minutes)
Numbered steps. Specific commands. No ambiguity.
Mark steps that require elevated access with 🔐
Mark irreversible steps with ⚠️ IRREVERSIBLE

---

## Diagnostic Steps
How to confirm the root cause. Organised by hypothesis.

### Check 1 — [Hypothesis name]
```command or query```
Expected output if this is the cause: ...

### Check 2 — [Hypothesis name]
...

---

## Resolution Procedures

### Option A — [Most common resolution]
Steps...

### Option B — [Alternative if Option A doesn't apply]
Steps...

---

## Escalation Criteria
Escalate if:
- [Condition 1] → Escalate to: [person/team] via [channel]
- [Condition 2] → Escalate to: [person/team] via [channel]

---

## Post-Incident Checks
Verification steps to confirm full resolution before closing.
1. ...
2. ...

---

## Known Causes
| Date | Root Cause | Resolution | Notes |
|------|------------|------------|-------|

```

---

## Platform-Specific Diagnostic Commands

Include these in runbooks as needed — pre-built for the environment.

### DB2 (RHEL 8.1)

```bash
# Source environment first — always
. /home/db2inst1/sqllib/db2profile

# Active connections
db2 list applications show detail

# Lock waits
db2 get snapshot for locks on DBNAME | grep -A5 "Lock wait"

# Long-running queries
db2 "SELECT SUBSTR(STMT_TEXT,1,80), ELAPSED_TIME_MIN, AGENT_ID 
     FROM SYSIBMADM.LONG_RUNNING_SQL 
     ORDER BY ELAPSED_TIME_MIN DESC 
     FETCH FIRST 10 ROWS ONLY"

# Tablespace health
db2 "SELECT TBSP_NAME, TBSP_STATE, 
     DECIMAL(FLOAT(TBSP_USED_PAGES)/FLOAT(TBSP_TOTAL_PAGES)*100,5,2) AS PCT_USED
     FROM SYSIBMADM.TBSP_UTILIZATION ORDER BY PCT_USED DESC"

# DB2 error log location
cat /home/db2inst1/sqllib/db2dump/DIAG0000/db2diag.log | tail -100
```

### ECM / WAS (Windows Server 2019/2022)

```powershell
# WAS service status
Get-Service -DisplayName "*WebSphere*" | Select-Object Name, Status

# P8 Application Engine log (adjust path to your install)
Get-Content "C:\IBM\WebSphere\AppServer\profiles\AppSrv01\logs\server1\SystemOut.log" -Tail 100

# ECM Content Engine connectivity test (P8 Java ping)
# Run via wsadmin or test servlet — confirm URL is reachable
Invoke-WebRequest -Uri "http://ce-host:9080/wsi/FNCEWS40MTOM/" -UseBasicParsing

# WAS JVM heap (via wsadmin — run on WAS host)
# wsadmin.bat -lang jython -c "print AdminControl.getAttribute(AdminControl.queryNames('type=JVM,*'), 'heapSize')"
```

### Kofax Capture (Windows Server 2019/2022)

```powershell
# Kofax services
Get-Service -DisplayName "Kofax*" | Select-Object DisplayName, Status

# Batch queue summary — requires Kofax admin access
# Run via Kofax Capture Administration or query the Kofax DB directly

# Kofax Application log
Get-EventLog -LogName Application -Source "Kofax*" -Newest 50 |
    Select-Object TimeGenerated, EntryType, Message

# Kofax log directory (adjust to your install path)
Get-ChildItem "C:\Kofax\Capture\Logs\" -Filter "*.log" | 
    Sort-Object LastWriteTime -Descending | Select-Object -First 5
```

### Observability Stack

```bash
# Alloy health (Linux)
systemctl status alloy
journalctl -u alloy -n 100 --no-pager

# Alloy health (Windows)
Get-Service "Alloy" | Select-Object Status
Get-Content "C:\Program Files\GrafanaLabs\Alloy\logs\alloy.log" -Tail 100

# Pushgateway — check current metric values
curl http://pushgateway:9091/metrics | grep kofax_capture

# Prometheus — check scrape target health
curl http://prometheus:9090/api/v1/targets | python3 -m json.tool | grep -A3 '"health"'

# Loki — recent ingestion check
curl http://loki:3100/ready
```

---

## Runbook Quality Standards

Before marking a runbook complete:
- [ ] Every command is specific and tested (not illustrative)
- [ ] All paths reflect actual install locations (not defaults)
- [ ] Escalation paths name actual people or teams, not roles
- [ ] `runbook_url` in the corresponding Prometheus alert rule points here
- [ ] Known Causes table has at least one entry (or "No incidents recorded yet")
- [ ] Irreversible steps are marked ⚠️
- [ ] Steps requiring elevated access are marked 🔐
