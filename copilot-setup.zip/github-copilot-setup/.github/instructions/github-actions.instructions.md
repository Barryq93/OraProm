---
applyTo: "**/.github/workflows/*.yml,**/.github/workflows/*.yaml"
---

# GitHub Actions & CI/CD

Apply when writing or reviewing GitHub Actions workflows for the documents platform.

---

## Workflow Header Standard

```yaml
# =============================================================================
# WORKFLOW:     deploy-monitoring.yml
# PURPOSE:      Deploy Alloy config updates to documents platform
# TRIGGERS:     Push to main (scripts/monitoring/**), manual dispatch
# ENVIRONMENTS: prod (requires approval), uat (auto-deploy)
# SECRETS:      ANSIBLE_VAULT_PASSWORD, MIMIR_REMOTE_WRITE_URL
# AUTHOR:       [name] — YYYY-MM-DD
# =============================================================================
name: Deploy Monitoring Config

on:
  push:
    branches: [main]
    paths:
      - 'scripts/monitoring/**'
      - '.github/workflows/deploy-monitoring.yml'
  workflow_dispatch:
    inputs:
      environment:
        description: 'Target environment'
        required: true
        default: 'uat'
        type: choice
        options: [uat, prod]
```

---

## Secrets Handling

```yaml
# ✅ Correct — reference via secrets context
- name: Configure Alloy
  env:
    MIMIR_PASSWORD: ${{ secrets.MIMIR_REMOTE_WRITE_PASSWORD }}
    VAULT_PASS: ${{ secrets.ANSIBLE_VAULT_PASSWORD }}
  run: |
    echo "$VAULT_PASS" > .vault_pass
    ansible-playbook deploy_alloy.yml --vault-password-file .vault_pass
    rm -f .vault_pass

# ❌ Never
- run: ansible-playbook deploy.yml -e "password=hardcoded123"
```

**Secrets rules:**
- All secrets via `${{ secrets.SECRET_NAME }}` — never hardcoded or in env files committed to repo
- Mask sensitive values: `echo "::add-mask::$SECRET_VALUE"` before using in scripts
- Temp files containing secrets: always `rm -f` in the same step or a `post` step
- Use environment-scoped secrets where possible — prod secrets should not be accessible from uat jobs

---

## Environment Protection (prod requires approval)

```yaml
jobs:
  deploy-uat:
    runs-on: ubuntu-latest
    environment: uat          # No approval gate
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to UAT
        run: ansible-playbook site.yml -i inventory/uat/

  deploy-prod:
    runs-on: ubuntu-latest
    environment: prod         # Requires reviewer approval — configure in repo Settings
    needs: [deploy-uat]       # Must pass UAT first
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to Production
        run: ansible-playbook site.yml -i inventory/prod/
```

---

## Self-Hosted Runners (for Windows / internal network access)

The documents platform runs on an internal network — GitHub-hosted runners cannot reach
WAS, ECM, DB2, or Kofax hosts. Use self-hosted runners.

```yaml
jobs:
  deploy:
    runs-on: [self-hosted, windows, documents-platform]  # Label your runner appropriately
    # OR for Linux jobs:
    runs-on: [self-hosted, linux, documents-platform]
```

Runner labels to define: `documents-platform`, `windows`, `linux`
Runner must have: Ansible, PowerShell 5.1+, network access to target hosts, vault password available.

---

## Workflow Standards

```yaml
jobs:
  validate-and-deploy:
    runs-on: [self-hosted, linux, documents-platform]
    timeout-minutes: 30          # Always set — prevents hung jobs consuming runner hours

    steps:
      - uses: actions/checkout@v4

      - name: Lint PowerShell scripts
        shell: pwsh
        run: |
          $issues = Get-ChildItem -Recurse -Filter "*.ps1" |
            Invoke-ScriptAnalyzer -Severity Error
          if ($issues) { $issues; exit 1 }

      - name: Validate Alloy config
        run: alloy fmt --check monitoring/alloy/

      - name: Validate Ansible playbooks
        run: ansible-playbook --syntax-check site.yml -i inventory/uat/

      - name: Run deployment
        run: ansible-playbook site.yml -i inventory/uat/ --diff
```

**Workflow rules:**
- Always set `timeout-minutes` — no job without a timeout
- `actions/checkout@v4` — pin to major version, not `@main` or `@latest`
- Use `--diff` on Ansible runs in CI — shows what would change in logs
- Lint before deploy — catch issues before touching infrastructure
- `--syntax-check` on all playbooks before running

---

## Permissions (least privilege)

```yaml
permissions:
  contents: read      # Default — restrict further if possible
  # Only add permissions actually needed:
  # issues: write     — if the workflow creates issues
  # pull-requests: write — if it comments on PRs
```

Never use `permissions: write-all` — scope to what the workflow actually needs.
