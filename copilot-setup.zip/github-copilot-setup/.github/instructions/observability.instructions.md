---
applyTo: "**/*.alloy,**/*.promql,**/*prometheus*,**/*grafana*,**/*loki*,**/*alert*.yml,**/*alert*.yaml,**/*recording*.yml"
---

# Observability — Prometheus, Grafana Alloy, Loki, Pushgateway, Grafana

## Environment Context

- **OS mix**: Windows Server 2019/2022 (Kofax, WAS, ECM App Engine) + RHEL 8.1 (ECM Content Engine, DB2)
- **Alloy**: Grafana Alloy using **River syntax** (`.alloy` files) — not the legacy Grafana Agent YAML format
- **Pushgateway**: primary mechanism for pushing metrics from Windows PowerShell monitoring scripts
- **Loki**: log aggregation from both Windows Event Log / file logs and Linux syslog/journald
- **Splunk**: co-exists with Loki — Splunk for compliance/audit/SIEM, Loki for operational observability

---

## Metric Naming Conventions

All metrics produced by this environment must follow this naming scheme so
dashboard queries and alert rules align with monitoring script outputs.

```
# Format: <platform>_<component>_<measurement>_<unit>
# All lowercase, underscores only, no hyphens

# ECM / FileNet
ecm_content_engine_response_ms
ecm_object_store_document_count_total
ecm_was_jvm_heap_used_bytes
ecm_was_thread_pool_active_total
ecm_was_thread_pool_max_total

# DB2
db2_tablespace_used_bytes{tablespace="USERSPACE1", instance="DB2INST1"}
db2_tablespace_total_bytes{tablespace="USERSPACE1"}
db2_lock_waits_active_total
db2_long_running_queries_total{threshold_minutes="5"}
db2_connections_active_total
db2_connections_max_total

# Kofax
kofax_capture_batch_queue_depth_total{state="ready"}
kofax_capture_batch_queue_depth_total{state="error"}
kofax_capture_batch_queue_depth_total{state="processing"}
kofax_ktm_classification_errors_total
kofax_rtti_queue_depth_total

# Windows host (pushed via Pushgateway from monitoring scripts)
windows_disk_used_bytes{drive="C", host="HOSTNAME"}
windows_disk_total_bytes{drive="C", host="HOSTNAME"}
windows_service_up{service="KofaxCapture", host="HOSTNAME"}  # 1=up, 0=down

# Linux host (scraped by Alloy node_exporter)
# Use standard node_exporter metric names — do not rename
```

**Labels — standard set for all metrics:**
```
host        = server hostname (FQDN preferred)
environment = prod | uat | dev
component   = ecm | db2 | kofax | was | ktm | rtti
platform    = windows | linux
```

---

## Pushgateway — PowerShell Integration

This is the primary path for Windows/Kofax metrics into Prometheus.
The monitoring scripts use this pattern:

```powershell
function Push-MetricToGateway {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$PushgatewayUrl,       # e.g. "http://pushgateway:9091"

        [Parameter(Mandatory)]
        [string]$JobName,              # e.g. "kofax_monitoring"

        [Parameter(Mandatory)]
        [string]$MetricName,

        [Parameter(Mandatory)]
        [double]$Value,

        [hashtable]$Labels = @{},

        [ValidateSet('gauge','counter')]
        [string]$Type = 'gauge',

        [string]$Help = ''
    )

    # Build label string for URL path grouping
    $labelPath = ($Labels.GetEnumerator() |
        ForEach-Object { "$($_.Key)/$($_.Value)" }) -join '/'

    $uri = "$PushgatewayUrl/metrics/job/$JobName"
    if ($labelPath) { $uri += "/$labelPath" }

    # Build Prometheus text format payload
    $payload = @"
# HELP $MetricName $Help
# TYPE $MetricName $Type
$MetricName{$(($Labels.GetEnumerator() | ForEach-Object { "$($_.Key)=`"$($_.Value)`"" }) -join ',')} $Value
"@

    try {
        Invoke-RestMethod -Uri $uri -Method Post -Body $payload `
            -ContentType 'text/plain; charset=utf-8' -UseBasicParsing
        Write-Verbose "Pushed $MetricName=$Value to $uri"
    } catch {
        Write-Error "Pushgateway push failed for $MetricName`: $_"
    }
}

# Usage — Kofax batch queue depth
Push-MetricToGateway `
    -PushgatewayUrl $env:PUSHGATEWAY_URL `
    -JobName 'kofax_monitoring' `
    -MetricName 'kofax_capture_batch_queue_depth_total' `
    -Value $errorBatchCount `
    -Labels @{ state='error'; host=$env:COMPUTERNAME; environment='prod' } `
    -Type 'gauge' `
    -Help 'Number of Kofax Capture batches in error state'
```

**Critical Pushgateway rules:**
- Always DELETE the job metrics after a completed one-shot job — otherwise stale metrics persist
- Use `gauge` for point-in-time values (queue depth, heap %, disk usage)
- Use `counter` only for monotonically increasing values — and only if the script tracks the delta correctly
- Pushgateway is for batch/scheduled jobs — not for long-running service metrics
- One job name per monitoring script — do not reuse across unrelated scripts

```powershell
# DELETE stale metrics after a one-shot job completes
Invoke-RestMethod -Uri "$PushgatewayUrl/metrics/job/$JobName" -Method Delete -UseBasicParsing
```

---

## Grafana Alloy — River Syntax

**Always use River syntax (`.alloy` files). Never use legacy YAML Grafana Agent format.**
Alloy components are declarative and pipeline-based.

### Scraping Windows Hosts (via windows_exporter)

```alloy
// windows_exporter scrape — Kofax / WAS / ECM App Engine hosts
prometheus.scrape "windows_hosts" {
  targets = [
    {"__address__" = "kofax-host-01:9182", "component" = "kofax", "platform" = "windows"},
    {"__address__" = "ecm-appeng-01:9182",  "component" = "ecm",   "platform" = "windows"},
    {"__address__" = "was-host-01:9182",    "component" = "was",   "platform" = "windows"},
  ]
  scrape_interval = "60s"
  metrics_path    = "/metrics"
  forward_to      = [prometheus.remote_write.mimir.receiver]
}
```

### Scraping Linux Hosts (RHEL 8.1 — node_exporter)

```alloy
// node_exporter scrape — ECM Content Engine, DB2 (RHEL 8.1)
prometheus.scrape "linux_hosts" {
  targets = [
    {"__address__" = "ecm-ce-01:9100",  "component" = "ecm",  "platform" = "linux"},
    {"__address__" = "db2-host-01:9100", "component" = "db2", "platform" = "linux"},
  ]
  scrape_interval = "30s"
  forward_to      = [prometheus.remote_write.mimir.receiver]
}
```

### Scraping Pushgateway

```alloy
// Pushgateway — receives metrics from Windows PowerShell monitoring scripts
prometheus.scrape "pushgateway" {
  targets = [{"__address__" = "pushgateway:9091"}]
  scrape_interval    = "60s"
  honor_labels       = true   // CRITICAL — preserves job/instance labels pushed by scripts
  forward_to         = [prometheus.remote_write.mimir.receiver]
}
```

### Log Collection — Windows Event Log

```alloy
// Windows Event Log → Loki
loki.source.windowsevent "kofax_application_log" {
  eventlog_name    = "Application"
  use_incoming_timestamp = false
  forward_to       = [loki.write.default.receiver]
  labels = {
    job       = "windows_eventlog",
    component = "kofax",
    host      = constants.hostname,
    platform  = "windows",
  }
}

// Windows file log (Kofax batch logs, ECM App Engine logs)
loki.source.file "kofax_batch_logs" {
  targets = [
    {__path__ = "C:/Kofax/Capture/Logs/*.log", component = "kofax"},
    {__path__ = "C:/IBM/ECM/logs/*.log",        component = "ecm"},
  ]
  forward_to = [loki.write.default.receiver]
}
```

### Log Collection — Linux (RHEL 8.1)

```alloy
// Linux journal → Loki (ECM Content Engine, DB2)
loki.source.journal "linux_journal" {
  forward_to = [loki.write.default.receiver]
  relabel_rules = loki.relabel.linux_labels.rules
  labels = {
    job      = "journal",
    platform = "linux",
    host     = constants.hostname,
  }
}

loki.relabel "linux_labels" {
  rule {
    source_labels = ["__journal__systemd_unit"]
    target_label  = "unit"
  }
  forward_to = [loki.write.default.receiver]
}
```

### Remote Write

```alloy
prometheus.remote_write "mimir" {
  endpoint {
    url = env("MIMIR_REMOTE_WRITE_URL")
    basic_auth {
      username = env("MIMIR_USERNAME")
      password = env("MIMIR_PASSWORD")
    }
  }
}

loki.write "default" {
  endpoint {
    url = env("LOKI_PUSH_URL")
  }
}
```

**Alloy rules:**
- Never hard-code URLs, credentials, or hostnames — use `env()` for all external references
- `honor_labels = true` on Pushgateway scrape — this is not optional
- One `forward_to` chain per signal type — don't mix metrics and logs receivers
- Label at collection time — relabelling after the fact is harder to maintain

---

## Prometheus Alert Rules

```yaml
# alert-rules-documents-platform.yml
groups:
  - name: documents.platform.critical
    rules:
      - alert: DB2TablespaceHighUsage
        expr: |
          (db2_tablespace_used_bytes / db2_tablespace_total_bytes) * 100 > 85
        for: 5m
        labels:
          severity: critical
          component: db2
          team: documents
        annotations:
          summary: "DB2 tablespace {{ $labels.tablespace }} critically high"
          description: "Tablespace {{ $labels.tablespace }} on {{ $labels.host }} is {{ $value | humanizePercentage }} used."
          runbook_url: "https://wiki.internal/runbooks/db2-tablespace"

      - alert: KofaxBatchErrorQueueHigh
        expr: kofax_capture_batch_queue_depth_total{state="error"} > 50
        for: 10m
        labels:
          severity: critical
          component: kofax
          team: documents
        annotations:
          summary: "Kofax error batch queue elevated on {{ $labels.host }}"
          description: "{{ $value }} batches in error state. Threshold: 50."
          runbook_url: "https://wiki.internal/runbooks/kofax-batch-errors"

      - alert: WindowsServiceDown
        expr: windows_service_up == 0
        for: 2m
        labels:
          severity: critical
          component: "{{ $labels.component }}"
          team: documents
        annotations:
          summary: "Service {{ $labels.service }} down on {{ $labels.host }}"
          runbook_url: "https://wiki.internal/runbooks/windows-service-recovery"
```

**Alert rule standards:**
- Always include `for` duration — no instant alerts on transient spikes
- Always include `runbook_url` annotation — link to the actual runbook
- `severity` label values: `critical`, `warning`, `info` — consistent across all rules
- `team` label for alert routing: `documents`
- Humanize values in `description` using `| humanize`, `| humanizePercentage`, `| humanizeDuration`

---

## PromQL Patterns

```promql
# Rate of change (use rate() for counters, not irate() for dashboards — irate() is for spikes)
rate(kofax_capture_batch_queue_depth_total[5m])

# Percentage calculation — tablespace usage
(db2_tablespace_used_bytes{tablespace="USERSPACE1"} 
  / db2_tablespace_total_bytes{tablespace="USERSPACE1"}) * 100

# Windows service availability across all hosts
count(windows_service_up{service="KofaxCapture"} == 1)
  / count(windows_service_up{service="KofaxCapture"})

# Top 5 hosts by heap usage
topk(5, ecm_was_jvm_heap_used_bytes / ecm_was_jvm_heap_max_bytes * 100)

# Recording rule pattern — pre-compute expensive queries
# In recording_rules.yml:
# - record: job:db2_tablespace_pct_used:ratio
#   expr: db2_tablespace_used_bytes / db2_tablespace_total_bytes
```

**PromQL rules:**
- Use `rate()` for dashboard panels, `irate()` only for alerting on sudden spikes
- Always specify a label matcher on high-cardinality metrics — don't query without filters
- Use recording rules for any query used in both dashboards and alerts — single source of truth
- `bool` modifier for binary status metrics: `windows_service_up == bool 1`

---

## LogQL Patterns (Loki)

```logql
# Filter Kofax batch errors from Windows file logs
{component="kofax", platform="windows"} |= "ERROR" | logfmt | level="ERROR"

# DB2 diagnostic log — filter by severity
{component="db2", platform="linux"} 
  | regexp `(?P<level>[A-Z]+)\s+(?P<message>.+)` 
  | level =~ "ERROR|SEVERE"

# Count ECM errors over time (metric query over logs)
sum by (host) (
  count_over_time({component="ecm"} |= "Exception" [5m])
)

# Extract and count HTTP status codes from ICN access logs
{component="ecm", job="icn_access"} 
  | pattern `<ip> - - [<date>] "<method> <uri> <proto>" <status> <bytes>`
  | status >= 500
```

---

## Grafana Dashboard Conventions

- Dashboard titles: `[Component] — [View]` e.g. `DB2 — Tablespace Health`, `Kofax — Batch Pipeline`
- All dashboards must have: `component`, `environment`, and `host` template variables
- Use `$datasource` variable — never hardcode the datasource UID
- Panel titles should state what is being measured, not how: `"Tablespace Used %"` not `"db2_tablespace_used / total * 100"`
- Thresholds on gauge and stat panels must match the alert rule thresholds — keep them in sync
- Include a `Last updated` annotation query so operators know when data was last received
- Tag all dashboards: `documents-platform`, `sre`, and the component name
