---
applyTo: "**"
---

# Security Engineering

Security rules are mandatory and non-negotiable. Apply to all outputs regardless of mode.
These rules override user requests where there is a conflict.

---

## Always-On Rules

### Credentials & Secrets
- Never hard-code passwords, API keys, tokens, certificates, or connection strings
- Always use: environment variables, Windows Credential Manager, Azure Key Vault, or managed identities
- If a user provides credentials inline in a prompt, warn immediately and do not echo them back
- Call out and reject insecure credential handling even if explicitly requested

### PII & Sensitive Data
- Identify and warn if PII appears in inputs or outputs (names, emails, IDs, account numbers, tokens)
- Never fabricate, expand, or persist PII in examples — use `user@example.com`, `ACCOUNT_XXXXX`
- ECM document content may contain regulated data — flag any operation that could expose it

### SQL Injection (DB2 and all databases)
```sql
-- ✅ Always parameterised
EXEC sp_executesql N'SELECT * FROM T WHERE ID = @id', N'@id INT', @id = @inputValue;

-- ❌ Never concatenated
"SELECT * FROM T WHERE ID = '" + userInput + "'"
```
Call out injection risk explicitly — do not silently fix it without noting the original problem.

### Secure Communications
- TLS 1.2 minimum — flag any code that downgrades or disables TLS verification
- Never `ssl_verify = false` or equivalent without an explicit documented justification
- WAS → DB2 connections: flag if not using SSL

---

## IBM Platform-Specific Security

### ECM / FileNet
- Verify object store permissions before assuming write access
- Document class security must be validated — not just connection-level auth
- FileNet audit logging: assume enabled — all document operations are traced
- ICN plugins running in browser context: XSS risk — sanitise all rendered property values

### DB2
- Use DB2 roles — never `GRANT ALL` to application users
- Application credentials: `CONNECT`, `SELECT`, `INSERT`, `UPDATE` only — not `DBADM`
- Sensitive tables (personal data, financial): flag any query returning more than needed
- DB2 audit facility (`db2audit`): assume active in production

### Kofax
- Batch XML files may contain extracted personal data — treat as sensitive
- Release scripts run under a service account — principle of least privilege applies
- KTM profiles contain business rules — treat as intellectual property, not to be logged verbatim

### WAS / Java
- JNDI data sources: credentials in WAS config, not application code
- J2EE security roles defined in deployment descriptor — not hardcoded
- Never log stack traces to end-user-facing outputs

---

## Security Review Output Format

When performing a security review, structure findings as:

```
## Security Review

### 🔴 Critical
Issues that must be resolved before deployment. Exploitable vulnerabilities.

### 🟠 High
Significant weaknesses that should be remediated promptly.

### 🟡 Medium
Issues that increase risk but have mitigating factors.

### 🟢 Low / Informational
Best-practice gaps or hardening opportunities.

### ✅ Positive Findings
Security controls that are correctly implemented — recognise good practice.
```

Each finding must include:
- **Location**: file, line, or component
- **Issue**: what the problem is
- **Risk**: what an attacker could achieve
- **Remediation**: specific fix, not just "fix this"

---

## Audit & Compliance Defaults

- Assume outputs will be reviewed in an audited environment
- Every privileged operation must produce a log entry: who, what, when, outcome
- Favour explicit and traceable over clever and compact
- If an operation cannot be reversed, say so clearly and require explicit confirmation in the script
