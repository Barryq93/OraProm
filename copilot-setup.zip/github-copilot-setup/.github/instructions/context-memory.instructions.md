---
applyTo: "**"
---

# Context Memory & Token Management

This skill governs how Copilot maintains accuracy and coherence across long sessions.
Apply these rules throughout every conversation, not just when explicitly invoked.

---

## Mandatory Context Pulse

Before responding to any request involving code, scripts, architecture, or file changes,
output this block first:

```
> **Context Pulse**
> - Current task: [one sentence]
> - Files in scope: [list active files]
> - Key decisions locked this session: [max 5 bullets]
> - Assumptions I am carrying: [anything inferred but not confirmed]
> - Confidence: [High / Medium / Low — if Low, explain why]
```

If confidence is Low on any item, resolve it before proceeding.

---

## Drift Detection — Hard Stop Rules

STOP and explicitly flag before proceeding if any of the following are true:

- You are about to reference a variable, function, file, or module not visible in current context
- You are unsure whether a prior decision was confirmed or only suggested
- You are about to make a change that contradicts something from earlier in the session
- You have lost track of which files have already been modified

When flagging, use:
```
## ⚠️ Context Drift Detected
Issue: [what is unclear or contradictory]
Last known state: [what you believe was agreed]
Action required: [what the user needs to clarify]
```

Do not silently resolve drift by guessing.

---

## Session Checkpoints

After every 5 exchanges on the same task, output a checkpoint unprompted:

```
## Session Checkpoint
✅ Done: [completed items]
🔄 Remaining: [what is still outstanding]
🔒 Decisions locked: [confirmed choices that should not be revisited]
❓ Open questions: [anything unresolved or deferred]
```

---

## Token Efficiency Rules

- Never repeat code already shown in this session unless explicitly asked
- Prefer diffs and targeted edits over full file rewrites
- For large files, work section-by-section and confirm before moving on
- When summarising prior context, use the checkpoint format — do not re-narrate in prose
- If a full file rewrite is genuinely necessary, state why before doing it

---

## Context Boundary Rules

- Do not carry assumptions from one task into a new, unrelated task
- If the user starts a clearly new topic, reset the Context Pulse
- Treat each new file opened as a new scope boundary — re-establish what is known about it
  before editing

---

## What This Skill Does NOT Do

- It cannot access previous VS Code sessions — session memory resets each time
- It cannot read files not currently open in the workspace
- If a prior decision is relevant but not visible, ask: "Can you re-share X so I stay consistent?"
