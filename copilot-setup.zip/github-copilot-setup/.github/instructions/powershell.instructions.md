---
applyTo: "**/*.ps1,**/*.psm1,**/*.psd1"
---

# PowerShell Engineering

Target runtime: **PowerShell 5.1 on Windows Server** unless explicitly told otherwise.
Never suggest PowerShell 7+ features without flagging the version dependency.

---

## Mandatory Script Header

Every script must begin with this block — no exceptions:

```powershell
<#
.SYNOPSIS
    One-line description of what this script does.

.DESCRIPTION
    Full description including context, purpose, and any relevant background.

.PARAMETER ParameterName
    Description of each parameter.

.EXAMPLE
    .\ScriptName.ps1 -Param1 Value1
    Describe what this example does.

.NOTES
    Author:       [your name / Copilot]
    Created:      YYYY-MM-DD
    Modified:     YYYY-MM-DD
    Version:      1.0.0
    Dependencies: [modules, external tools, APIs required]
    Assumptions:  [what this script takes for granted]
    Limitations:  [known edge cases not handled]
    Environment:  Windows Server / PowerShell 5.1
#>
```

---

## Function Standards

All functions must use advanced function syntax:

```powershell
function Verb-Noun {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$ParameterName
    )

    begin { }
    process { }
    end { }
}
```

- Use approved PowerShell verbs (`Get-Verb` for reference)
- `[CmdletBinding()]` on every function — enables `-Verbose`, `-Debug`, `-WhatIf`
- `[ValidateNotNullOrEmpty()]` on all mandatory string parameters
- Use `begin/process/end` blocks for pipeline-aware functions

---

## Error Handling

```powershell
try {
    # operation
} catch [System.IO.IOException] {
    Write-Error "IO failure: $_"
    throw
} catch {
    Write-Error "Unexpected error in [FunctionName]: $_"
    throw
} finally {
    # cleanup always runs
}
```

- Use `Write-Error` for errors — never `Write-Host` for error output
- Use `Write-Verbose` for diagnostic output, not `Write-Host`
- Always re-throw after logging unless the error is intentionally swallowed (comment why)
- Use `$ErrorActionPreference = 'Stop'` at script scope for unhandled exceptions

---

## Secrets & Credentials

```powershell
# ✅ Correct — retrieve from secure store
$credential = Get-StoredCredential -Target 'MyApp'
$apiKey = [System.Environment]::GetEnvironmentVariable('MY_API_KEY', 'Machine')

# ❌ Never do this
$password = "P@ssword123"
$apiKey = "abc123secret"
```

- Never hard-code credentials, tokens, or keys
- Use `Get-StoredCredential`, Windows Credential Manager, or environment variables
- For Azure: use managed identities or Key Vault references

---

## Logging Standards

```powershell
function Write-Log {
    [CmdletBinding()]
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','DEBUG')]
        [string]$Level = 'INFO'
    )
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$timestamp] [$Level] $Message"
    Write-Verbose $entry
    Add-Content -Path $script:LogFile -Value $entry
}
```

- All scripts with scheduled or automated execution must write to a log file
- Log path should be a parameter with a sensible default
- Log format: `[YYYY-MM-DD HH:mm:ss] [LEVEL] Message`

---

## Kofax-Specific Patterns

```powershell
# Kofax COM object — always release explicitly
$kfxApp = New-Object -ComObject "Kofax.SessionManager"
try {
    # work
} finally {
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($kfxApp) | Out-Null
    [GC]::Collect()
}
```

- Always release COM objects in a `finally` block
- COM interaction is single-threaded — never parallelize Kofax COM calls
- For RTTI/KTM: note if the operation is stateful (session-bound)

---

## Style Rules

- Indent with 4 spaces — no tabs
- One blank line between functions
- Opening brace on the same line: `function Name {`
- Use `$null` not `""` for empty checks where possible
- Prefer `Where-Object { }` over `.Where({ })` for PS 5.1 compatibility
- Always quote paths: `"$env:SystemRoot\System32"`
