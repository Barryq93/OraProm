---
applyTo: "**"
---

# Code Review — Always-On Standards

This skill applies Copilot's review lens automatically. It runs alongside any code
generation or editing, not just when explicitly invoked.
For a full structured review workflow, use `#code-review.prompt.md`.

---

## Passive Review (applies during all code generation)

While producing code, Copilot must internally check and flag:

- **Hardcoded credentials, secrets, or environment-specific values** — flag before returning
- **Unparameterised SQL** — flag and fix before returning
- **Missing error handling** — bare `catch {}`, swallowed exceptions, unchecked return codes
- **Missing resource cleanup** — open connections, file handles, COM objects, DB2 cursors
- **Unbounded operations** — queries without `FETCH FIRST`, loops without exit conditions
- **Version-unsafe syntax** — PS 7+ features in PS 5.1 context, DB2 12.x features on 11.5.9

If any of the above are present in generated code, fix them AND note them in the self-review block.
Do not silently fix without noting what was wrong.

---

## Peer Review Lens (when reviewing existing code)

Apply three passes in order:

### Pass 1 — Security (from security.instructions.md)
Security findings always come first. If a critical security issue is found,
flag it prominently before any other feedback.

### Pass 2 — Domain Correctness
Apply the relevant skill for the code type:
- PowerShell → powershell.instructions.md
- Shell → shell.instructions.md  
- SQL / DB2 → db2-dba.instructions.md
- ECM / Java → ecm.instructions.md
- Alloy / PromQL / LogQL → observability.instructions.md

### Pass 3 — General Quality
- Does the code match its stated intent?
- Are edge cases and error states handled?
- Is the logic readable without explanation?
- Are there any performance risks?
- Is it testable / verifiable?

---

## Review Output Format

```
## Code Review

### 🔴 Blockers
[Quote line/block] — Issue — Recommended fix

### 🟡 Recommendations
[Quote line/block] — Issue — Recommended fix

### 🟢 Suggestions
[Quote line/block] — Optional improvement

### ✅ What's Done Well
[Specific callout — never skip this section]

### Verdict
Approve | Approve with minor changes | Request changes
```

---

## What a Reviewer Notices That a Writer Misses

Flag these patterns even if they are not explicitly asked about:

- Scripts that work in happy path only and have no behaviour on failure
- Monitoring scripts that don't push a metric on failure (silent absence of data)
- DB2 queries joining large ECM tables without filtering on date or document class
- PowerShell that uses `Write-Host` instead of `Write-Verbose` / `Write-Error`
- Alloy config with hardcoded hostnames or credentials in plain text
- Alert rules without a `runbook_url` annotation
- Loki queries without label matchers (full log scan)
- COM object instantiation without `finally` block cleanup
