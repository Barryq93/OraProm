---
applyTo: "**/*.yml,**/*.yaml"
---

# Ansible — Automation & Configuration Management

Target: mixed Windows Server 2019/2022 and RHEL 8.1 environment.
All playbooks must be idempotent. If a task cannot be made idempotent, document why.

---

## Role Structure (always use roles for anything reusable)

```
roles/
└── ecm_monitoring/
    ├── tasks/
    │   ├── main.yml          # Entrypoint — imports subtask files
    │   ├── install.yml
    │   └── configure.yml
    ├── handlers/
    │   └── main.yml          # Service restart handlers
    ├── defaults/
    │   └── main.yml          # Default variables (lowest precedence — safe to override)
    ├── vars/
    │   └── main.yml          # Role-internal vars (high precedence — not for overriding)
    ├── templates/
    │   └── config.j2         # Jinja2 templates
    ├── files/
    │   └── static_file       # Static files to copy
    └── meta/
        └── main.yml          # Role dependencies
```

---

## Playbook Header Standard

```yaml
---
# =============================================================================
# PLAYBOOK:     deploy_alloy_monitoring.yml
# PURPOSE:      Deploy Grafana Alloy on documents platform hosts
# TARGETS:      documents_platform (Windows + Linux)
# AUTHOR:       [name]
# CREATED:      YYYY-MM-DD
# DEPENDENCIES: roles/alloy_deploy, ansible-windows collection
# ASSUMPTIONS:  WinRM configured on Windows hosts, SSH on Linux
# VARIABLES:    See group_vars/documents_platform/vars.yml
# =============================================================================
- name: Deploy Grafana Alloy — Documents Platform
  hosts: documents_platform
  gather_facts: true
  become: "{{ ansible_os_family != 'Windows' }}"  # become only on Linux
  vars_files:
    - group_vars/all/vault.yml
  roles:
    - alloy_deploy
```

---

## Inventory Structure

```ini
# inventory/hosts.ini

[ecm_appengine]
ecm-appeng-01.internal   ansible_os_family=Windows  component=ecm
ecm-appeng-02.internal   ansible_os_family=Windows  component=ecm

[ecm_content_engine]
ecm-ce-01.internal       ansible_os_family=RedHat   component=ecm

[db2_hosts]
db2-host-01.internal     ansible_os_family=RedHat   component=db2

[kofax_hosts]
kofax-host-01.internal   ansible_os_family=Windows  component=kofax
kofax-host-02.internal   ansible_os_family=Windows  component=kofax

[was_hosts]
was-host-01.internal     ansible_os_family=Windows  component=was

[documents_platform:children]
ecm_appengine
ecm_content_engine
db2_hosts
kofax_hosts
was_hosts

[windows:children]
ecm_appengine
kofax_hosts
was_hosts

[linux:children]
ecm_content_engine
db2_hosts
```

---

## Windows vs Linux Task Handling

Always gate OS-specific tasks explicitly — never assume:

```yaml
- name: Configure Alloy — Linux
  ansible.builtin.template:
    src: alloy-linux.alloy.j2
    dest: /etc/alloy/config.alloy
    owner: alloy
    group: alloy
    mode: '0640'
  when: ansible_os_family == "RedHat"
  notify: restart alloy linux

- name: Configure Alloy — Windows
  ansible.windows.win_template:
    src: alloy-windows.alloy.j2
    dest: 'C:\Program Files\GrafanaLabs\Alloy\config.alloy'
  when: ansible_os_family == "Windows"
  notify: restart alloy windows
```

**Windows-specific rules:**
- Use `ansible.windows.*` collection modules — not `ansible.builtin` for Windows
- WinRM must be configured — document the prerequisite
- Windows paths use backslash in YAML strings: `'C:\Path\To\File'` (single quotes)
- `become: false` on all Windows plays — use `ansible_user` with admin rights instead
- Check Windows firewall rules if connectivity fails — it's not always WinRM

---

## Secrets & Vault

```yaml
# group_vars/all/vault.yml — encrypt this file with ansible-vault
# ansible-vault encrypt group_vars/all/vault.yml

vault_pushgateway_url: "http://pushgateway.internal:9091"
vault_mimir_password: "..."
vault_db2_monitor_password: "..."

# Reference in playbooks via vars.yml (never reference vault_ vars directly in tasks)
# group_vars/all/vars.yml
pushgateway_url: "{{ vault_pushgateway_url }}"
```

**Vault rules:**
- All secrets in vault-encrypted files (`vault_` prefix convention)
- Wrapper vars in plain `vars.yml` — tasks reference wrappers, not vault vars directly
- Never commit unencrypted vault files — add `*.vault.yml` to `.gitignore` only if unencrypted
- Use `--ask-vault-pass` or `--vault-password-file` — never `-e vault_password=...` on CLI

---

## Idempotency Patterns

```yaml
# ✅ Idempotent — module handles state check
- name: Ensure monitoring service is running
  ansible.windows.win_service:
    name: alloy
    state: started
    start_mode: auto

# ✅ Idempotent — creates_/removes: guards
- name: Run DB2 health check script
  ansible.builtin.command: /opt/scripts/db2_healthcheck.sh
  args:
    creates: /var/run/db2_healthcheck.lock  # Only run if lock file doesn't exist

# ⚠️ NOT idempotent — raw command, no state check
- name: Restart Kofax service  # BAD — always restarts
  ansible.windows.win_command: net stop KofaxCapture && net start KofaxCapture

# ✅ Idempotent version
- name: Ensure Kofax Capture is running
  ansible.windows.win_service:
    name: KofaxCapture
    state: started
```

---

## Handlers

```yaml
# handlers/main.yml
- name: restart alloy linux
  ansible.builtin.systemd:
    name: alloy
    state: restarted
  listen: restart alloy linux

- name: restart alloy windows
  ansible.windows.win_service:
    name: alloy
    state: restarted
  listen: restart alloy windows
```

Handlers only fire once at the end of a play, even if notified multiple times —
use this to avoid multiple restarts during a single playbook run.

---

## Tags Convention

```yaml
# Apply consistent tags for selective execution
- name: Deploy monitoring config
  tags:
    - monitoring
    - alloy
    - configure
    
# Run only config tasks: ansible-playbook site.yml --tags configure
# Skip install tasks:     ansible-playbook site.yml --skip-tags install
```

Standard tags for this environment: `install`, `configure`, `monitoring`, `security`, `db2`, `ecm`, `kofax`, `was`
