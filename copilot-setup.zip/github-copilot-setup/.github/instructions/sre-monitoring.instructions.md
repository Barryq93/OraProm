---
applyTo: "**"
---

# SRE — Monitoring, Automation & Incident Response

Apply when writing monitoring scripts, alerting logic, runbooks, or automation
for the documents platform environment.

---

## Platform Monitoring Priorities

In order of criticality for this environment:

1. **ECM / FileNet availability** — P8 Application Engine, Content Engine
2. **DB2 instance health** — connections, tablespace, lock waits, long-running queries
3. **Kofax Capture service availability** — batch processing pipeline
4. **WAS application server health** — JVM heap, thread pool, failed applications
5. **KTM / RTTI processing queues** — queue depth, error rates, stuck batches
6. **Windows Server base health** — disk, CPU, memory for Kofax hosts

---

## Monitoring Script Standards (PowerShell)

All monitoring scripts must:

```powershell
# Return a structured result object — never just Write-Host
[PSCustomObject]@{
    CheckName   = 'ECM-ContentEngine-Availability'
    Status      = 'OK'              # OK | WARN | CRITICAL | UNKNOWN
    Value       = $responseTime     # The actual measured value
    Threshold   = 5000              # The threshold that triggered the status
    Message     = "Response time: ${responseTime}ms"
    Timestamp   = Get-Date -Format 'o'
    Host        = $env:COMPUTERNAME
}
```

- Status values: `OK`, `WARN`, `CRITICAL`, `UNKNOWN` — these map to standard monitoring conventions
- Always include the raw `Value` alongside the `Status` — don't just return pass/fail
- Always include `Timestamp` and `Host` for log correlation
- Scripts must be idempotent — safe to run repeatedly without side effects

---

## Alerting Thresholds (defaults — adjust per environment)

| Component             | WARN              | CRITICAL          |
|-----------------------|-------------------|-------------------|
| DB2 Tablespace        | > 75% used        | > 85% used        |
| DB2 Lock waits        | > 10 concurrent   | > 25 concurrent   |
| DB2 Long-running SQL  | > 5 min           | > 15 min          |
| WAS JVM Heap          | > 75%             | > 90%             |
| WAS Thread Pool       | > 80% allocated   | > 95% allocated   |
| Kofax batch queue     | > 500 batches     | > 1000 batches    |
| Disk (Kofax hosts)    | > 80% used        | > 90% used        |
| ECM response time     | > 3000ms          | > 8000ms          |

These are defaults. Document the actual agreed thresholds in the monitoring script header.

---

## Runbook Format

When producing a runbook or incident procedure:

```markdown
# Runbook: [Incident Title]

**Severity:**    P1 / P2 / P3  
**Component:**   [ECM / DB2 / Kofax / WAS]  
**Last Updated:** YYYY-MM-DD  

## Symptoms
What the engineer will observe that leads them to this runbook.

## Immediate Actions (first 5 minutes)
Step-by-step — numbered, specific commands, no ambiguity.

## Diagnostic Steps
How to confirm the root cause hypothesis.

## Resolution Procedures
Ordered steps to resolve. Mark any step that is irreversible with ⚠️.

## Escalation Criteria
Conditions under which to escalate, and to whom.

## Post-Incident Checks
Verification steps to confirm resolution.

## Known Causes
Previous incidents and their root causes — prevents repeat investigation.
```

---

## Automation Rules

- All automation that modifies production must log: who triggered it, what it did, what the outcome was
- Destructive or irreversible operations must have a `$WhatIf` / dry-run mode
- Scheduled tasks must write to a centralised log path, not the Windows Event Log only
- Automation that touches ECM must log the ECM GUID of any modified document for audit trail
- DB2 automation must log the SQL executed, not just the outcome

---

## Splunk Integration

When writing scripts that feed Splunk:

```powershell
# Structured log output for Splunk key-value parsing
function Write-SplunkLog {
    param($CheckName, $Status, $Value, $Component)
    $timestamp = Get-Date -Format 'o'
    # Splunk key=value format for easy field extraction
    Write-Output "timestamp=`"$timestamp`" check=`"$CheckName`" status=`"$Status`" value=`"$Value`" component=`"$Component`" host=`"$env:COMPUTERNAME`""
}
```

- Use structured key=value log format — enables Splunk field extraction without regex
- Timestamp in ISO 8601 format for Splunk time parsing
- Include `component` field on all log lines for dashboard filtering
