---
applyTo: "**"
---

# CMIS 1.0 - BAW / IBM Content Manager Integration

Standard: OASIS CMIS 1.0 via IBM ECM CMIS / IBM Content Navigator 3.1.0
BAW integrates with CM8 via CMIS 1.0 through the ICN CMIS endpoint.
Docs: https://www.ibm.com/docs/en/content-navigator/3.1.0?topic=navigator-ecm-cmis-enterprise-content-management-api-reference

---

## Architecture

BAW Process -CMIS 1.0-> ICN CMIS Endpoint -> CM8 Library Server
  /navigator/atom  (AtomPub binding - preferred for Spring Boot)
  /navigator/wsdl  (SOAP binding - used by BAW native ECM components)

---

## CMIS Type Mapping - CM8 to CMIS

CMIS type IDs match CM8 item type names exactly - case-sensitive.

CM8 Item Type (Document, classification=2) -> cmis:document subtype
CM8 Item Type (Folder, classification=3)   -> cmis:folder subtype
CM8 Attribute                               -> CMIS property
CM8 Primary content part                   -> CMIS content stream
CM8 PID                                    -> cmis:objectId
CM8 Version                                -> cmis:versionLabel

---

## CMIS SQL

Always set maxItems - never unbounded queries in production.

Example:
  SELECT cmis:objectId, INVOICE_NUMBER FROM InvoiceDocument
  WHERE CUSTOMER_ID = ?
  ORDER BY cmis:creationDate DESC

Operators: =, <>, <, >, <=, >=, LIKE, IN, IS NULL, IS NOT NULL

---

## Spring Boot - Apache Chemistry OpenCMIS Client

Use Apache Chemistry OpenCMIS 1.1.0. Never write raw AtomPub HTTP calls.
Maven: org.apache.chemistry.opencmis:chemistry-opencmis-client-impl:1.1.0

Session config (one session per application lifecycle):
  SessionParameter.BINDING_TYPE    = BindingType.ATOMPUB.value()
  SessionParameter.ATOMPUB_URL     = from environment
  SessionParameter.REPOSITORY_ID   = from environment (matches CM8 server name in ICN)
  SessionParameter.USER            = System.getenv("CMIS_USERNAME")
  SessionParameter.PASSWORD        = System.getenv("CMIS_PASSWORD")
  SessionParameter.CONNECT_TIMEOUT = "5000"
  SessionParameter.READ_TIMEOUT    = "30000"

application.yml (values from environment only):
  cmis.atompub-url: 
  cmis.repository-id: 

---

## BAW Integration Patterns

- BAW stores document references as CMIS objectId (= CM8 PID)
- Case properties referencing CM8 docs store objectId - not raw PID
- Confirm repository-id matches CM8 server name in ICN connection config
- BAW service account needs CM8 read/write on item types and ACLs - not ICMADMIN
- CMIS 1.0 does not support multi-part content, annotations, notelog
  -> use CM8 REST API from a Spring Boot service for those operations

---

## CMIS vs CM8 REST API - Decision Guide

BAW process storing/retrieving documents   -> CMIS (BAW native)
Spring Boot reading CM8 metadata           -> CM8 REST API
Storing documents with multiple parts      -> CM8 REST API
Spring Boot that must be BAW-compatible    -> CMIS
Bulk operations, admin, complex queries    -> CM8 REST API or Java SDK
Cross-platform ECM integration (non-IBM)  -> CMIS (open standard)

---

## Security

- Credentials in environment variables only - never committed config files
- ICN CMIS uses Basic auth - always HTTPS outside development
- CMIS objectId (CM8 PID) must not be exposed in external APIs without access control
- Dedicated service account per integration - never ICMADMIN