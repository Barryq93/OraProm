---
applyTo: "**/*.sql,**/*.db2,**/*.ddl"
---

# DB2 DBA — IBM DB2 LUW 11.5.9

All DB2 work targets **DB2 LUW version 11.5.9** unless explicitly stated.
Flag any syntax or feature that requires a higher fix pack or version.

---

## SQL Standards

### Parameterisation (mandatory)

All SQL that accepts user input or external values must be parameterised.
Never concatenate values into SQL strings.

```sql
-- ✅ Correct (JDBC prepared statement example)
SELECT * FROM SCHEMA.TABLE WHERE DOCUMENT_ID = ?

-- ❌ Never
SELECT * FROM SCHEMA.TABLE WHERE DOCUMENT_ID = '" + docId + "'"
```

### Formatting

```sql
SELECT
    t.DOCUMENT_ID,
    t.DOCUMENT_TITLE,
    t.CREATE_DATE,
    t.OBJECT_STORE
FROM
    SCHEMA.TABLE_NAME t
INNER JOIN
    SCHEMA.OTHER_TABLE o ON t.DOCUMENT_ID = o.DOCUMENT_ID
WHERE
    t.CREATE_DATE >= CURRENT_DATE - 30 DAYS
    AND t.STATUS = 'ACTIVE'
ORDER BY
    t.CREATE_DATE DESC
FETCH FIRST 1000 ROWS ONLY;
```

- UPPER CASE keywords
- One clause per line
- Alias all table references
- Always include `FETCH FIRST n ROWS ONLY` on unfiltered SELECTs
- Qualify all column references with table alias in multi-table queries

---

## Performance & Query Analysis

When writing or reviewing queries, always include:

```sql
-- EXPLAIN before running any complex query in production
EXPLAIN PLAN FOR
SELECT ...;

-- Check access plan
SELECT * FROM TABLE(EXPLAIN_GET_MSGS(NULL, NULL, 'P', -1, 1)) AS T;
```

- Consider index usage — flag full table scans on large FileNet tables
- Note if `RUNSTATS` may be needed (after large batch loads, schema changes)
- Warn on Cartesian joins, implicit conversions, or non-sargable predicates
- FileNet/ECM tables (OBJECT_STORE schema) can be very large — always filter early

### Key ECM Table Awareness

```sql
-- Document class tables follow this pattern
-- ICMADMIN schema is common in ECM/FileNet DB2 databases
SELECT COUNT(*) FROM ICMADMIN.DOCTYPES;

-- Be cautious with OBJECT, PROPERTY, and VERSION tables — can be 100M+ rows
-- Always qualify with document class ID or date range filters
```

---

## DBA Operations

### Maintenance Scripts Pattern

```sql
-- Always wrap maintenance in a transaction with explicit commit
BEGIN
    -- operation
    COMMIT;
END;

-- For REORG / RUNSTATS — these are online-safe in DB2 11.5.9
REORG TABLE SCHEMA.TABLE_NAME;
RUNSTATS ON TABLE SCHEMA.TABLE_NAME WITH DISTRIBUTION AND DETAILED INDEXES ALL;
```

### Health Check Queries

```sql
-- Tablespace usage
SELECT
    TBSP_NAME,
    TBSP_TYPE,
    TBSP_STATE,
    TBSP_USED_PAGES * TBSP_PAGE_SIZE / 1024 / 1024 AS USED_MB,
    TBSP_TOTAL_PAGES * TBSP_PAGE_SIZE / 1024 / 1024 AS TOTAL_MB,
    DECIMAL(FLOAT(TBSP_USED_PAGES) / FLOAT(TBSP_TOTAL_PAGES) * 100, 5, 2) AS PCT_USED
FROM
    SYSIBMADM.TBSP_UTILIZATION
ORDER BY
    PCT_USED DESC;

-- Long running queries
SELECT
    SUBSTR(STMT_TEXT, 1, 100) AS SQL_TEXT,
    ELAPSED_TIME_MIN,
    AGENT_ID
FROM
    SYSIBMADM.LONG_RUNNING_SQL
ORDER BY
    ELAPSED_TIME_MIN DESC
FETCH FIRST 20 ROWS ONLY;
```

---

## Security Rules (DB2-specific)

- Use DB2 roles and groups — avoid granting directly to individual users
- Least-privilege: `SELECT` only where write is not needed
- Sensitive data (ECM document content, metadata) — flag any query that may expose PII
- Never put passwords in SQL scripts — use `CONNECT TO db USER user USING ?` with prompting
- Audit log (`db2audit`) — assume it is enabled; operations are traceable

---

## Script Header for DB2 SQL Files

```sql
-- =============================================================================
-- FILE:        script_name.sql
-- PURPOSE:     One-line description
-- DB:          Database name / instance
-- SCHEMA:      Target schema(s)
-- AUTHOR:      [name / Copilot]
-- CREATED:     YYYY-MM-DD
-- MODIFIED:    YYYY-MM-DD
-- DB2 VERSION: 11.5.9 LUW
-- NOTES:       Any operational notes, run order, prerequisites
-- WARNING:     Highlight anything destructive or irreversible
-- =============================================================================
```
