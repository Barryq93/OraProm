---
applyTo: "**"
---

# Spring Boot Microservices

Your role: architecture, design, documentation, and review.
A separate dev team owns implementation.

---

## Platform Context

- Primary integration layer between CM8, Kofax, BAW, and consumers
- Run on WAS Liberty (FP4) or standalone container
- Integrate with CM8 via REST API (cm-rest-api.instructions.md)
- Integrate with BAW via CMIS 1.0 (cmis.instructions.md)
- Observed via Prometheus, Grafana Alloy, Loki
- DB2 11.5.9 LUW for relational persistence
- Spring Boot 3.x unless confirmed otherwise

---

## Your Scope

IN SCOPE:
- Understanding existing Spring Boot codebases
- Service documentation (README, API docs, architecture)
- OpenAPI / Swagger specifications
- Integration design (CM8 REST, CMIS, Kofax, DB2)
- Architecture decisions and ADRs
- Code review (security, performance, integration)
- HLD sections covering microservice components

OUT OF SCOPE (dev team):
- Greenfield service implementation
- Sprint planning and story breakdown
- CI/CD pipeline ownership

When asked to implement a full service: produce architecture and API contract first,
then offer scaffolding the dev team will own.

---

## Service Documentation Standard

Every microservice needs README.md in its root with these sections:

  Purpose          -- what business problem this solves
  Responsibilities -- what this service owns (and what it does NOT own)
  Integration Map  -- table of systems, direction, protocol, purpose
  API Summary      -- brief endpoint descriptions, full spec in openapi.yaml
  Configuration    -- env var names and descriptions only, no values
  Prerequisites    -- Java version, Liberty version, required env vars
  Running Locally  -- build and run commands
  Observability    -- Prometheus endpoint, key metrics, log format
  Known Limitations-- non-obvious design constraints

---

## OpenAPI / Swagger

Dependencies (Spring Boot 3.x):
  springdoc-openapi-starter-webmvc-ui:2.x
  springdoc-openapi-starter-webflux-ui:2.x (reactive)

Required per controller:
  @Tag(name, description)
  @Operation(summary, description) per endpoint
  @ApiResponse for 2xx, 400, 502 minimum

openapi.yaml must include:
  info.title, info.version, info.description
  servers[] with environment placeholder URLs
  All schemas with descriptions
  Security scheme (Bearer or Basic)
  Consistent error response schema across all endpoints

Standard error body: timestamp, status, error, message, path, correlationId

---

## Configuration Standards

Never hardcode. All external connections via environment variables:

  CM8_BASE_URL, CM8_SERVER_NAME, CM8_USERNAME, CM8_PASSWORD
  CMIS_ATOMPUB_URL, CMIS_REPOSITORY_ID
  DB2_JDBC_URL, DB2_USERNAME, DB2_PASSWORD

In application.yml:
  cm8.base-url: 
  cm8.username: 
  cmis.atompub-url: 
  spring.datasource.url: 

---

## Correlation IDs

All services must propagate correlation ID through the full request lifecycle:
- Accept X-Correlation-ID header on inbound requests
- Forward to CM8 REST calls (CM8 returns Correlation-Id in response header)
- Include in all log entries and error responses

---

## Observability

Required Spring Actuator endpoints:
  /actuator/health     -- liveness and readiness
  /actuator/prometheus -- Prometheus scrape target

Custom Micrometer metrics for CM8:
  cm_rest_request_duration_seconds{operation, item_type, status}
  cm_rest_error_total{operation, item_type, error_type}
  cmis_session_active_total

Structured JSON logging. Required fields:
  level, timestamp, service, correlationId, operation, itemType, pid, durationMs, error

---

## Code Review Checklist

Security:
  No hardcoded credentials or URLs in source or committed config
  CM8 token not logged or returned to clients
  Input validated before CM8 query
  DB2 queries parameterised only

CM8 Integration:
  Token refresh implemented -- not assumed perpetual
  Query has explicit limit -- never limit=0 in production
  PID URL-encoded before REST path use
  ContentStream and DKResults closed in finally blocks
  Item type names validated before CM8 calls

Resilience:
  Timeout configured on WebClient and CMIS session
  CM8 unavailable returns 502 not 500
  Retry has backoff -- no tight loops
  Connection pool sized for expected concurrency

Observability:
  /actuator/prometheus exposed
  Correlation ID propagated through all outbound calls
  All CM8 calls timed and metered

---

## Kofax Release Script Integration

When a microservice acts as a Kofax release script target:
  Accept document metadata as JSON POST
  Validate all required CM8 attributes present before calling CM8
  Return CM8 PID in response so Kofax records it against the batch
  Log batch ID and PID pair at INFO level for traceability
  Return 4xx for invalid data, 502 for CM8 unavailability
  (Kofax uses HTTP status to decide retry vs permanent failure)
