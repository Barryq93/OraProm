---
applyTo: "**/*hld*,**/*HLD*,**/*architecture*,**/*design*"
---

# High-Level Design (HLD) Documentation

HLDs are first-class engineering outputs. Apply the same rigour to a design document
as to production code. Treat the audience as senior technical stakeholders unless told otherwise.

---

## Standard HLD Structure

Every HLD must contain these sections in order:

```markdown
# High-Level Design: [Solution Name]
**Version:** 1.0  
**Status:** Draft / Review / Approved  
**Author:** [name]  
**Date:** YYYY-MM-DD  
**Reviewers:** [names / roles]

---

## 1. Executive Summary
One paragraph. What is being built, why, and what the key outcome is.
Non-technical stakeholders should understand this section.

## 2. Background & Business Context
Problem statement. Why does this need to exist? What is the current state and its limitations?

## 3. Goals & Non-Goals
### Goals
- What this design achieves

### Non-Goals
- What is explicitly out of scope (prevents scope creep and reviewer challenges)

## 4. Assumptions & Constraints
- Technical constraints (versions, platform limitations, existing infrastructure)
- Business constraints (budget, timeline, regulatory)
- Assumptions being made that, if wrong, would invalidate the design

## 5. Architecture Overview
High-level description of the solution. Include a component diagram.
For text-based diagrams use Mermaid or ASCII art.

## 6. Component Design
For each major component:
- Name and responsibility
- Technology and version
- Interfaces (inputs/outputs)
- Failure mode and behaviour

## 7. Data Flow
Describe how data moves through the system. Include a sequence diagram for
the primary flow and any significant exception flows.

## 8. Integration Points
| System | Integration Type | Protocol | Auth Method | Owner |
|--------|-----------------|----------|-------------|-------|

## 9. Security Considerations
- Authentication and authorisation model
- Data classification and handling
- Network exposure and firewall requirements
- Secrets management
- Audit and logging requirements

## 10. HA / DR / Resilience
- Single points of failure identified
- Recovery Time Objective (RTO) and Recovery Point Objective (RPO)
- Failover mechanism
- Backup and restore strategy

## 11. Observability & Monitoring
- Key metrics to capture
- Alerting thresholds
- Log aggregation approach (Splunk integration where applicable)
- Health check endpoints

## 12. Risks & Mitigations
| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|-----------|

## 13. Alternatives Considered
Document the options that were evaluated and why they were rejected.
This protects the design decision in future reviews.

## 14. Open Questions
Items that need resolution before the design can be finalised.

## 15. Appendix
Supporting diagrams, reference documents, glossary.
```

---

## Diagramming

Prefer **Mermaid** for diagrams embedded in markdown HLDs (renders in GitHub, Confluence, VS Code):

```mermaid
flowchart LR
    A[Kofax Capture] --> B[Release Script]
    B --> C[ECM 8.7.4]
    C --> D[DB2 11.5.9]
    C --> E[ICN Plugin]
```

For sequence diagrams:
```mermaid
sequenceDiagram
    actor User
    participant ICN
    participant ECM
    participant DB2
    User->>ICN: Search request
    ICN->>ECM: FQL Query
    ECM->>DB2: SQL
    DB2-->>ECM: Results
    ECM-->>ICN: Document set
    ICN-->>User: Results rendered
```

---

## Language & Style Rules

- Use active voice: "The service validates the token" not "The token is validated by the service"
- Avoid ambiguous terms: "fast", "scalable", "robust" — replace with measurable statements
- Version everything: document versions, API versions, platform versions
- All acronyms defined on first use
- Decisions justified — never just describe what, explain why

---

## HLD Review Checklist

Before marking an HLD ready for review:

- [ ] All sections present and populated (no "TBD" on critical sections)
- [ ] Non-goals explicitly stated
- [ ] All integration points documented with auth method
- [ ] Security section addresses data classification
- [ ] Single points of failure identified
- [ ] Alternatives considered section is not empty
- [ ] Open questions logged as tracked items
