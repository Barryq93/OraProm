# Session Context

Use this file to capture persistent context that you want Copilot to carry
across sessions. Paste key decisions, environment details, or ongoing task state.

---

## Environment Notes
- CM8 8.7.0 FP4
- DB2 LUW 11.5.9
- PowerShell 5.1 target
- RHEL 8.1 for Linux scripts
- Date format: DD-MM-YY HH:MM

## Current Ongoing Work
(update as needed)

## Known Open Questions
(update as needed)
