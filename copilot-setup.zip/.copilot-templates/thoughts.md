# Copilot Thoughts

Design reasoning, open questions, and promote-to-ADR signals.
Automatically maintained by GitHub Copilot during agent sessions.
DO NOT edit manually — append only.

---
