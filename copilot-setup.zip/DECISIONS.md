# Decisions Log

This file records all significant technical decisions made in this project.
Maintained under principal engineer guidance.
Last updated: DD-MM-YY

---

## Index

| ADR | Title | Component | Status | Date |
|-----|-------|-----------|--------|------|

---

## Decisions

<!-- ADR entries go here, newest first -->
