# Install Plan

## Goal
Bundle the newer instruction files, prompt packs, and supporting updates into the workspace without losing the existing structure.

## Recommended Order
1. Extract the instruction zip containing README, TTA, SQL, PIR, Runbook, Decisions, Architecture, Tech Lead updates.
2. Extract the prompt zip into `.github/prompts/`.
3. Review the updated index files:
   - `.github/prompts/README.md`
   - `.github/instructions/tech-lead.instructions.md`
   - `.github/instructions/runbook.instructions.md`
   - `.github/instructions/decisions.instructions.md`
   - `.github/instructions/architecture.instructions.md`
4. Add any missing manual workspace folders such as `tungsten/ideas/` if they are empty.

## Files that are updated manually
- `.github/instructions/runbook.instructions.md` — Component list includes TTA and WAS
- `.github/instructions/decisions.instructions.md` — Component list includes TTA and WAS
- `.github/instructions/architecture.instructions.md` — Component list includes TTA and WAS
- `.github/prompts/README.md` — add or reorder prompt entries if you rename prompts

## What the prompts add
- `new-runbook`
- `new-pir`
- `new-adr`
- `session-start`
- TTA workflow design
- CM8 integration design
- DB2 health script
- PowerShell monitor script
- Bash utility script
- README update helper
- change log helper
- decision helper
- Mermaid diagram helper
- security audit helper
- install-plan helper

## What the instructions add
- TTA first-class workspace rules
- README creation/update rules
- blameless PIR structure
- stricter runbook and ADR component coverage
- tech-lead delegation updates

## Verification Checklist
- [ ] `.github/instructions/` contains the updated instruction files
- [ ] `.github/prompts/` exists and contains the prompt pack
- [ ] `INSTALL-PLAN.md` is reviewed before applying the bundle
- [ ] Existing files are not overwritten unintentionally
- [ ] Any manual updates listed above are applied after extraction
