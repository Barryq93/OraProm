---
description: Update or create a directory README.md
---

Ask me for:
- Directory path
- New files added or changed
- Any sub-directories
- Any notes or caveats

Then update or create the README using the workspace README instructions.
Add a Contents row for each file and a Per-Script block for each script.
