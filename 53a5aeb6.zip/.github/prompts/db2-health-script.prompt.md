---
description: Create a DB2 health-check script for CM8 systems
---

Ask me for:
- DB2 host or environment name
- Diagnostic goal
- Whether it is read-only
- Output format requirements
- Any CM8 table or tablespace focus

Then generate a parameterised DB2 health-check script with:
- DB2 LUW 11.5.9-safe syntax
- ICMADMIN table qualification where relevant
- No SELECT *
- WITH UR for diagnostics where appropriate
- RUNSTATS note if data changes are included
