---
description: Create a decision record from a chosen approach
---

Ask me for:
- Title
- Component
- Mode
- Date
- Context
- Decision
- Alternatives
- Consequences
- References

Then produce an ADR block ready for DECISIONS.md.
