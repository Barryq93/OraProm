---
description: Scan content for hardcoded secrets and unsafe patterns
---

Ask me for:
- File type or content
- Any known sensitive values to watch for

Then inspect the content for:
- passwords, tokens, hostnames, connection strings, keys
- unsafe commands and bypasses
- hardcoded credentials

Return a concise pass/fail plus required fixes.
