---
description: Create a PowerShell 5.1 monitoring script
---

Ask me for:
- What to monitor
- Target server or service
- Thresholds
- Output object needs
- Logging destination
- Whether it touches WAS, TTA, Kofax, or CM8

Then generate a PowerShell 5.1 script that follows the workspace rules:
- #Requires -Version 5.1
- Write-Log only
- No hardcoded secrets or hostnames
- Copy-pasteable and production-ready
