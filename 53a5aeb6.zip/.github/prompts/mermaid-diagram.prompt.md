---
description: Create the right MermaidJS diagram for a design
---

Ask me for:
- What the diagram should show
- Systems involved
- Whether it is a flow, sequence, state, or ER diagram

Then generate a MermaidJS diagram using the workspace conventions.
