---
description: Design a CM8 integration flow and document the contract
---

Ask me for:
- Source system
- Target CM8 item type
- REST or CMIS usage
- Authentication method
- Key metadata mapping
- Error handling expectations

Then produce:
- A sequence diagram
- A concise integration design
- Mapping notes
- Any ADR-worthy technology choices

Use CM8 EE 8.7.0 FP4 assumptions only.
