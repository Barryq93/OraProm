---
description: Create a new architecture decision record
---

You are creating an ADR for this workspace.

Ask me for:
- Decision title
- Component
- Mode
- Date
- Jira ticket if applicable
- Context
- Decision made
- Alternatives considered
- Consequences
- References

Then generate a complete ADR in the workspace format.
Use DD-MM-YY for dates and keep the decision concise.
