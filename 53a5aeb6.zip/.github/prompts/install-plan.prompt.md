---
description: Produce an install plan for workspace instruction and prompt updates
---

Ask me for:
- Which zip(s) or files are being installed
- Whether prompts, instructions, or both are included
- Any files that must be updated manually

Then produce a concise install plan that lists:
- what to extract
- what to overwrite
- what existing files need manual edits
- the recommended order of application
