---
description: Prepare changes.md and thoughts.md log entries
---

Ask me for:
- Files changed
- What changed
- Why it changed
- Caveats
- Whether this should become an ADR

Then produce ready-to-paste entries for changes.md and thoughts.md in the nearest .copilot folder.
