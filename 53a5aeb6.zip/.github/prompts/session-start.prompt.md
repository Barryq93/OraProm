---
description: Start a new Copilot session with context and missing questions
---

Start by summarizing the current workspace context from the conversation and the known instruction set.
Then ask only for the missing facts needed to continue.

Include:
- Current task summary
- Files or instruction areas likely in scope
- Key decisions already locked
- Assumptions being carried
- Open questions that block progress
- Recommended instruction files or prompts to use next

If enough context already exists, ask the minimum possible number of questions.
