---
description: Create a Bash utility script for RHEL 8.1
---

Ask me for:
- Purpose
- Input parameters
- Host or environment
- Output requirements
- Error handling expectations

Then generate a Bash utility script that follows the workspace shell rules:
- shebang at top
- set -euo pipefail
- env vars only for secrets and hosts
- copy-pasteable commands
