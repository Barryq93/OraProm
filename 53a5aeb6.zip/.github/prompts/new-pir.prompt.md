---
description: Create a new blameless post-incident review
---

You are creating a PIR for this workspace.

Ask me for:
- Component
- Incident title
- Severity
- Platform
- Incident date
- Detection time
- Resolution time
- Jira ticket
- Whether a runbook exists

Then generate a complete blameless PIR.
Must include:
- Summary
- Timeline
- Impact
- Root Cause Analysis
- What Went Well
- Action Items
- Follow-Up
- Sign-Off

Use systems-thinking language only. Do not use blame language.
