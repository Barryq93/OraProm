# Prompts Index

> A reusable command library for guided Copilot workflows.

This folder contains prompt packs for common workspace tasks such as runbooks,
PIRs, ADRs, TTA design, CM8 integration, DB2 health checks, and session start.

---

## Contents

| Name | Type | Description |
|------|------|-------------|
| `new-runbook.prompt.md` | Prompt | Create a runbook from the standard template |
| `new-pir.prompt.md` | Prompt | Create a blameless post-incident review |
| `new-adr.prompt.md` | Prompt | Create an architecture decision record |
| `session-start.prompt.md` | Prompt | Start a session with context and missing questions |
| `tta-workflow-design.prompt.md` | Prompt | Design a TTA workflow and scaffold structure |
| `cm8-integration-design.prompt.md` | Prompt | Design a CM8 integration and contract |
| `db2-health-script.prompt.md` | Prompt | Create a DB2 health-check script |
| `ps-monitor-script.prompt.md` | Prompt | Create a PowerShell 5.1 monitoring script |
| `shell-utility.prompt.md` | Prompt | Create a Bash utility script |
| `update-readme.prompt.md` | Prompt | Update or create a directory README |
| `log-changes.prompt.md` | Prompt | Create changes.md and thoughts.md entries |
| `create-decision.prompt.md` | Prompt | Create an ADR block for DECISIONS.md |
| `mermaid-diagram.prompt.md` | Prompt | Create the right MermaidJS diagram |
| `security-audit.prompt.md` | Prompt | Scan for secrets and unsafe patterns |
| `install-plan.prompt.md` | Prompt | Produce a plan for applying new workspace files |

---

## Notes

- Prompts are invoked on demand in Copilot Chat.
- Prompts complement always-on instructions in `.github/instructions/`.
- Keep prompts short, task-oriented, and explicitly copy-pasteable.
