---
description: Create a new runbook from the standard workspace template
---

You are creating a runbook for this workspace.

Ask me for:
- Component
- Incident title
- Severity
- Platform
- Owner team
- Alert name if applicable
- Any known symptoms

Then generate a complete runbook using the workspace runbook structure.
Must include:
- Symptoms
- Immediate Actions
- Diagnostic Steps
- Resolution Procedures
- Escalation Criteria
- Post-Incident Checks
- Known Causes table

Keep it copy-pasteable and use DD-MM-YY for dates.
