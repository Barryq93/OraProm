---
description: Design a TTA workflow and scaffold the workspace structure
---

Ask me for:
- Workflow name
- Business purpose
- Input and output systems
- Whether COM, REST, or both are involved
- Any CM8 mapping details

Then produce:
- A suggested folder structure under tungsten/
- A README starter for the workflow folder
- A MermaidJS diagram for the workflow or integration
- Any ADR-worthy trade-offs

TTA is not Kofax Capture.
