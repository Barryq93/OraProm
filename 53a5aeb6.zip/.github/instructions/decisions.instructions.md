---
applyTo: "**"
description: Rules for writing and maintaining DECISIONS.md
---

## Location — Walk-Up Rule
`DECISIONS.md` is always written alongside the nearest `.copilot/` folder.

## Entry Format

    ## ADR-NNN — Short decision title

    **Date**: DD-MM-YY
    **Status**: Proposed | Accepted | Superseded by ADR-NNN
    **Mode**: Coding | Architecture | Research
    **Component**: ECM | DB2 | TTA | WAS | Kofax | Observability | Ansible | Scripting | Platform
    **Jira**: JIRA-XXX

    ### Context
    ### Decision
    ### Reasoning
    ### Consequences
    ### References
