---
applyTo: "**"
description: README standards — auto-create and maintain per-directory READMEs
---

## Core Principle
Every directory in the workspace must have a README.md.
When a directory lacks one, create it immediately using the template below.
When new files are added, update the directory README automatically.

## Two-Level Structure
### Level 1 — Directory README
One README.md per directory. Include:
1. A short description of the directory purpose.
2. A Contents table listing every file and sub-directory.
3. An optional Notes section for folder-specific conventions.

### Level 2 — Per-Script Section
Below the Contents table, one section per file using heading `## filename.ext`.
Each section contains the standard Per-Script Block.

## Directory README Template
Use this exact template when creating a README.md from scratch:

    # <Directory Name>

    > <One sentence describing what this directory contains and its purpose.>

    <Two to three sentences of context: what system it relates to, who owns it,
    and any important constraints or conventions.>

    ---

    ## Contents

    | Name | Type | Description |
    |------|------|-------------|
    | `filename-or-subdir` | Script / Module / Config / Directory | One-line description |

    ---

    ## Scripts

    <!-- One section per file. Add new sections as files are created. -->

    ---

    ## Notes

    <!-- Optional: folder-level caveats, conventions, or links -->

## Per-Script Block Template
Add one of these sections per file, directly under `## Scripts`.
Replace all placeholders before saving.

    ## <filename.ext>

    **Purpose**: What this file does in one sentence.
    **Inputs / Parameters**:
    - `PARAM_NAME` — description, required/optional, example value

    **Outputs / Side Effects**: What it produces, writes, or changes.
    **Dependencies**: Modules, env vars, or external systems required.
    **Usage example**:

        <copy-pasteable invocation here>

    **Last updated**: DD-MM-YY
    **Author / Owner**: [team or person]
    **Notes**: Edge cases, known limitations, or follow-up items.

    ---

## Maintenance Rules
- New file added -> append a Per-Script Block and a row to Contents.
- File renamed or deleted -> update the row and section heading.
- Sub-directory added -> add a Directory row and create a new README there.
- Never overwrite existing content; append and update only.
- Use DD-MM-YY for all dates.

## Quality Checklist
- Every file has a row in Contents.
- Every file has a Per-Script Block.
- Usage examples are copy-pasteable.
- No hardcoded credentials or server names.
- Last updated date is current.
