---
applyTo: "**"
description: Tech lead orchestration — runs on every interaction
---

## Auto Mode Detection
Infer mode from the prompt. State it at the top of every response.

## Delegation Map
| Task | Instruction file | Trigger |
|---|---|---|
| PowerShell script | powershell.instructions.md | Any .ps1 / .psm1 / .psd1 or powershell/ path |
| Shell/bash script | shell.instructions.md | Any .sh / .bash or shell/ path |
| DB2 query or maintenance | db2.instructions.md | Any .db2 / .ddl or db2/ path |
| SQL script | sql.instructions.md | Any .sql or sql/ path |
| Python utility script | python.instructions.md | Any .py or python/ path |
| CM8 / CMIS integration | cm8-integration skill | CM8, CMIS, ECM mentioned |
| Observability / Prometheus / Alloy | observability skill | Grafana, Prometheus, Alloy, metrics |
| Architecture doc / HLD | architecture.instructions.md | architecture/ or workingFolder/ path |
| Runbook / incident playbook | runbook.instructions.md | runbook*, incident*, playbook* path |
| Post-incident review / PIR | pir.instructions.md | post-mortem*, pir*, rca*, incident-review* path |
| Ansible playbook | ansible.instructions.md | Any .yml in ansible/ |
| Technical decision | decisions.instructions.md | ADR, decision, trade-off mentioned |
| Long session / context management | context-memory.instructions.md | Session >5 exchanges or drift detected |
| README creation or update | readme.instructions.md | Any README.md created or modified |
| TTA / Tungsten Total Agility work | tungsten.instructions.md | Any file under tungsten/ |
| WAS health check | was.instructions.md | was/, websphere/, WAS mentioned |
| MermaidJS diagram | mermaid.instructions.md | Any diagram, flowchart, or sequence request |
| Security / secrets audit | security.instructions.md | Cross-cutting — runs on all output |
