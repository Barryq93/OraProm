---
applyTo: "**/post-mortem*,**/pir*,**/rca*,**/incident-review*"
description: Post-Incident Review — blameless, systems-thinking framing
---

## Writing Principle
PIRs are learning documents, not blame documents.
The goal is to understand how the system allowed the incident to occur and to make it more resilient.

## Language Rules
- Never name individuals in a negative context.
- Use "the on-call team" or "the responder".
- Frame causes as system conditions, not human errors.

## PIR Template

    # PIR — [Component] [Incident Title]

    **Severity**        : P1 | P2 | P3
    **Component**       : ECM | DB2 | TTA | WAS | Kofax | Observability | Platform
    **Platform**        : Windows 2019/2022 | RHEL 8.1 | Both
    **Incident date**   : DD-MM-YY
    **Detection time**  : HH:MM
    **Resolution time** : HH:MM
    **Total duration**  : HH:MM
    **Author**          : [team]
    **Status**          : Draft | In Review | Closed
    **Runbook**         : [link] or "No runbook existed — see Action Items"
    **Jira**            : JIRA-XXX

    ---

    ## Summary
    Two to three sentences: what happened, what was affected, how it was resolved.

    ---

    ## Timeline
    | Time (DD-MM-YY HH:MM) | Event |
    |---|---|
    | | First symptom observed |
    | | Alert fired — or alert did not fire |
    | | On-call team engaged |
    | | Impact scope confirmed |
    | | Mitigation applied |
    | | Service restored |
    | | Incident closed |

    ---

    ## Impact
    - Systems affected
    - Users affected
    - Data integrity
    - SLA / SLO
    - Duration of user-visible impact

    ---

    ## Root Cause Analysis
    ### Trigger
    The immediate event that started the incident.

    ### Contributing System Conditions
    - Condition 1
    - Condition 2
    - Condition 3

    ### Why It Was Not Caught Earlier
    What monitoring, alerting, testing, or process gap allowed this to reach impact?

    ---

    ## What Went Well
    - One thing that helped.

    ---

    ## Action Items
    | ID | Action | Owner (team) | Due | Jira | Status |
    |----|--------|--------------|-----|------|--------|
    | PIR-NNN-01 | Specific, testable action | Team | DD-MM-YY | JIRA-XXX | Open |

    ---

    ## Follow-Up
    - Runbook: created / updated / adequate
    - ADR raised: [link] or N/A
    - Prometheus alert added / modified: [alert name] or N/A
