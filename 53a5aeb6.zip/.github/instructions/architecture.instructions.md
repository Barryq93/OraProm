---
applyTo: "**/architecture/**,**/workingFolder/**"
description: Architecture design documents and draft decision records
---

## Diagrams
- sequenceDiagram — API flows, integration interactions
- flowchart TD — system topology, process flows
- erDiagram — DB2 schema documentation
- classDiagram — object/data model design
- stateDiagram-v2 — document lifecycle, workflow states, TTA workflow state machines

## ADR Format

    # [JIRA-XXX] Title

    **Status**: Proposed | Accepted | Superseded by ADR-NNN
    **Date**: DD-MM-YY
    **Jira**: JIRA-XXX
    **Mode**: Coding | Architecture | Research
    **Component**: ECM | DB2 | TTA | WAS | Kofax | Observability | Platform

    ## Context
    ## Decision
    ## Consequences
    ## Diagram
