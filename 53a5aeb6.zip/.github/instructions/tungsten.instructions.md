---
applyTo: "tungsten/**,**/tungsten/**"
description: Tungsten Total Agility (TTA) expert rules — activates in tungsten/
---

## Identity — Read This First
Tungsten Total Agility (TTA) is Tungsten Automation's intelligent process automation platform.
It is a separate product from Kofax Capture.

- Do NOT conflate TTA with Kofax Capture.
- TTA covers: document capture, forms processing, workflow orchestration, business rules, and integration with external systems (including CM8).
- Treat TTA as a first-class system alongside CM8 and DB2.

## Version Safety
- Current workspace version: 2026.1
- Never assume an API, COM object, property, or REST endpoint exists without verifying against 2026.1 docs.
- If behaviour differs between versions, flag it explicitly.

## API Patterns — COM vs REST
Always clarify which is in use before writing integration code.

### COM Automation
- Used for local/server-side automation, typically from PowerShell or scripting hosts.
- COM objects are version-specific — confirm the ProgID is valid for 2026.1.
- Always release COM objects explicitly to prevent memory leaks.

### REST API
- Preferred for integration with CM8, Spring Boot microservices, and external systems.
- Confirm the endpoint path against TTA 2026.1 API docs before use.
- Use environment variables for base URL, credentials, and tokens — never hardcode.
- Handle paginated responses explicitly.

## File Header Template
Every script, config, or integration file under tungsten/ must begin with:

    # ============================================================
    # File    : <filename>
    # Purpose : <one sentence>
    # TTA Ver : 2026.1
    # API     : COM | REST | Both | N/A
    # Created : DD-MM-YY
    # Updated : DD-MM-YY
    # Author  : <team or person>
    # Deps    : <env vars, modules, or external systems required>
    # Notes   : <version-specific caveats or follow-up items>
    # ============================================================

## Terminology
Use these terms consistently.

| Term | Meaning |
|------|---------|
| TTA | Tungsten Total Agility — the platform |
| Workflow | A TTA process definition |
| Activity | A step within a TTA workflow |
| Document Class | TTA's document categorisation unit |
| Batch | A set of documents processed together in TTA capture |
| Integration Server | The TTA component that exposes REST/COM to external systems |
| Export Connector | TTA component that pushes documents to CM8 or other targets |
| Field | A metadata field on a TTA Document Class |

## Design Checklist
- Version confirmed as 2026.1.
- API surface stated explicitly (COM / REST / Both).
- TTA is not referred to as Kofax Capture.
- All credentials and hostnames in environment variables.
- COM objects released explicitly (if COM path used).
- REST endpoints verified against 2026.1 docs (if REST path used).
- File header block present and complete.
- Terminology matches the table above.
- MermaidJS diagram offered for any workflow or integration design.
- ADR written if a technology choice or trade-off was made.
- README updated in the affected tungsten/ sub-directory.

## CM8 Integration Notes
- Target CM8 EE 8.7.0 FP4 — NOT FileNet P8.
- Use CM8 REST API or CMIS 1.0 — never the FileNet Java API.
- Log the CM8 endpoint variable name in the file header Deps line.

## Folder Conventions
- Never put scripts directly in tungsten/ root — use a named sub-directory.
- ideas/ is free-form; normal README rules still apply.
- Sub-directory names must match the TTA workflow name exactly (lowercase, hyphens).
