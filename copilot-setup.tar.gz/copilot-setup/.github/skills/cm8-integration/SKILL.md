---
name: cm8-integration
description: Help design or document CM8 REST API or CMIS 1.0 integrations, Spring Boot service patterns, or document workflow flows. Use when asked about CM8 APIs, item types, object stores, or document workflows.
---

When working on CM8 integration design or documentation:

1. API references:
   - CM8 REST API: https://www.ibm.com/docs/en/content-manager/8.7.0?topic=support-rest-api-documentation
   - CMIS 1.0: https://docs.oasis-open.org/cmis/CMIS/v1.0/cmis-spec-v1.0.html
   - Always prefer REST or CMIS — never suggest the FileNet Java API

2. When designing flows:
   - Always produce a MermaidJS sequenceDiagram showing the integration
   - Label each step with the HTTP method and endpoint path
   - Show error/fault paths as well as happy path

3. Spring Boot patterns (design/support level only):
   - Services interact with CM8 via REST — show endpoint + payload structure
   - Handle CM8 fault codes in error handling design
   - Map CM8 item type properties to DTO field names

4. CMIS patterns:
   - Use CMIS query language for document retrieval designs
   - Show AtomPub or Browser binding patterns as appropriate

5. Kofax/Tungsten integration points:
   - Release scripts deliver documents to CM8
   - Design for both batch and single-document modes
   - Note any Tungsten Total Agility (TTA) on-prem integration server constraints

6. Always note DB2/tablespace implications for bulk document operations
