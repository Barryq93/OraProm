---
name: architecture-doc
description: Create or update architecture design documents, ADRs, or system design diagrams for the CM8/DB2/Kofax platform. Use when asked to document a design decision, create a system diagram, or write up a technical design.
---

When creating architecture or design documents:

1. Always include at least one MermaidJS diagram. Choose type by use case:
   - `sequenceDiagram` — API flows, system interactions
   - `flowchart TD` — process flows, system topology
   - `erDiagram` — DB2 schema or data model
   - `classDiagram` — object/data structure design
   - `stateDiagram-v2` — document lifecycle, workflow states

2. ADR format (when capturing a decision):
   ```markdown
   # [JIRA-XXX] Title

   **Status**: Proposed
   **Date**: DD-MM-YY
   **Jira**: JIRA-XXX

   ## Context
   ## Decision
   ## Consequences
   ## Diagram
   ```

3. New docs go to `workingFolder/` — only promote to `architecture/` when accepted

4. Always mention:
   - Which systems are involved (CM8, DB2, Kofax/TTA, Spring Boot)
   - Any DB2 or CM8 tablespace/performance implications
   - Whether the design is REST, CMIS, or a hybrid approach

5. After creating a doc, append to `.copilot/thoughts.md` with `Promote to ADR?: yes/maybe/no`
