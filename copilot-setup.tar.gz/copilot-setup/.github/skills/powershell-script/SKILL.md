---
name: powershell-script
description: Scaffold or review a PowerShell monitoring script for Windows servers using AIB.Logging. Use when asked to create, fix, or improve a PowerShell script.
---

When generating or reviewing a PowerShell script:

1. Always import AIB.Logging from the commons symlink:
   ```powershell
   Import-Module "$PSScriptRoot\commons\AIB.Logging"
   ```
2. Never use Write-Host, Write-Output, Write-Warning, Write-Error, or Write-Verbose for messages
   — all output goes through `Write-Log -Level {LEVEL} -Message {MESSAGE}`
3. Every script must have `[CmdletBinding()]` and a `param()` block
4. Wrap meaningful operations in try/catch; log errors with `Write-Log -Level ERROR`
5. Return a `[PSCustomObject]` with at minimum: Status, Message, Timestamp, ScriptName
6. Use `$PSScriptRoot` for all path references
7. No hardcoded credentials, server names, or paths — use parameters with sensible defaults
8. PSScriptAnalyzer-compatible: no aliases, approved verbs, no positional parameters in scripts

Skeleton structure to follow:
```powershell
Import-Module "$PSScriptRoot\commons\AIB.Logging"

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$TargetServer,

    [Parameter(Mandatory=$false)]
    [int]$Threshold = 80
)

try {
    Write-Log -Level INFO -Message "Starting <script purpose> on $TargetServer"

    # Main logic here

    Write-Log -Level INFO -Message "Completed successfully"
    return [PSCustomObject]@{
        Status     = 'OK'
        Message    = 'Description of result'
        Value      = $null
        Threshold  = $Threshold
        Server     = $TargetServer
        Timestamp  = (Get-Date -Format 'dd-MM-yy HH:mm:ss')
        ScriptName = $MyInvocation.MyCommand.Name
    }
}
catch {
    Write-Log -Level ERROR -Message "Failed on $TargetServer`: $_"
    return [PSCustomObject]@{
        Status     = 'ERROR'
        Message    = $_.Exception.Message
        Value      = $null
        Threshold  = $Threshold
        Server     = $TargetServer
        Timestamp  = (Get-Date -Format 'dd-MM-yy HH:mm:ss')
        ScriptName = $MyInvocation.MyCommand.Name
    }
}
```
