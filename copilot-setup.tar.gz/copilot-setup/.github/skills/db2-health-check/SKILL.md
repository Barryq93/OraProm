---
name: db2-health-check
description: Generate DB2 health check or diagnostic scripts for CM8 — tablespace monitoring, lock analysis, log space, bufferpool, connection counts. Use when asked about DB2 health, monitoring, diagnostics, or performance.
---

When generating DB2 health check or diagnostic scripts:

1. Target IBM DB2 LUW syntax only
2. Cover these areas based on what is asked:
   - **Tablespace utilisation**: SYSCAT.TABLESPACES, MON_GET_TABLESPACE
   - **Active connections**: MON_GET_CONNECTION, SNAPAPPL
   - **Lock waits**: MON_GET_LOCKS, MON_GET_APPL_LOCKWAIT
   - **Log utilisation**: MON_GET_TRANSACTION_LOG
   - **Bufferpool hit ratios**: MON_GET_BUFFERPOOL
   - **CM8-specific tables**: ICMADMIN.ICMUT00100, ICMADMIN.ICMFILESEG, ICMADMIN.ICMRESOURCE
3. Define thresholds as variables at the top of any shell wrapper
4. Use `db2 -x` for scriptable output (no column headers)
5. Credentials from env vars: `$DATABASE`, `$DB_USER`, `$DB_PASSWORD`
6. Log with timestamps in DD-MM-YY HH:MM:SS format
7. Return codes must be checked after every DB2 command
8. Include comments noting CM8 impact for any tablespace or storage queries
9. SQL must use DB2 syntax: `FETCH FIRST n ROWS ONLY`, `CURRENT TIMESTAMP`, schema-qualified tables
