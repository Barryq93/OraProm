---
name: ansible-playbook
description: Create or review Ansible playbooks for platform configuration, CM8 setup, or DB2 tasks. Use when asked to automate server configuration or create Ansible tasks.
---

When writing or reviewing Ansible playbooks:

1. Always use FQCN: `ansible.builtin.copy`, `ansible.builtin.template`, etc. — never short module names
2. All tasks must be idempotent — use `creates:`, `when:`, or module-native idempotency checks
3. Variables go in `vars/` or `group_vars/` — never hardcoded in task files
4. Sensitive values must use `ansible-vault` — add comment `# vault-encrypted` next to the variable
5. Use `become: true` at task level only, never at play level unless every task needs it
6. Include a `tags:` block on every task for selective execution
7. Add `# Test with: ansible-playbook --check --diff` comment at top of every playbook
8. YAML formatting: 2-space indent, explicit string quoting where ambiguous
9. Group related tasks into roles when the playbook exceeds ~20 tasks
