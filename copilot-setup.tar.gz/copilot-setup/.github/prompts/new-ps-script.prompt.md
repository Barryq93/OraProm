---
mode: agent
description: Scaffold a new PowerShell monitoring script using AIB.Logging
---

Scaffold a PowerShell monitoring script that does the following: {{what_to_monitor}}

Requirements:
- Import AIB.Logging from `$PSScriptRoot\commons\AIB.Logging`
- Use `Write-Log -Level {LEVEL} -Message {MESSAGE}` — no Write-Host or Write-Error
- CmdletBinding + param block with at minimum: -TargetServer, -Threshold
- Wrap logic in try/catch with error logging
- Return a [PSCustomObject] with: Status, Message, Value, Threshold, Server, Timestamp, ScriptName
- PSScriptAnalyzer-compatible
- Timestamp format: dd-MM-yy HH:mm:ss
