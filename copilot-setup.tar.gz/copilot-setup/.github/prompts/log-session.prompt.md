---
mode: agent
description: Write a full session summary to the nearest .copilot/ folder
---

Review everything done in this conversation and write a complete summary
to the nearest `.copilot/changes.md` and `.copilot/thoughts.md` files.

Follow the standard logging format from copilot-instructions.md.

Use DD-MM-YY HH:MM for all timestamps.

Be thorough — this is an end-of-session capture. Include:
- All files created or changed
- All decisions made and alternatives rejected
- Any open questions or follow-up actions
- Whether any decisions should be promoted to workingFolder/ or architecture/
