---
mode: ask
description: Promote a thought or workingFolder draft to a formal ADR in architecture/
---

Review the following draft or thoughts entry and produce a complete, polished
ADR ready to move to `architecture/`:

{{source_content_or_filename}}

Apply the standard ADR format:
- Status: Accepted
- Date in DD-MM-YY
- Include or improve the MermaidJS diagram
- Sharpen the Consequences section to reflect what was actually implemented
- Filename: kebab-case, saved to architecture/

After saving, append to `.copilot/changes.md` noting the promotion.
