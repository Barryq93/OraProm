# Workspace Context

## Role
Platform Engineer / SRE / Solution Architect working in enterprise document management.
Primary focus is scripting, system operations, and solution design — not deep application development.

## Primary Systems
- **IBM Content Manager 8 (CM8)**: Document management platform
  - REST API: https://www.ibm.com/docs/en/content-manager/8.7.0?topic=support-rest-api-documentation
  - CMIS 1.0: https://docs.oasis-open.org/cmis/CMIS/v1.0/cmis-spec-v1.0.html
  - Always use CM8 REST or CMIS — never suggest the FileNet Java API
- **DB2 (IBM LUW)**: Primary database backing CM8; all SQL must use DB2 syntax
- **Kofax Capture / Tungsten Total Agility**: Document capture pipeline (integration server on-prem)
- **Spring Boot Microservices**: Java services integrating CM8 and DocuSign — support and design only, not development
- **Windows Servers**: Host PowerShell monitoring scripts
- **Linux**: Host DB2 day-to-day operation scripts

## Folder Structure
- `architecture/` — Promoted design docs (MD + MermaidJS); source of truth for system design
- `git/` — Active repos: PowerShell monitoring, Ansible playbooks, SQL scripts, Spring Boot apps
- `powershell/` — Standalone Windows monitoring scripts
- `shell/` — General Linux shell scripts
- `db2/` — DB2-specific shell scripts (split from shell/)
- `python/` — Simple utility scripts
- `workingFolder/` — Draft design decisions not yet promoted to architecture/

## Date Format
Always use DD-MM-YY HH:MM (Irish format) in all generated content, logs, and comments.
Example: 06-05-26 11:45

## Sensitive Values — Never Hardcode
- DB2 credentials (username, password, instance name)
- CM8 server hostnames or URLs
- Any credentials or connection strings
Always use environment variables or a config file reference with a comment indicating the expected value.

## General Behaviour
- Prefer working output over lengthy explanation unless asked
- When suggesting Ansible, use idempotent tasks and FQCN (ansible.builtin.*)
- For DB2 tasks, always note impact on CM8 tablespaces where relevant
- When designing flows, always offer a MermaidJS diagram
- Flag CM8 API version-specific caveats where known

---

## Logging Requirement (MANDATORY)

After EVERY agent interaction where code, scripts, configs, or docs are
created or modified, you MUST append an entry to both files below —
IF a `.copilot/` folder exists in the current working directory or its
nearest parent directory.

### Locate the `.copilot/` folder
1. Check the directory of the file(s) being worked on
2. If not found, walk up to the parent directory
3. If no `.copilot/` folder exists anywhere in the path, skip logging silently — do NOT create one

### Append to `.copilot/changes.md`

```
## [DD-MM-YY HH:MM] — <one-line summary>

**Files affected**: list each file changed
**What changed**: brief description of what was done
**Why**: reason for the change, problem it solves
**Alternatives rejected**: any options considered but not taken, and why
**Caveats**: known limitations, follow-up needed, or risks

---
```

### Append to `.copilot/thoughts.md`

```
## [DD-MM-YY HH:MM] — <one-line summary>

**Context**: what was being worked on and why
**Reasoning**: the thought process behind the approach taken
**Open questions**: anything unresolved or worth revisiting
**Promote to ADR?**: yes / no / maybe — one line reason

---
```

### Logging Rules
- Always append — never overwrite existing content
- Be specific: reference actual filenames, function names, DB2 table names, CM8 endpoints, or script parameters
- Trivial changes (typo fixes) still get logged but briefly
- `Promote to ADR?` in thoughts.md signals whether the decision should move to `workingFolder/` or `architecture/`
