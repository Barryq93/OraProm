---
applyTo: "**/*.ps1,**/powershell/**,**/Powershell/**"
description: PowerShell monitoring scripts for Windows servers
---

## Module & Logging
- AIB.Logging is always available via the `commons` symlink in the script's directory
- NEVER use `Write-Host`, `Write-Output`, `Write-Verbose`, `Write-Warning`, or `Write-Error` for user-facing messages
- ALL logging must use: `Write-Log -Level {LEVEL} -Message {MESSAGE}`
- Valid levels: use whatever AIB.Logging supports — if unsure, use INFO, WARN, ERROR
- Import pattern at top of every script:
  ```powershell
  Import-Module "$PSScriptRoot\commons\AIB.Logging"
  ```

## Style & Standards
- Use `[CmdletBinding()]` and a `param()` block on every script
- PSScriptAnalyzer-compatible: no aliases, approved verbs only
- Use `$PSScriptRoot` for all relative paths — never hardcode paths
- Wrap all meaningful operations in `try/catch` blocks
- Never hardcode credentials, server names, or connection strings — use parameters or env vars
- Scripts should return structured `[PSCustomObject]` objects, not plain text
  (exact shape is still being designed — keep properties descriptive and consistent)

## Commons Symlink
- The symlink is always named `commons` and lives in the same directory as the script
- To create the symlink manually: `New-Item -ItemType SymbolicLink -Name commons -Target "C:\path\to\your\shared\lib"`
- Always reference shared modules via `$PSScriptRoot\commons\<ModuleName>`
