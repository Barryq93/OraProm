---
applyTo: "**/*.sh,**/shell/**"
description: General Linux shell scripts
---

## Standards
- Always include `set -euo pipefail` at the top of every script
- Log to stdout with timestamps: `echo "[$(date '+%d-%m-%y %H:%M:%S')] MESSAGE"`
- Never hardcode credentials or hostnames — use environment variables
- Use descriptive variable names in UPPER_SNAKE_CASE for env/config vars
- Quote all variable expansions: `"$VAR"` not `$VAR`
- Scripts should be idempotent where possible
