---
applyTo: "**/*.sql,**/sql/**"
description: Ad hoc SQL scripts targeting IBM DB2 for CM8
---

## DB2 Syntax Rules (Strict)
- DB2 LUW syntax only — never PostgreSQL, MySQL, or ANSI-only constructs
- `FETCH FIRST n ROWS ONLY` — never `LIMIT`
- `CURRENT TIMESTAMP` — never `NOW()`
- `CURRENT DATE` — never `CURDATE()`
- `VALUES (...)` for single-row inserts
- Use `WITH UR` (uncommitted read) for read-only diagnostic queries where appropriate

## Schema & Table Conventions
- Always qualify CM8 table names with schema: `ICMADMIN.<TABLE>`
- Never use `SELECT *` in any script — list columns explicitly
- No other custom schemas exist currently

## Script Quality
- Scripts are ad hoc, run via DB2 CLI — no stored procedures
- Include a comment block at top: purpose, affected tables, run instructions
- Include RUNSTATS recommendation comment after any large INSERT/UPDATE/DELETE
- Never hardcode credentials or instance names in SQL files
