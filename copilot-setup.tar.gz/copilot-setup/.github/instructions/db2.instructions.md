---
applyTo: "**/db2/**,**/*.db2"
description: DB2-specific shell scripts for day-to-day CM8 database operations
---

## DB2 Connection Pattern
- Use raw `db2` CLI — no shared connection wrapper exists yet
- Standard pattern:
  ```bash
  db2 connect to "$DATABASE" user "$DB_USER" using "$DB_PASSWORD"
  # ... operations ...
  db2 connect reset
  ```
- Always connect and disconnect explicitly — never leave connections open
- Credentials must come from environment variables: `$DATABASE`, `$DB_USER`, `$DB_PASSWORD`

## DB2 CLI Standards
- Use `db2 -x` for scriptable output (no column headers)
- Use `db2 -v` for verbose output during interactive use
- Always check DB2 return codes after critical operations:
  ```bash
  db2 "SOME SQL"
  RC=$?
  if [ $RC -ne 0 ]; then
    echo "[$(date '+%d-%m-%y %H:%M:%S')] ERROR: DB2 command failed with RC=$RC"
    exit $RC
  fi
  ```
- Log every operation with timestamp before and after execution

## CM8 Awareness
- Scripts touching tablespaces must include a comment noting the CM8 impact
- ICMADMIN is the primary schema — qualify all CM8 table references: `ICMADMIN.<TABLE>`
- Note any RUNSTATS recommendations in comments after large data changes
