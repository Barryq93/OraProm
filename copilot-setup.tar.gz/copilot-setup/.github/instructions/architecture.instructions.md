---
applyTo: "**/architecture/**,**/workingFolder/**"
description: Architecture design documents and draft decision records
---

## Document Standards
- All design docs use MermaidJS diagrams
- Choose diagram type based on use case:
  - `sequenceDiagram` — API flows, integration interactions
  - `flowchart TD` — system topology, process flows
  - `erDiagram` — DB2 schema documentation
  - `classDiagram` — object/data model design
  - `stateDiagram-v2` — document lifecycle, workflow states
- Always offer to generate a MermaidJS diagram when designing any flow or integration

## ADR Format
Design decisions follow this structure:
```markdown
# [JIRA-XXX] Title of Decision

**Status**: Proposed | Accepted | Deprecated
**Date**: DD-MM-YY
**Jira**: [JIRA-XXX](link if available)

## Context
Why is this decision needed? What constraints exist?

## Decision
What was decided?

## Consequences
Trade-offs, CM8/DB2 performance implications, operational impact.

## Diagram
(MermaidJS here)
```

## Promotion Pipeline
- `workingFolder/` = draft decisions in progress
- `architecture/` = promoted, accepted decisions
- Copilot should note `Promote to ADR?` in `.copilot/thoughts.md` when relevant
