# Copilot Setup — Instructions

## File Placement

```
CODING/
├── .github/
│   ├── copilot-instructions.md          ← always-on workspace context
│   ├── instructions/
│   │   ├── powershell.instructions.md   ← auto-applied to *.ps1
│   │   ├── shell.instructions.md        ← auto-applied to *.sh / shell/
│   │   ├── db2.instructions.md          ← auto-applied to db2/
│   │   ├── sql.instructions.md          ← auto-applied to *.sql
│   │   └── architecture.instructions.md ← auto-applied to architecture/ workingFolder/
│   ├── skills/
│   │   ├── powershell-script/SKILL.md   ← invoked: "create a PS monitoring script"
│   │   ├── shell-script/SKILL.md        ← invoked: "create a shell script"
│   │   ├── db2-health-check/SKILL.md    ← invoked: "DB2 health / diagnostic"
│   │   ├── cm8-integration/SKILL.md     ← invoked: "CM8 API / CMIS / workflow"
│   │   ├── ansible-playbook/SKILL.md    ← invoked: "create an Ansible playbook"
│   │   └── architecture-doc/SKILL.md    ← invoked: "design doc / ADR / diagram"
│   └── prompts/
│       ├── new-adr.prompt.md            ← /new-adr
│       ├── new-ps-script.prompt.md      ← /new-ps-script
│       ├── new-db2-script.prompt.md     ← /new-db2-script
│       ├── log-session.prompt.md        ← /log-session
│       └── promote-to-adr.prompt.md     ← /promote-to-adr
├── db2/                                 ← move DB2-specific scripts here from shell/
├── architecture/
├── git/
├── powershell/
├── shell/
├── python/
└── workingFolder/
```

## .gitignore — Add This
```
**/.copilot/
```

## Creating a .copilot/ Folder (Opt-in Logging)
Copy the templates into any directory where you want logging:
```bash
mkdir .copilot
cp /path/to/.copilot-templates/thoughts.md .copilot/thoughts.md
cp /path/to/.copilot-templates/changes.md .copilot/changes.md
# Optional:
cp /path/to/.copilot-templates/context.md .copilot/context.md
```

## VSCode Settings to Enable
- GitHub > Copilot > Chat > Code Generation: Use Instruction Files → ON
- Use Agent mode in Copilot Chat for Skills to activate

## PowerShell Commons Symlink
Run once per machine to set up the commons symlink in a script directory:
```powershell
New-Item -ItemType SymbolicLink -Name commons -Target "C:\path\to\your\shared\lib"
```
The symlink must always be named `commons`.

## Prompt File Usage
In Copilot Chat (agent mode), type:
- `/new-adr` — create an ADR
- `/new-ps-script` — scaffold a PowerShell monitoring script
- `/new-db2-script` — scaffold a DB2 shell script
- `/log-session` — end-of-session summary to .copilot/
- `/promote-to-adr` — promote a workingFolder draft to architecture/
