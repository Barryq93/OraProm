# Directory Context

## Purpose
What this folder is for, who uses the outputs, what system it touches.

## Key dependencies
e.g. "Scripts here connect to DB2 instance on server X via env vars"

## Conventions
Naming patterns, required parameters, output formats expected by other systems.

## Do not
Anything Copilot should avoid in this directory.
e.g. "Do not alter tablespace definitions without a changes.md entry"
