# Thoughts & Reasoning Log

<!-- Copilot appends a new entry after every agent interaction in this directory -->
<!-- Format:
## [DD-MM-YY HH:MM] — summary

**Context**: what was being worked on and why
**Reasoning**: the thought process behind the approach taken
**Open questions**: anything unresolved or worth revisiting
**Promote to ADR?**: yes / no / maybe — one line reason

---
-->

---
