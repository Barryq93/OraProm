# Changes Log

<!-- Copilot appends a new entry after every agent interaction in this directory -->
<!-- Format:
## [DD-MM-YY HH:MM] — summary

**Files affected**: list each file
**What changed**: what was done
**Why**: reason / problem solved
**Alternatives rejected**: options not taken and why
**Caveats**: limitations, risks, follow-up needed

---
-->

---
