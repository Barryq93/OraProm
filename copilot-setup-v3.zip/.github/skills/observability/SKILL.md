---
name: observability
description: Design or build Prometheus metrics, Grafana Alloy River config, Pushgateway PowerShell integration, Loki log pipelines, or Prometheus alert rules for the CM8/DB2/Kofax/WAS platform. Use when asked about monitoring, metrics, alerting, dashboards, Grafana Alloy, Loki, Pushgateway, or Prometheus.
---

## Environment
- Windows Server 2019/2022 (Kofax, WAS, ECM App Engine) | RHEL 8.1 (ECM CE, DB2)
- Metrics: PowerShell scripts → Pushgateway → Prometheus → Grafana/Mimir
- Logs: Grafana Alloy → Loki (operational) + Splunk (compliance/SIEM)
- Alloy syntax: River `.alloy` files ONLY — never legacy Grafana Agent YAML
- PS target: 5.1 — `Write-Log -Level {LEVEL} -Message {MESSAGE}` for all script logging

---

## Metric Naming
Format: `platform_component_measurement_unit`
Lowercase, underscores only.

| Component | Example |
|-----------|---------|
| CM8 Library Server | `cm_library_server_response_ms` |
| DB2 Tablespace | `db2_tablespace_used_bytes{tablespace="USERSPACE1"}` |
| DB2 Lock Waits | `db2_lock_waits_active_total` |
| Kofax Batch Queue | `kofax_capture_batch_queue_depth_total{state="error"}` |
| WAS JVM Heap | `was_jvm_heap_used_pct{host="HOST"}` |
| Windows Service | `windows_service_up{service="KofaxCapture",host="HOST"}` — 1=up, 0=down |

Standard labels on all metrics: `host`, `environment`, `component`, `platform`

---

## Pushgateway PowerShell Pattern

```powershell
function Push-MetricToGateway {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]  [string]$PushgatewayUrl,
        [Parameter(Mandatory=$true)]  [string]$JobName,
        [Parameter(Mandatory=$true)]  [string]$MetricName,
        [Parameter(Mandatory=$true)]  [double]$Value,
        [Parameter(Mandatory=$false)] [hashtable]$Labels = @{},
        [Parameter(Mandatory=$false)] [ValidateSet("gauge","counter")] [string]$Type = "gauge",
        [Parameter(Mandatory=$false)] [string]$Help = ""
    )
    $labelPath = ($Labels.GetEnumerator() | ForEach-Object { "$($_.Key)/$($_.Value)" }) -join "/"
    $uri = "$PushgatewayUrl/metrics/job/$JobName"
    if ($labelPath) { $uri = "$uri/$labelPath" }
    $labelStr = ($Labels.GetEnumerator() | ForEach-Object { "$($_.Key)=`"$($_.Value)`"" }) -join ","
    $metricLine = if ($labelStr) { "${MetricName}{${labelStr}} $Value" } else { "$MetricName $Value" }
    $payload = "# HELP $MetricName $Help`n# TYPE $MetricName $Type`n${metricLine}`n"
    try {
        Invoke-RestMethod -Uri $uri -Method Post -Body $payload -ContentType "text/plain; charset=utf-8" -UseBasicParsing
        Write-Log -Level INFO -Message "Pushed $MetricName=$Value to $JobName"
    }
    catch { Write-Log -Level ERROR -Message "Pushgateway push failed for ${MetricName}: $_" }
}

function Remove-PushgatewayJob {
    # MANDATORY after every one-shot job — stale metrics persist otherwise
    [CmdletBinding()]
    param([string]$PushgatewayUrl, [string]$JobName)
    Invoke-RestMethod -Uri "$PushgatewayUrl/metrics/job/$JobName" -Method Delete -UseBasicParsing
    Write-Log -Level INFO -Message "Pushgateway job deleted: $JobName"
}
```

Rules:
- Always call `Remove-PushgatewayJob` after a one-shot job completes
- `gauge` for point-in-time values; `counter` for monotonically increasing only
- `honor_labels: true` on Pushgateway scrape target — mandatory
- One `$JobName` per script — never reuse across unrelated scripts
- Never hardcode `$PushgatewayUrl` — pass as parameter or env var

---

## Grafana Alloy River Syntax

Always River `.alloy` syntax. Never legacy YAML Grafana Agent format.
All endpoints and credentials via `env()` — never hardcoded.

```alloy
prometheus.scrape "pushgateway" {
  targets         = [{ __address__ = env("PUSHGATEWAY_HOST") }]
  scrape_interval = "60s"
  honor_labels    = true
  forward_to      = [prometheus.remote_write.mimir.receiver]
}

prometheus.scrape "windows_hosts" {
  targets = [
    { __address__ = "kofax-host-01:9182", component = "kofax", platform = "windows" },
    { __address__ = "ecm-appeng-01:9182",  component = "ecm",   platform = "windows" },
  ]
  scrape_interval = "60s"
  forward_to      = [prometheus.remote_write.mimir.receiver]
}

prometheus.scrape "linux_hosts" {
  targets = [
    { __address__ = "ecm-ce-01:9100",  component = "ecm", platform = "linux" },
    { __address__ = "db2-host-01:9100", component = "db2", platform = "linux" },
  ]
  scrape_interval = "30s"
  forward_to      = [prometheus.remote_write.mimir.receiver]
}

loki.source.windowsevent "kofax_app_log" {
  eventlog_name          = "Application"
  use_incoming_timestamp = false
  forward_to             = [loki.write.default.receiver]
  labels = { job = "windows_eventlog", component = "kofax", platform = "windows" }
}

prometheus.remote_write "mimir" {
  endpoint {
    url = env("MIMIR_REMOTE_WRITE_URL")
    basic_auth { username = env("MIMIR_USERNAME"); password = env("MIMIR_PASSWORD") }
  }
}

loki.write "default" {
  endpoint { url = env("LOKI_PUSH_URL") }
}
```

---

## Alert Rule Standards

```yaml
groups:
  - name: documents.platform.critical
    rules:
      - alert: DB2TablespaceHighUsage
        expr: db2_tablespace_used_bytes / db2_tablespace_total_bytes * 100 > 85
        for: 5m
        labels:
          severity: critical
          component: db2
          team: documents
        annotations:
          summary: "DB2 tablespace {{ $labels.tablespace }} critically high on {{ $labels.host }}"
          description: "{{ $value | humanizePercentage }} used. Threshold: 85%."
          runbook_url: "https://wiki.internal/runbooks/db2-tablespace"
```

- Always include `for:` — no instant-fire alerts
- Always include `runbook_url`
- `severity`: critical | warning | info
- `team: documents` on every rule
- Humanize values: `humanize`, `humanizePercentage`, `humanizeDuration`

---

## Grafana Dashboard Conventions
- Titles: "[Component] Health" or "[Component] Overview"
- Template variables on all dashboards: `component`, `environment`, `host`
- Never hardcode datasource UID — use a datasource template variable
- Panel titles describe what is measured, not the query expression
- Gauge/stat thresholds must match alert rule thresholds exactly
- Tags: `documents-platform`, `sre`, component name
