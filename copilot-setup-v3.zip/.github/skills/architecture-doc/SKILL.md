---
name: architecture-doc
description: Create or update architecture design documents, ADRs, or system diagrams for the CM8/DB2/Kofax platform. Use when asked to document a design decision, create a system diagram, or write a technical design.
---

1. Always include at least one MermaidJS diagram. Choose by use case:
   - `sequenceDiagram` — API flows, system interactions
   - `flowchart TD` — process flows, system topology
   - `erDiagram` — DB2 schema or data model
   - `classDiagram` — object/data structure
   - `stateDiagram-v2` — document lifecycle, workflow states

2. New docs go to `workingFolder/` — promote to `architecture/` only when accepted

3. Always mention:
   - Systems involved (CM8 8.7.0 FP4, DB2 11.5.9, Kofax/TTA, Spring Boot)
   - DB2/CM8 tablespace implications for bulk or storage-affecting operations
   - REST vs CMIS — always REST or CMIS, never Java SDK

4. After creating, append to nearest `thoughts.md` with `Promote to ADR?: yes/maybe/no`

5. Update DECISIONS.md at the nearest `.copilot/` location if a significant architectural choice was made
