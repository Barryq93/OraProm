---
name: powershell-script
description: Scaffold or review a PowerShell monitoring script for Windows servers using AIB.Logging and PS 5.1. Use when asked to create, fix, or improve a PowerShell script.
---

1. `#Requires -Version 5.1` at top — PS 7 syntax never used
2. Import: `Import-Module "$PSScriptRoot\commons\AIB.Logging"`
3. All output via `Write-Log -Level {LEVEL} -Message {MESSAGE}` only
4. `[CmdletBinding()]` + `param()` block on every script
5. `try/catch` with `Write-Log -Level ERROR` on failure
6. Return `[PSCustomObject]` with: Status, Message, Value, Threshold, Server, Timestamp, ScriptName
7. `$PSScriptRoot` for all paths — no hardcoded paths
8. No hardcoded credentials or server names

Skeleton:
```powershell
#Requires -Version 5.1
Import-Module "$PSScriptRoot\commons\AIB.Logging"

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]  [string]$TargetServer,
    [Parameter(Mandatory=$false)] [int]$Threshold = 80
)

try {
    Write-Log -Level INFO -Message "Starting on $TargetServer"
    # logic here
    return [PSCustomObject]@{
        Status     = 'OK'
        Message    = 'Completed successfully'
        Value      = $null
        Threshold  = $Threshold
        Server     = $TargetServer
        Timestamp  = (Get-Date -Format 'dd-MM-yy HH:mm:ss')
        ScriptName = $MyInvocation.MyCommand.Name
    }
}
catch {
    Write-Log -Level ERROR -Message "Failed on ${TargetServer}: $_"
    return [PSCustomObject]@{
        Status     = 'ERROR'
        Message    = $_.Exception.Message
        Value      = $null
        Threshold  = $Threshold
        Server     = $TargetServer
        Timestamp  = (Get-Date -Format 'dd-MM-yy HH:mm:ss')
        ScriptName = $MyInvocation.MyCommand.Name
    }
}
```
