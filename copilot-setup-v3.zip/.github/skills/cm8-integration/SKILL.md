---
name: cm8-integration
description: Help design or document CM8 REST API or CMIS 1.0 integrations, Spring Boot service patterns, or document workflow flows. Use when asked about CM8 APIs, item types, object stores, or document workflows.
---

IBM Content Manager EE 8.7.0 FP4 — NOT FileNet P8.
Never suggest com.filenet.api.* or P8/FileNet terminology.

## API References
- CM8 REST: https://www.ibm.com/docs/en/content-manager/8.7.0?topic=support-rest-api-documentation
- CMIS 1.0: https://docs.oasis-open.org/cmis/CMIS/v1.0/cmis-spec-v1.0.html

## Role
Architecture, API contract design, and code review only.
Never produce Spring Boot controller/service/repository implementation code.

## Key Patterns for Design Review
- Auth: Bearer token (JWT) — token refresh mandatory, ~30 min expiry
- PID handling: PIDs contain spaces — must be URL-encoded in path segments
- Query limit: always set `limit` explicitly; `limit=0` exhausts memory on large repos
- Multipart ordering: attributes JSON array MUST precede file streams
- CMIS: use for BAW integration only; does not support multi-part content or annotations

## Common Failure Points to Flag
1. Token not refreshed → 401 mid-session
2. File streams sent before attributes JSON in multipart
3. PID not URL-encoded → 400
4. Item type name case mismatch → silent "not found"
5. Query with no limit → hangs on large repositories
6. Content URL cached → RM token is time-limited

## When Designing Flows
- Always produce a MermaidJS `sequenceDiagram`
- Label each step with HTTP method and endpoint
- Show error paths as well as happy path
- Note DB2/tablespace implications for bulk document operations
