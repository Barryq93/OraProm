---
name: shell-script
description: Scaffold or review a Linux shell script for DB2 operations or general platform tasks on RHEL 8.1. Use when asked to create, fix, or improve a shell or bash script.
---

1. `#!/usr/bin/env bash` + `set -euo pipefail`
2. Log function: `log() { echo "[$(date '+%d-%m-%y %H:%M:%S')] $*"; }`
3. For DB2 scripts:
   - Source: `. ~/sqllib/db2profile`
   - Credentials from env vars: `$DATABASE`, `$DB_USER`, `$DB_PASSWORD`
   - Connect and disconnect explicitly
   - Check return codes after every DB2 command
   - DB2 11.5.9 syntax: `FETCH FIRST n ROWS ONLY`, `CURRENT TIMESTAMP`, `ICMADMIN.<TABLE>`
4. Quote all variable expansions: `"$VAR"`
5. Comment block at top: purpose, usage, required env vars

DB2 skeleton:
```bash
#!/usr/bin/env bash
set -euo pipefail
# Purpose: <describe>
# Usage: DATABASE=<db> DB_USER=<u> DB_PASSWORD=<p> ./script.sh
# Required: DATABASE, DB_USER, DB_PASSWORD

log() { echo "[$(date '+%d-%m-%y %H:%M:%S')] $*"; }

. ~/sqllib/db2profile
log "Connecting to $DATABASE"
db2 connect to "$DATABASE" user "$DB_USER" using "$DB_PASSWORD"

# logic here

db2 connect reset
log "Done"
```
