# Workspace Context

## Role
Platform Engineer / SRE / Solution Architect in enterprise document management.
Primary focus: scripting, system operations, and solution design — not deep application development.

## Primary Systems
- **IBM Content Manager EE 8.7.0 FP4** (CM8)
  — This is CM8 EE, NOT FileNet P8. Never suggest com.filenet.api.* or P8 terminology.
  — REST API: https://www.ibm.com/docs/en/content-manager/8.7.0?topic=support-rest-api-documentation
  — CMIS 1.0: https://docs.oasis-open.org/cmis/CMIS/v1.0/cmis-spec-v1.0.html
  — Always use REST or CMIS. Never the FileNet Java API.
- **DB2 LUW 11.5.9** — backing database for CM8. All SQL must target 11.5.9 exactly.
- **Kofax Capture / Tungsten Total Agility** — document capture, integration server on-prem
- **Spring Boot Microservices** — support and design only; not implementation
- **Windows Server 2019/2022** — hosts PowerShell monitoring; PS 5.1 target
- **RHEL 8.1** — hosts DB2 and ECM Content Engine; bash scripts here

## Folder Structure
- `architecture/`  — promoted design docs (MD + MermaidJS); source of truth
- `git/`           — active repos: PS monitoring, Ansible, SQL, Spring Boot
- `powershell/`    — standalone Windows monitoring scripts
- `shell/`         — general Linux shell scripts
- `db2/`           — DB2-specific shell scripts
- `python/`        — simple utility scripts
- `workingFolder/` — draft design decisions not yet promoted to architecture/

## Date Format
Always DD-MM-YY HH:MM (Irish format) in all generated content, logs, comments, ADRs.
Example: 06-05-26 11:45

## Sensitive Values — Never Hardcode
DB2 credentials, CM8 server hostnames, connection strings, tokens.
Always use environment variables or a config parameter with a comment.

## General Behaviour
- Prefer working output over explanation unless asked otherwise
- For DB2 tasks, note impact on CM8 tablespaces where relevant
- When designing flows, always offer a MermaidJS diagram
- PS 7 syntax must never be used — target is PS 5.1 only
- DB2 12.x syntax must never be used — target is 11.5.9

---

## Session Logging — MANDATORY

After every agent interaction where code, scripts, configs, or docs are created
or modified, append entries to `changes.md` and `thoughts.md` in the nearest
`.copilot/` folder.

### How to locate the nearest .copilot/ folder

Starting from the directory of the file(s) being worked on, walk UP the directory
tree until a `.copilot/` folder is found. Use the first one found.

Example: working on `powershell/monitoring/disk-check.ps1`
→ check `powershell/monitoring/.copilot/`  — not found
→ check `powershell/.copilot/`             — found → use this one
→ stop walking

If no `.copilot/` folder exists anywhere in the path up to the workspace root:
→ Output the log entries as plain text for manual copy
→ Do NOT create a `.copilot/` folder automatically

### Auto-create log files

If the `.copilot/` folder exists but `changes.md` or `thoughts.md` do not:
→ Create them with the header below before appending
→ Never ask the user to create them

`changes.md` header (create once on first use):
```
# Changes Log

Maintained by GitHub Copilot. Append only.

---
```

`thoughts.md` header (create once on first use):
```
# Copilot Thoughts

Maintained by GitHub Copilot. Append only.

---
```

### DECISIONS.md — same walk-up rule

`DECISIONS.md` is written alongside the nearest `.copilot/` folder.
If `.copilot/` is at `powershell/.copilot/`, write `DECISIONS.md` to `powershell/DECISIONS.md`.
If no `.copilot/` is found, output the ADR for manual copy.
If `DECISIONS.md` does not exist at that location, create it from the first-run
template in `decisions.instructions.md`.

---

### Append to changes.md

```
## [DD-MM-YY HH:MM] — <one-line summary>

**Files affected**:
- <workspace-relative full path to each file changed>

**What changed**: brief description of what was done
**Why**: reason for the change or problem solved
**Alternatives rejected**: options considered and why not taken
**Caveats**: known limitations, follow-up needed, or risks

---
```

### Append to thoughts.md

```
## [DD-MM-YY HH:MM] — <one-line summary>

**Context**: what was being worked on and why
**Reasoning**: thought process behind the approach
**Open questions**: anything unresolved or worth revisiting
**Promote to ADR?**: yes / no / maybe — one line reason

---
```

### Logging Rules
- Always append — never overwrite
- Always use full workspace-relative paths in **Files affected** (e.g. `powershell/monitoring/disk-check.ps1`)
- Use DD-MM-YY HH:MM for all timestamps
- Be specific: reference actual function names, DB2 tables, CM8 endpoints, script parameters
- Trivial changes still get a brief entry
- `Promote to ADR?` signals whether the decision warrants a `workingFolder/` or `architecture/` entry
