---
applyTo: "**"
description: Rules for writing and maintaining DECISIONS.md
---

## Location — Walk-Up Rule

`DECISIONS.md` is always written alongside the nearest `.copilot/` folder.
There is no fixed path — location is resolved at the time of writing.

**Resolution steps:**
1. Starting from the directory of the file(s) being worked on, walk UP until
   a `.copilot/` folder is found
2. Write `DECISIONS.md` in that same directory (sibling to `.copilot/`)
3. If no `.copilot/` folder is found, output the ADR block for manual copy
4. If `DECISIONS.md` does not exist at the resolved location, create it using
   the First-Run Template below — do not ask the user to create it

---

## When to Write an Entry

Write a new ADR when:
- A technology, tool, library, or platform was chosen over an alternative
- A version was pinned for a specific reason
- An architectural boundary was defined
- A security or compliance constraint shaped the implementation
- A known limitation or trade-off was consciously accepted

Do NOT write entries for trivial naming/formatting choices or decisions
that are self-evident from the code.

When confirming an existing decision is still valid: update the entry's date
and add a confirmation note. Do not create a duplicate ADR.

---

## Entry Format

```markdown
## ADR-NNN — Short decision title

**Date**: DD-MM-YY
**Status**: Proposed | Accepted | Superseded by ADR-NNN
**Mode**: Coding | Architecture | Research
**Component**: ECM | DB2 | Kofax | Observability | Ansible | Scripting | etc.
**Jira**: JIRA-XXX (omit if not applicable)

### Context
Why did this decision need to be made?

### Decision
What was decided, in one clear sentence.

### Reasoning
- **Chosen**: [option] — why
- **Rejected**: [option] — why rejected

### Consequences
What does this make easier? What does it make harder?

### References
- Link, IBM technote, or internal doc

---
```

---

## Superseding a Decision

1. Change the old entry Status to `Superseded by ADR-NNN`
2. New ADR references the old one in its Context section
3. Never delete old entries

---

## File Structure — Newest First

```markdown
# Decisions Log

Last updated: DD-MM-YY

---

## Index

| ADR | Title | Component | Status | Date |
|-----|-------|-----------|--------|------|

---

## Decisions

(entries here, newest first)
```

---

## First-Run Template

If `DECISIONS.md` does not exist at the resolved location, create it:

```markdown
# Decisions Log

Last updated: DD-MM-YY

---

## Index

| ADR | Title | Component | Status | Date |
|-----|-------|-----------|--------|------|

---

## Decisions

<!-- ADR entries go here, newest first -->
```

---

## Change Log Surface

Every time DECISIONS.md is written, include in the response:
```
Change Log
- <path>/DECISIONS.md — ADR-NNN added: [title]
```
