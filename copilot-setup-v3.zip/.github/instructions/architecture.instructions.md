---
applyTo: "**/architecture/**,**/workingFolder/**"
description: Architecture design documents and draft decision records
---

## Diagrams
Choose MermaidJS type by use case:
- `sequenceDiagram` — API flows, integration interactions
- `flowchart TD` — system topology, process flows
- `erDiagram` — DB2 schema documentation
- `classDiagram` — object/data model design
- `stateDiagram-v2` — document lifecycle, workflow states

Always offer a MermaidJS diagram when designing any flow or integration.

## ADR Format
```markdown
# [JIRA-XXX] Title

**Status**: Proposed | Accepted | Superseded by ADR-NNN
**Date**: DD-MM-YY
**Jira**: JIRA-XXX
**Mode**: Coding | Architecture | Research
**Component**: ECM | DB2 | Kofax | Observability | etc.

## Context
## Decision
## Consequences
## Diagram
(MermaidJS here)
```

## Promotion Pipeline
- `workingFolder/` = drafts in progress
- `architecture/` = promoted, accepted decisions
- Append `Promote to ADR?: yes/maybe/no` to `thoughts.md` when creating docs
