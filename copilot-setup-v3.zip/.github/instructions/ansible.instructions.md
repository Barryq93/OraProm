---
applyTo: "**/playbooks/**,**/ansible/**,**/roles/**"
description: Ansible playbooks for platform configuration
---

- Always use FQCN: `ansible.builtin.copy`, `ansible.builtin.template`, etc.
- All tasks must be idempotent
- Variables in `vars/` or `group_vars/` — never hardcoded in task files
- Sensitive values use `ansible-vault` — add comment `# vault-encrypted`
- `become: true` at task level only
- `tags:` on every task
- Add `# Test with: ansible-playbook --check --diff` comment at top of every playbook
- Group into roles when playbook exceeds ~20 tasks
- YAML: 2-space indent, explicit string quoting where ambiguous
