---
mode: ask
description: Create a new incident runbook using the platform runbook standard
---

Create a runbook for: {{incident_or_component}}

Use the structure from `runbook.instructions.md`.
Include all relevant diagnostic commands for the component.
Mark irreversible steps ⚠ IRREVERSIBLE.
Mark steps requiring elevated access 🔐.
Locate nearest `.copilot/` and log the new file in `changes.md`.
Suggest whether an ADR should be written for any decisions made.
