---
mode: ask
description: Write a full summary of the current session to the nearest .copilot/ logs
---

Summarise everything done in this session and append to the nearest `.copilot/` logs.

Walk up from the primary file worked on to find the nearest `.copilot/` folder.
If no `.copilot/` found, output entries for manual copy.
Auto-create `changes.md` and `thoughts.md` if the folder exists but the files do not.

Write:
- `changes.md`: all files affected (full workspace-relative paths), what changed, why, alternatives rejected, caveats
- `thoughts.md`: context, reasoning, open questions, promote-to-ADR recommendation

If any significant decisions were made, write an ADR to `DECISIONS.md` at the same location.
