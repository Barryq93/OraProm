---
mode: ask
description: Promote a workingFolder draft decision to architecture/ and write a formal ADR
---

Promote the draft at: {{draft_file_path}}

Actions:
1. Move file to `architecture/` with a clean filename
2. Write or update the formal ADR in `DECISIONS.md` at the nearest `.copilot/` location
3. Update Status to `Accepted`
4. Add to the Index table
5. Log in the nearest `changes.md` and `thoughts.md`

If a Jira number is provided: {{jira_number}} — include it in the ADR.
