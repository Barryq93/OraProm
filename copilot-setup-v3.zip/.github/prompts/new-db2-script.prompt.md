---
mode: agent
description: Scaffold a new DB2 LUW 11.5.9 shell script for RHEL 8.1
---

Scaffold a DB2 shell script that performs: {{task_description}}

Requirements:
- `#!/usr/bin/env bash` and `set -euo pipefail`
- Log with DD-MM-YY HH:MM:SS timestamps
- Credentials from env vars only
- Source DB2 environment: `. ~/sqllib/db2profile`
- Explicit connect and disconnect
- Return code check after every DB2 command
- DB2 11.5.9 syntax: `FETCH FIRST n ROWS ONLY`, `CURRENT TIMESTAMP`, `ICMADMIN.` prefix
- Comment block: purpose, usage, required env vars
- Locate nearest `.copilot/` and log the new file in `changes.md`
