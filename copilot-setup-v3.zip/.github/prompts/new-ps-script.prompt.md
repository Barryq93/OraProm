---
mode: agent
description: Scaffold a new PowerShell 5.1 monitoring script using AIB.Logging
---

Scaffold a PowerShell monitoring script that checks: {{what_to_monitor}}

Requirements:
- PS 5.1 only — no PS 7 syntax
- `#Requires -Version 5.1`
- Import AIB.Logging from `"$PSScriptRoot\commons\AIB.Logging"`
- All output via `Write-Log -Level {LEVEL} -Message {MESSAGE}`
- `[CmdletBinding()]` + param block with -TargetServer, -Threshold
- Returns `[PSCustomObject]` per the standard return shape in `powershell.instructions.md`
- `try/catch` with error logging
- Locate nearest `.copilot/` and log the new file in `changes.md`
