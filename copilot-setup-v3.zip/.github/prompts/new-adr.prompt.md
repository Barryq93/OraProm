---
mode: ask
description: Generate a new Architecture Decision Record and add it to the nearest DECISIONS.md
---

Locate the nearest `.copilot/` folder by walking up from the current working directory.
Write `DECISIONS.md` as a sibling of that folder.
If no `.copilot/` found, output the ADR block for manual copy.

Create an ADR for: {{decision_topic}}

Use the format from `decisions.instructions.md`.
Include a MermaidJS diagram relevant to the decision.
Number sequentially from the last ADR in the target DECISIONS.md.
Append to the Index table.
Log to the nearest `changes.md` and `thoughts.md`.
