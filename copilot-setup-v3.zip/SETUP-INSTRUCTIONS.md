# Copilot Setup — Installation Guide

## Design Principles

**Place once, works everywhere.**
The `.github/` folder lives at the `CODING` root — you never touch it again.
`DECISIONS.md` and `.copilot/` logs are found automatically by walking up the tree.
No templates. No copying. Just `mkdir .copilot` where you want logging to start.

---

## Package Contents

```
.github/
  copilot-instructions.md          ← workspace identity, stack, logging behaviour
  instructions/
    tech-lead.instructions.md      ← 7-step execution, TODO-first, self-review, mode detection
    decisions.instructions.md      ← ADR format, walk-up rule, auto-create
    context-memory.instructions.md ← context pulse, drift detection, session checkpoints
    runbook.instructions.md        ← incident runbook structure + platform diagnostics
    powershell.instructions.md     ← PS 5.1, AIB.Logging, commons, return shape
    shell.instructions.md          ← RHEL 8.1 bash standards, timestamp logging
    db2.instructions.md            ← DB2 11.5.9, connect pattern, CM8 schema rules
    sql.instructions.md            ← DB2 syntax, ICMADMIN prefix, no SELECT *
    architecture.instructions.md   ← MermaidJS types, ADR format, promotion pipeline
    ansible.instructions.md        ← FQCN, idempotency, vault pattern
  skills/
    powershell-script/SKILL.md     ← scaffold PS monitoring scripts
    shell-script/SKILL.md          ← scaffold DB2/Linux shell scripts
    db2-health-check/SKILL.md      ← DB2 health and diagnostic queries
    cm8-integration/SKILL.md       ← CM8 REST/CMIS design review
    ansible-playbook/SKILL.md      ← Ansible playbook generation
    architecture-doc/SKILL.md      ← design docs and MermaidJS diagrams
    observability/SKILL.md         ← Prometheus, Pushgateway, Alloy, Loki, alert rules
  prompts/
    new-adr.prompt.md              ← /new-adr
    new-ps-script.prompt.md        ← /new-ps-script
    new-db2-script.prompt.md       ← /new-db2-script
    new-runbook.prompt.md          ← /new-runbook
    log-session.prompt.md          ← /log-session
    promote-to-adr.prompt.md       ← /promote-to-adr

SETUP-INSTRUCTIONS.md             ← this file
```

---

## Step 1 — Copy .github/ to your CODING root

```
CODING/
├── .github/          ← copy here
├── architecture/
├── db2/
├── git/
├── powershell/
├── shell/
├── python/
└── workingFolder/
```

That is the only copy step. You're done.

---

## Step 2 — Enable instruction files in VS Code

Settings (Ctrl+, / Cmd+,):

| Setting | Value |
|---------|-------|
| `github.copilot.chat.codeGeneration.useInstructionFiles` | ✅ Enabled |
| `github.copilot.chat.reviewSelection.useInstructionFiles` | ✅ Enabled |
| `github.copilot.chat.testGeneration.useInstructionFiles` | ✅ Enabled |

Skills activate in **Agent mode only**. Switch to Agent mode in the Copilot Chat
dropdown when you want skills and prompts to activate.

---

## Step 3 — Starting work in a folder

When you begin active work in a subdirectory and want session logging:

```bash
mkdir powershell/.copilot
```

That's it. Copilot will:
- Auto-create `changes.md` and `thoughts.md` on first use (no templates needed)
- Auto-create `DECISIONS.md` alongside `.copilot/` if an ADR-worthy decision is made

If there is no `.copilot/` folder anywhere in the path, Copilot outputs the log
entries as plain text for manual copy — nothing is lost.

---

## Step 4 — Commons symlink (PowerShell only)

The PowerShell instructions expect a `commons` symlink in each PowerShell
script directory pointing to your shared AIB.Logging module.
This is the only per-directory setup and only applies to PowerShell.

```powershell
# Run elevated, once per PowerShell working directory
New-Item -ItemType SymbolicLink `
  -Path ".\commons" `
  -Target "C:\path\to\shared\AIB.Logging"
```

---

## How the walk-up works

For every interaction, Copilot starts at the directory of the file being worked
on and walks UP until it finds a `.copilot/` folder.

Example tree:
```
CODING/
├── .copilot/           ← fallback if nothing closer exists
├── powershell/
│   ├── .copilot/       ← used for anything inside powershell/
│   └── monitoring/
│       ├── .copilot/   ← used for anything inside monitoring/ (closest wins)
│       └── disk-check.ps1
```

`disk-check.ps1` → finds `monitoring/.copilot/` → logs there.
`powershell/other-script.ps1` → finds `powershell/.copilot/` → logs there.
`architecture/design.md` → finds `CODING/.copilot/` → logs there.

DECISIONS.md is always written as a sibling of whichever `.copilot/` was found.

---

## Prompt Reference

Invoke from Copilot Chat with `/`:

| Prompt | Use |
|--------|-----|
| `/new-adr` | Generate a new ADR and write it to the nearest DECISIONS.md |
| `/new-ps-script` | Scaffold a PS 5.1 monitoring script |
| `/new-db2-script` | Scaffold a DB2 11.5.9 shell script |
| `/new-runbook` | Create an incident runbook |
| `/log-session` | Write full session summary to nearest .copilot/ |
| `/promote-to-adr` | Promote a workingFolder draft to architecture/ |

---

## Skills Reference (Agent mode only)

| Skill | Triggers when you mention... |
|-------|------------------------------|
| `powershell-script` | create / fix / scaffold a PowerShell script |
| `shell-script` | create / fix a shell or bash script |
| `db2-health-check` | DB2 health, monitoring, tablespace, locks |
| `cm8-integration` | CM8 API, CMIS, item types, Spring Boot + CM8 |
| `ansible-playbook` | Ansible playbook, automation, server config |
| `architecture-doc` | design doc, HLD, system diagram, ADR |
| `observability` | Prometheus, Alloy, Pushgateway, Loki, metrics, alerting |

---

## .gitignore

Add this to your root `.gitignore` — session logs are not source control artifacts:

```
.copilot/
```
